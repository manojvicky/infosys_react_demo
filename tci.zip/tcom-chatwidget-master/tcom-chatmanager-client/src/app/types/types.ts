/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:27:40+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T18:21:45+11:00
 * @Copyright: Telstra 2018
 */

export enum Features {
	LIVE_AGENT = 'LiveAgent'
}

export enum Language {
	ENGLISH = 'en'
}
