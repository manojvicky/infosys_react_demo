export interface IRequestOptions {
	method: string;
	headers: any;
	mode?: string;
	body?: any;
}
