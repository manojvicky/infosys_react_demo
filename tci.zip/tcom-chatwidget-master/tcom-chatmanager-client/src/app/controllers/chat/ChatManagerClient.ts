/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:53:06+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:45:34+11:00
 * @Copyright: Telstra 2018
 */

import {
	NormalizedChatManagerConfig, Configuration
} from '../../../app/types/IChatManagerConfig';
import { FetchConfigService } from '../../../app/services/FetchConfigService';
//import { Promise } from 'es6-promise';

export class ChatManagerClient {

	constructor(readonly endpointUrl: string) {
	}

	configService: FetchConfigService = new FetchConfigService(this.endpointUrl);

	static chatManagerConfig: NormalizedChatManagerConfig;

	public async loadPageConfigurations(pageUrl: string) {
		let me = this;
		let response :any;
		let responseConfig = await me.configService.fetchConfig();
		if (responseConfig && responseConfig.data) {
			this.setChatManagerConfig(responseConfig.data);
			response = this.fetchConfig(pageUrl);
		} else {
			console.log('Attention: There may be some issues with the ChatManager config JSON');
		}
		return response;
	}

	public setChatManagerConfig(chatManagerConfig: NormalizedChatManagerConfig){
		ChatManagerClient.chatManagerConfig = chatManagerConfig;
	}

	public fetchConfig(pageUrl: string): NormalizedChatManagerConfig {

		let globalConfig: Configuration = {};
		let	groupConfig: Configuration = {};
		let	pageConfig: Configuration = {};
		let	buttonIdLevelConfig: Configuration = {};
		let	systemConfig: Configuration = {};

		let normalizedConfig = {
			configuration: {}
		};

		let buttonId: any;

		try{

		let chatManagerConfig: any = ChatManagerClient.chatManagerConfig;
		globalConfig = chatManagerConfig.global.configuration;

		let groups = chatManagerConfig.global.groups;

		if(groups){
			let currentPage: any, groupItem: any;
					for (let item in groups) {
						groupItem = groups[item];
						let pages = groupItem.groupIdentifier.pages;

						currentPage = pages.filter(function(item: any) {
							return item.pageIdentifier.pageUrl === pageUrl;
						})[0];

						if(currentPage){
							break;
						}
					}

					if(currentPage){
						if(currentPage.pageIdentifier){
								pageConfig = currentPage.pageIdentifier.configuration;
								if(pageConfig){
									buttonId =  pageConfig.buttonId;
								}
						}
						if(groupItem.groupIdentifier){
								groupConfig = groupItem.groupIdentifier.configuration;
						}
					}
		}

		if(buttonId && chatManagerConfig.system && chatManagerConfig.system.buttonIds && chatManagerConfig.system.buttonIds[0][buttonId]){
			buttonIdLevelConfig = chatManagerConfig.system.buttonIds[0][buttonId].configuration;
		}

		if(chatManagerConfig.system && chatManagerConfig.system.configuration){
					systemConfig = chatManagerConfig.system.configuration;
		}

		let finalConfig: Configuration = {
			...globalConfig,
			...groupConfig,
			...pageConfig,
			...buttonIdLevelConfig,
			...systemConfig
		};

		normalizedConfig.configuration = finalConfig;

	}catch(e){
		console.log('failed during the config fetch '+e);
	}

		return normalizedConfig;
	}
}
