/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-30T01:34:22+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-02T15:25:55+11:00
 * @Copyright: Telstra 2018
 */
import 'whatwg-fetch';
//import { IS_DEV } from '../../app/constants/DefaultConstants';

interface IFetchConfigService {
	fetchConfig(): any;
}

declare global {
    interface Window { chatManagerConfigurationData: any; }
}

interface IRequestOptions {
	method: string;
	headers?: any;
	mode?: string;
	body?: any;
}

export class FetchConfigService implements IFetchConfigService {

	constructor(readonly endpointUrl: string) {
	}

	protected getOptions(): any {

		let headerValues = {
				'Content-Type': 'application/json'
		};

		let optionsObj: IRequestOptions = {
			method: 'get',
			//mode : 'no-cors',
			headers: headerValues
		};

		return optionsObj;
	}

	public fetchConfig() {
			let response = window.chatManagerConfigurationData.json();
			return response;
	}

	public async fetchConfigOld() {
			let response = await fetch(this.getUrl(), this.getOptions());
			return await response.json();
	}


	private getUrl(): string {
		return this.endpointUrl;
	}
}
