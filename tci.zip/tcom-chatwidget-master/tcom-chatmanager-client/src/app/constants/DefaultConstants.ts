/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T12:23:09+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-30T00:01:42+11:00
 * @Copyright: Telstra 2018
 */

export const IS_DEV: boolean = DEVLOPMENT_MODE || false;

export const APP_NAME = 'tcom-chatmanager-client';
