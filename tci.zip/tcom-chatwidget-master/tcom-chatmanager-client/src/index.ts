/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:51:36+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T11:50:16+11:00
 * @Copyright: Telstra 2018
 */

import { ChatManagerClient } from './app/controllers/chat/ChatManagerClient';

export { ChatManagerClient };
