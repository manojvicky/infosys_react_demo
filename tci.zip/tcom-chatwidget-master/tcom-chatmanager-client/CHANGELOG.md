# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.0.2"></a>
## [1.0.2](https://git02.ae.sda.corp.telstra.com/scm/lcp/tcom-chatmanager-ui/compare/v1.0.1...v1.0.2) (2019-01-23)



<a name="1.0.1"></a>
## 1.0.1 (2018-12-13)
