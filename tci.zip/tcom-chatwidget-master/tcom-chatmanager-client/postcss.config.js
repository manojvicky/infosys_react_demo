module.exports = {
  plugins: [require('autoprefixer')],
  browsers: ['> 0.25%', 'ie >= 11']
};
