/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T13:48:58+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-19T16:21:45+11:00
 * @Copyright: Telstra 2018
 */

import Main from '../../src/app/Main';
import 'jest';

jest.mock('../../src/app/controllers/chat/ChatManager');

//let mockChatInitialize = jest.fn();

describe('AppSpec', function() {
	afterEach(() => {
		jest.restoreAllMocks();
	});
	test('should initialize sucessfully', function() {
		let result: boolean = Main.bootstrap('Test');
		expect(result).toBeTruthy();
	});

	// test('should fail gracefully', function() {
	// 	ChatManager.prototype.chatInitialize = mockChatInitialize.mockImplementationOnce(() => {
	// 		throw new Error('failed');
	// 	});
	// 	let result: boolean = Main.bootstrap('Test');
	// 	expect(result).toBeFalsy();
	// });
});
