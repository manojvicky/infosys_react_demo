/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:53:06+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:45:23+11:00
 * @Copyright: Telstra 2018
 */

import { ChatManager } from '../../../../src/app/controllers/chat/ChatManager';
//import { ServiceFactory } from '../../../../src/app/services/ServiceFactory';
import { SFPropertiesService } from '../../../../src/app/services//SFPropertiesService';
import { IChatManagerConfig } from '../../../../src/app/types/IChatManagerConfig';
import { ChatUtil } from '../../../../src/app/util/ChatUtil';
import { Validator } from 'class-validator';

import 'jest';

jest.mock('../../../../src/app/services/SFPropertiesService');
jest.mock('../../../../src/app/services/LoggerService');
jest.mock('../../../../src/app/services/ChatManagerConfigService');
jest.mock('../../../../src/app/util/ChatUtil');
//jest.mock('Validator');

describe('ChatManagerSpec', function() {
	// test('should return the valid object of input settings', function() {
	// 	let mockChatInitialize = jest.fn(value => {
	// 		return value;
	// 	});
	// 	SFPropertiesService.prototype.prop = mockChatInitialize;
	//
	// 	let sFactory: ServiceFactory = new ServiceFactory();
	// 	let chatManager: ChatManager = new ChatManager(
	// 		sFactory.getPropsService(),
	// 		sFactory.getConfigService(),
	// 		sFactory.getLoggerService(),
	// 		sFactory.getChatService()
	// 	);
	// 	expect(['baseCoreUrl', 'communityEndpointUrl', 'gslbBaseUrl', 'orgId', 'eswConfigDevName']).toEqual(
	// 		chatManager.prepareInput()
	// 	);
	// });
	let chatManager: ChatManager;
	beforeEach(() => {
		chatManager = new ChatManager();
		// chatManager.envProps = Container.get(SFPropertiesService);
		// chatManager.loggerService = Container.get(LoggerService);
		// chatManager.sfService = Container.get(SalesforceChatService);
		// chatManager.configService = Container.get(ChatManagerConfigService);
	});

	test('should return the valid object from the filtered array', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		//		let sFactory: ServiceFactory = ServiceFactory.getInstance();
		let chatManager: ChatManager = new ChatManager();

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: true,
			liveagent: true,
			staticParams: ['orderId']
		};

		expect(chatManager.filterResultsForCurrentPage([inputObj], 'test123')).toEqual(inputObj);
	});

	test('should return the invalid object from the filtered array', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		//	let sFactory: ServiceFactory = ServiceFactory.getInstance();
		let chatManager: ChatManager = new ChatManager();

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: true,
			liveagent: true,
			staticParams: ['orderId']
		};

		expect(chatManager.filterResultsForCurrentPage([inputObj], 'test12345')).not.toEqual(inputObj);
	});

	// test('should call callToRenderDefaultUI successfully', function() {
	// 	let mockChatInitialize = jest.fn();
	//
	// 	chatManager.envProps.prop = mockChatInitialize.mockImplementation(() => {
	// 		return false;
	// 	});
	//
	// 	ChatManager.prototype.callToRenderDefaultUI = mockChatInitialize.mockImplementation(() => {
	// 		return false;
	// 	});
	//
	// 	const spy = jest.spyOn(chatManager, 'callToRenderDefaultUI');
	// 	chatManager.chatInitialize();
	// 	expect(spy).toHaveBeenCalled();
	// 	spy.mockRestore();
	// });

	// test('should call callToRenderCustomUI successfully', function() {
	// 	let mockChatInitialize = jest.fn();
	//
	// 	chatManager.envProps.prop = mockChatInitialize.mockImplementation(() => {
	// 		return true;
	// 	});
	//
	// 	const spy = jest.spyOn(chatManager, 'callToRenderCustomUI');
	// 	chatManager.chatInitialize();
	// 	expect(spy).toHaveBeenCalled();
	// 	spy.mockRestore();
	// });

	test('should validate the current page successfully', function() {
		let mockChatInitialize = jest.fn();

		chatManager.configService.fetchConfig = mockChatInitialize.mockImplementation(() => {
			let promise = new Promise((resolve, reject) => {});
			promise.then(res => {
				let response = {
					response: {
						data: {
							data: {
								pages: {}
							}
						}
					}
				};
				return response;
			});
			promise.catch(err => {});
			return promise;
		});

		chatManager.callToRenderCustomUI();
	});

	// test('should enable the chat successfully', function() {
	// 	let mockChatInitialize = jest.fn();
	// 	let sFactory: ServiceFactory = new ServiceFactory();
	// 	let chatManager: ChatManager = new ChatManager(
	// 		sFactory.getPropsService(),
	// 		sFactory.getConfigService(),
	// 		sFactory.getLoggerService(),
	// 		sFactory.getChatService()
	// 	);
	//
	// 	let response = {
	// 		data: {
	// 			data: {
	// 				pages: [
	// 					{
	// 						url: 'http://localhost:8082/index.html',
	// 						assetName: 'asset_name',
	// 						buttonId: '5732N000000001h',
	// 						chatEverywhere: true,
	// 						liveagent: true,
	// 						staticParams: ['orderId']
	// 					}
	// 				]
	// 			}
	// 		}
	// 	};
	//
	// 		let validator:Validator = new Validator();
	//
	// 		validator.validateSync = mockChatInitialize.mockImplementationOnce(() => {
	// 			return true;
	// 		});
	//
	// 	ChatUtil.fetchPageUrl = mockChatInitialize.mockImplementationOnce(() => {
	// 		return 'index.html';
	// 	});
	// 	chatManager.processResponse(response);
	// 	expect(chatManager.getChatEnabled()).toBeTruthy();
	// });

	test('should disable the chat if liveagent or chatEverywhere is false', function() {
		let mockChatInitialize = jest.fn();

		let response = {
			data: {
				data: {
					pages: [
						{
							url: 'http://localhost:8082/index.html',
							assetName: 'asset_name',
							buttonId: '5732N000000001h',
							chatEverywhere: true,
							liveagent: false,
							staticParams: ['orderId']
						}
					]
				}
			}
		};

		let validator: Validator = new Validator();

		validator.validateSync = mockChatInitialize.mockImplementationOnce(() => {
			return [{}];
		});

		ChatUtil.fetchPageUrl = mockChatInitialize.mockImplementationOnce(() => {
			return 'http://localhost:8082/index.html';
		});
		chatManager.processResponse(response);
		expect(chatManager.getChatEnabled()).toBeFalsy();
	});

	test('should disable the chat if the page url is not found', function() {
		let mockChatInitialize = jest.fn();

		let response = {
			data: {
				data: {
					pages: [
						{
							url: 'dummy',
							assetName: 'asset_name',
							buttonId: '5732N000000001h',
							chatEverywhere: true,
							liveagent: true,
							staticParams: ['orderId']
						}
					]
				}
			}
		};

		ChatUtil.fetchPageUrl = mockChatInitialize.mockImplementationOnce(() => {
			return 'http://localhost:8082/index.html';
		});
		chatManager.processResponse(response);
		expect(chatManager.getChatEnabled()).toBeFalsy();
	});

	test('should disable while proble reading the chatManager config', function() {
		let mockChatInitialize = jest.fn();

		let response = {
			data: {
				data: {}
			}
		};
		ChatUtil.fetchPageUrl = mockChatInitialize.mockImplementationOnce(() => {
			return 'http://localhost:8082/index.html';
		});
		chatManager.processResponse(response);
		expect(chatManager.getChatEnabled()).toBeFalsy();
	});

	test('should return the validate chat access for chatEverywhere, liveagent', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: true,
			liveagent: true,
			staticParams: ['orderId']
		};

		expect(chatManager.validateChatAccess(inputObj)).toBeTruthy();
	});

	test('should return the validate chat access when liveagent is false', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: true,
			liveagent: false,
			staticParams: ['orderId']
		};

		expect(chatManager.validateChatAccess(inputObj)).toBeFalsy();
	});

	test('should return the validate chat access when chatEverywhere is false', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: false,
			liveagent: true,
			staticParams: ['orderId']
		};

		expect(chatManager.validateChatAccess(inputObj)).toBeFalsy();
	});

	test('should return the validate chat access when both liveagent, chatEverywhere are false', function() {
		let mockChatInitialize = jest.fn(value => {
			return value;
		});
		SFPropertiesService.prototype.prop = mockChatInitialize;

		let inputObj: IChatManagerConfig = {
			url: 'test123',
			assetName: 'asset_name',
			buttonId: '5732N000000001h',
			chatEverywhere: false,
			liveagent: false,
			staticParams: ['orderId']
		};

		expect(chatManager.validateChatAccess(inputObj)).toBeFalsy();
	});
});
