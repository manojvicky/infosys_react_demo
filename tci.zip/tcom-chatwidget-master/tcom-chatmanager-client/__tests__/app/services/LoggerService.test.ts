/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-30T14:37:09+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:44:08+11:00
 * @Copyright: Telstra 2018
 */

import { LoggerService } from '../../../src/app/services/LoggerService';
import { ServiceFactory } from '../../../src/app/services/ServiceFactory';
import * as log from 'loglevel';
import 'jest';

describe('LoggerServiceSpec', function() {
	test('should initialise logger service successfully', function() {
		let chatService: LoggerService = ServiceFactory.getInstance().getLoggerService();
		expect(chatService).toBeDefined();
	});

	test('should invoke info successfully', function() {
		let chatService: LoggerService = ServiceFactory.getInstance().getLoggerService();
		const spy = jest.spyOn(log, 'info');
		chatService.info('test');
		expect(spy).toHaveBeenCalled();
		spy.mockRestore();
	});

	test('should invoke warn successfully', function() {
		let chatService: LoggerService = ServiceFactory.getInstance().getLoggerService();
		const spy = jest.spyOn(log, 'warn');
		chatService.warn('test');
		expect(spy).toHaveBeenCalled();
		spy.mockRestore();
	});

	test('should invoke error successfully', function() {
		let chatService: LoggerService = ServiceFactory.getInstance().getLoggerService();
		const spy = jest.spyOn(log, 'error');
		chatService.error('test', 'err');
		expect(spy).toHaveBeenCalled();
		spy.mockRestore();
	});
});
