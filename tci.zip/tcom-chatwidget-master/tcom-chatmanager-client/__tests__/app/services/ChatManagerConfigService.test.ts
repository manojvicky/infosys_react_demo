/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-30T01:34:22+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:43:46+11:00
 * @Copyright: Telstra 2018
 */

import { ChatManagerConfigService } from '../../../src/app/services/ChatManagerConfigService';
import 'jest';

describe('ChatManagerConfigService', function() {
	test('init should return the valid httpClient object', function() {
		let cmConfig = new ChatManagerConfigService();
		cmConfig.prepareHttpClient();
		expect(cmConfig._httpClient).toBeDefined();
	});

	// TODO: the promise needs be mocked
	// test('fetchConfig should return the valid Promise object', () => {
	// 	let cmConfig = new ChatManagerConfigService();
	// 	return cmConfig.fetchConfig().then(data => {
	// 		expect(data);
	// 	});
	// });
});
