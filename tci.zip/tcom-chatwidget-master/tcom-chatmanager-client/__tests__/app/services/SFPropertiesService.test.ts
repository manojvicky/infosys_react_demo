/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-21T14:02:09+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:45:03+11:00
 * @Copyright: Telstra 2018
 */

import { SFPropertiesService } from '../../../src/app/services/SFPropertiesService';
import 'jest';

describe('SFPropertiesService', function() {
	test('init should return the valid httpClient object', function() {
		let propServices = new SFPropertiesService();
		(<any>propServices)._configurationProperties['baseCoreUrl'] = 'test-baseCoreUrl';
		(<any>propServices)._configurationProperties['communityEndpointUrl'] = 'test-communityEndpointUrl';
		(<any>propServices)._configurationProperties['baseLiveAgentContentURL'] = 'test-baseLiveAgentContentURL';
		(<any>propServices)._configurationProperties['gslbBaseUrl'] = 'test-gslbBaseUrl';
		(<any>propServices)._configurationProperties['orgId'] = 'test-orgId';

		expect(propServices.prop('baseCoreUrl')).toEqual('test-baseCoreUrl');
		expect(propServices.prop('communityEndpointUrl')).toEqual('test-communityEndpointUrl');
		expect(propServices.prop('baseLiveAgentContentURL')).toEqual('test-baseLiveAgentContentURL');
		expect(propServices.prop('gslbBaseUrl')).toEqual('test-gslbBaseUrl');
		expect(propServices.prop('orgId')).toEqual('test-orgId');
	});
});
