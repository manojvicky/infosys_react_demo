/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-20T15:49:01+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:44:50+11:00
 * @Copyright: Telstra 2018
 */

import { SalesforceChatService } from '../../../src/app/services/SalesforceChatService';
import { ServiceFactory } from '../../../src/app/services/ServiceFactory';
import { ISFSettingsConfig } from '../../../src/app/types/ISFSettingsConfig';
import { SalesforceChatModel } from '../../../src/app/models/SalesforceChatModel';
import 'jest';

let mockChatInitialize = jest.fn();

describe('SalesforceChatServiceSpec', function() {
	let chatService: SalesforceChatService;

	beforeEach(() => {
		let sfModel: SalesforceChatModel = new SalesforceChatModel();
		sfModel.baseCoreUrl = 'test';
		sfModel.communityEndpointUrl = 'test';
		sfModel.gslbBaseUrl = 'test';
		sfModel.orgId = 'test';
		sfModel.eswConfigDevName = 'test';

		sfModel.baseLiveAgentContentURL = 'test';
		sfModel.deploymentId = 'test';
		sfModel.buttonId = 'test';
		sfModel.baseLiveAgentURL = 'test';
		sfModel.eswLiveAgentDevName = 'test';
		sfModel.isOfflineSupportEnabled = false;

		sfModel.language = 'test';
		sfModel.targetElement = 'test';
		sfModel.displayHelpButton = true;
		sfModel.enabledFeatures = ['test'];
		sfModel.entryFeature = 'test';
		sfModel.defaultMinimizedText = 'test';

		sfModel.assetName = 'test';
		sfModel.chatEverywhere = true;
		sfModel.liveagent = true;
		sfModel.staticParams = ['test'];
		sfModel.url = 'test';

		chatService = ServiceFactory.getInstance().getChatService();
		chatService.setSalesforceChatModel(sfModel);
	});
	test('should load the settings successfully', function() {
		chatService.loadSettings();
		let settings: ISFSettingsConfig = (<any>chatService)._settings;
		expect(settings).toBeDefined();
	});

	test('should load the additional settings successfully', function() {
		chatService.loadAdditionalSettings();
		let additonalSettings: ISFSettingsConfig = (<any>chatService)._additionalSettings;
		expect(additonalSettings).toBeDefined();
	});

	test('should call the init method successfully', function() {
		let result: boolean = false;

		(<any>chatService)._sfChatEmbdObj.init = mockChatInitialize.mockImplementationOnce(() => {
			result = true;
		});

		chatService.invoke();
		expect(result).toBeTruthy();
	});

	test('should call the fetchStaticParams method successfully', function() {
		document.getElementById = mockChatInitialize.mockImplementationOnce(() => {
			return {
				value: 'test'
			};
		});
		let responseObj = chatService.fetchStaticParams();
		expect(responseObj).toBeDefined();
		expect(responseObj).toEqual({ test: 'test' });
	});

	test('should call the fetchStaticParams method fail gracefully', function() {
		document.getElementById = mockChatInitialize.mockImplementationOnce(() => {
			throw new Error();
		});
		let responseObj = chatService.fetchStaticParams();
		expect(responseObj).toBeDefined();
		expect(responseObj).toEqual({});
	});

	test('should call the fetchStaticParams method successfully', function() {
		document.getElementById = mockChatInitialize.mockImplementationOnce(() => {
			return {
				value: 'test'
			};
		});
		let responseObj = chatService.prepareEngagementParams();
		expect(responseObj).toBeDefined();
		expect(responseObj).toEqual('{"chatData":{"assetName":"test","test":"test"}}');
	});

	// TODO:  Assertion needs to be modified.
	// test('should handle the exception when init method fails', function() {
	//
	// 	(<any>chatService)._sfChatEmbdObj.init = mockChatInitialize.mockImplementationOnce(() => {
	// 		throw new Error('Failed');
	// 	});
	//
	// 	expect(chatService.invoke()).not.toBeDefined();
	// });
});
