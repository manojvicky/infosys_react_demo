import { addDecorator, configure, setAddon, addParameters } from '@storybook/react';
import { setConsoleOptions } from '@storybook/addon-console';
import { withOptions } from '@storybook/addon-options';
import { themes } from '@storybook/components';
import { INITIAL_VIEWPORTS } from '@storybook/addon-viewport';
import { infoAddon } from '@storybook/addon-info';
import { withA11y } from '@storybook/addon-a11y';
import { create } from '@storybook/theming';

import './storybook.css';

window.DEVLOPMENT_MODE=false;

addParameters({
	options: {
		theme: create({
			base: 'dark',
			brandTitle: 'Chat Custom Widget',
			brandImage: './logo-telstra.svg',
			brandUrl: 'https://git02.ae.sda.corp.telstra.com/projects/LCP/repos/tcom-chatmanager-ui/browse',
		}),
		hierarchySeparator: /\//,
		hierarchyRootSeparator: /\|/,
    sortStoriesByKind: true,
    showSearchBox: false,
    isFullScreen: false,
    panelPosition: 'right',
    enableShortcuts: true
	},
  viewport: {
    defaultViewport: 'iphone6'
  }
});

addDecorator(withA11y);

setConsoleOptions({
	panelExclude: [],
});

function loadStories() {
	require('../src/styles/style.scss');
	const req = require.context('../src', true, /(stories|story)\.jsx$/);
	req.keys().forEach(filename => req(filename));
}

setAddon(infoAddon);

configure(loadStories, module);
