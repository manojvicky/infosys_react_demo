const webpack = require('webpack');
const path = require('path');
const webpackOverride = require('../webpack/webpack.dev.js');
const CopyWebpackPlugin = require('copy-webpack-plugin');


module.exports =  ({ config, mode }) => {

	config.module.rules.push({
				test: /\.s[ac]ss$/,
				loader: 'style-loader!css-loader!sass-loader?includePaths[]=./node_modules',
				include: path.resolve(__dirname, '../src')
	});


	config.module.rules = config.module.rules.filter(({ loader }) => !/json-loader/.test(loader));


	config.module.rules.push({
				test: /\.svg$/,
				loader: 'svg-react-loader'
	});

	config.module.rules.push({
        test: /\.(jpg|png|gif|eot|svg|ttf|woff|woff2)$/,
        loader: 'file-loader',
        include: path.resolve(__dirname, '../'),
				exclude: /\.svg$/,
  });

	config.module.rules.push({
		test: /\.(ts|tsx)?$/,
		exclude: /node_modules/,
		include: [/stories/, /src/],
		loader: 'awesome-typescript-loader'
	});

	config.module.rules.push({
		test: /\.js?$/,
		use: 'source-map-loader',
		enforce: 'pre'
	});

	// config.module.rules.push({
  //       test: /\.js$/,
  //       exclude: /node_modules/,
  //       loader: 'babel-loader',
  //       query: {
  //         plugins:[ 'transform-object-rest-spread' ]
  //       }
  //     });

	config.resolve.extensions.push('.ts', '.tsx', 'js');

	config.resolve.alias = webpackOverride.resolve.alias;

	config.plugins.push(new CopyWebpackPlugin([
		{ from: 'src/assets/icons/*', to: 'icons', flatten: true },
		{ from: 'src/assets/audio/*', to: 'audio', flatten: true }
	]));

	return config;
};
