/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-03T13:55:52+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T11:15:48+11:00
 * @Copyright: Telstra 2018
 */

import 'jest';

jest.mock('../src/app/Main');

describe('SalesforceChat', () => {
	it('SalesForceChat should invoke bootstrap successfully', () => {
		expect(true).toBeTruthy();
	});
});
