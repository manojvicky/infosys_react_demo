/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T13:48:58+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-19T16:21:45+11:00
 * @Copyright: Telstra 2018
 */

import 'jest';

describe('AppSpec', function() {
	afterEach(() => {
		jest.restoreAllMocks();
	});
	test('should initialize sucessfully', function() {
		expect(true).toBeTruthy();
	});
});
