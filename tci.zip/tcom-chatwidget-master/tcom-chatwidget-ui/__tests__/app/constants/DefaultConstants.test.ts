/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T12:23:09+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:45:57+11:00
 * @Copyright: Telstra 2018
 */

import { APP_NAME, IS_DEV } from '../../../src/app/constants/DefaultConstants';
import 'jest';

// NOTE: Units tests are not required for constants.
describe('DefaultConstantsSpec', function() {
	test('should import the constants', function() {
		expect(APP_NAME).toEqual('tcom-chatwidget-ui');
	});
});

describe('DefaultConstantsSpec', function() {
	test('DEVLOPMENT_MODE should be false', function() {
		expect(IS_DEV).toBeFalsy();
	});
});
