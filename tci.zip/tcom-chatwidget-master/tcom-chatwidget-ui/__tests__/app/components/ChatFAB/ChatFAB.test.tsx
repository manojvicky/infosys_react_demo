import * as React from 'react';
import { mount, shallow } from 'enzyme';
import 'jest';
import { ChatFAB } from '../../../../src/app/components/ChatFAB/ChatFAB.ui';

let props;
let mountedChatFAB;

const fab = () => {
	if (!mountedChatFAB) {
		mountedChatFAB = mount(<ChatFAB {...props} />);
	}
	return mountedChatFAB;
};

describe('renders the fab', () => {
	describe('renders ChatFab Component', () => {
		beforeEach(() => {
			props = {};
			mountedChatFAB = undefined;
		});

		test('should render the Chat FAB', function() {
			fab();
			expect(mountedChatFAB).toBeDefined();
		});
	});

	describe('ChatFAB render function ', () => {
		test('Desktop View, stat: MAXIMIZE', function() {
			fab();
			props = {
				...props,
				status: 'MAXIMIZE'
			};

			const wrapper = mount<ChatFAB>(<ChatFAB {...props} />);
			const instance = wrapper.instance();
			instance.isMobileFlag = false;
			instance.renderFAB = jest.fn();
			instance.renderMininizedFAB = jest.fn();
			instance.render();
			expect(instance.renderMininizedFAB).not.toBeCalled();
			expect(instance.renderFAB).toBeCalled();
		});
	});

	test('Desktop View, stat: MINIMIZE', function() {
		fab();
		props = {
			...props,
			status: 'MINIMIZE'
		};
		const wrapper = mount<ChatFAB>(<ChatFAB {...props} />);
		const instance = wrapper.instance();
		instance.isMobileFlag = false;
		instance.renderFAB = jest.fn();
		instance.renderMininizedFAB = jest.fn();
		instance.render();
		expect(instance.renderMininizedFAB).toBeCalled();
		expect(instance.renderFAB).not.toBeCalled();
	});

	test('Mobile View, stat: MINIMIZE', function() {
		fab();
		props = {
			...props,
			status: 'MINIMIZE'
		};
		const wrapper = mount<ChatFAB>(<ChatFAB {...props} />);
		const instance = wrapper.instance();
		instance.isMobileFlag = true;
		instance.renderFAB = jest.fn();
		instance.renderMininizedFAB = jest.fn();
		instance.render();
		expect(instance.renderMininizedFAB).not.toBeCalled();
		expect(instance.renderFAB).toBeCalled();
	});

	describe('ChatFAB renderFAB function ', () => {
		test('should render with chatHeaderTitle', function() {
			fab();
			props = {
				...props,
				chatHeaderTitle: 'chatHeaderTitle',
				status: 'MAXIMIZE'
			};
			const wrapper = shallow<ChatFAB>(<ChatFAB {...props} />);
			const instance = wrapper.instance();
			console.log(instance.renderFAB());
			expect(instance.renderFAB().type).toEqual('button');
			expect(instance.renderFAB().props.className).toEqual('telstra-lpa-chat--fab bottom-right');
		});
	});

	describe('ChatFAB renderMinimizedFAB function ', () => {
		test('should render with chatHeaderTitle', function() {
			fab();
			props = {
				...props,
				chatHeaderTitle: 'chatHeaderTitle',
				status: 'MAXIMIZE'
			};
			const wrapper = shallow<ChatFAB>(<ChatFAB {...props} />);
			const instance = wrapper.instance();
			console.log(instance.renderMininizedFAB());
			expect(instance.renderMininizedFAB().type).toEqual('div');
			expect(instance.renderMininizedFAB().props.className).toEqual('telstra-lpa-chat--fab-wrapper bottom-right');
		});
	});
});
