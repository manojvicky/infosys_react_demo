import * as React from 'react';
import { mount, shallow } from 'enzyme';
import 'jest';
import { ChatConnect } from '../../../../src/app/components/ChatConnect/ChatConnect.ui';

let props;
let mountedChatConnect;

const connect = () => {
	if (!mountedChatConnect) {
		mountedChatConnect = mount(<ChatConnect {...props} />);
	}
	return mountedChatConnect;
};

describe('ChatConnect Tests', () => {
	describe('renders ChatConnect Component', () => {
		beforeEach(() => {
			props = {
				connectToChat: () => {}
			};
			mountedChatConnect = undefined;
		});
		test('should render the Chat Connect', function() {
			connect();
			expect(mountedChatConnect).toBeDefined();
		});
	});

	describe('renders ChatConnect', () => {
		beforeEach(() => {
			props = {
				connectToChat: () => {}
			};
			mountedChatConnect = undefined;
		});

		test('connectionStatus: PENDING', function() {
			connect();
			props = {
				...props,
				connectionStatus: 'PENDING'
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).toBeCalled();
			expect(instance.renderFailure).not.toBeCalled();
			expect(instance.renderNoAgents).not.toBeCalled();
			expect(instance.renderQueuing).not.toBeCalled();
			expect(instance.renderNone).not.toBeCalled();
		});

		test('connectionStatus: SUCCESS', function() {
			connect();
			props = {
				...props,
				connectionStatus: 'SUCCESS'
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).not.toBeCalled();
			expect(instance.renderFailure).not.toBeCalled();
			expect(instance.renderNoAgents).not.toBeCalled();
			expect(instance.renderQueuing).not.toBeCalled();
			expect(instance.renderNone).toBeCalled();
		});

		test('connectionStatus: FAILURE', function() {
			connect();
			props = {
				...props,
				connectionStatus: 'FAILURE'
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).not.toBeCalled();
			expect(instance.renderFailure).toBeCalled();
			expect(instance.renderNoAgents).not.toBeCalled();
			expect(instance.renderQueuing).not.toBeCalled();
			expect(instance.renderNone).not.toBeCalled();
		});

		test('connectionStatus: NO_AGENTS', function() {
			connect();
			props = {
				...props,
				connectionStatus: 'NO_AGENTS'
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).not.toBeCalled();
			expect(instance.renderFailure).not.toBeCalled();
			expect(instance.renderNoAgents).toBeCalled();
			expect(instance.renderQueuing).not.toBeCalled();
			expect(instance.renderNone).not.toBeCalled();
		});

		test('connectionStatus: QUEUED', function() {
			connect();
			props = {
				...props,
				connectionStatus: 'QUEUED'
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).not.toBeCalled();
			expect(instance.renderFailure).not.toBeCalled();
			expect(instance.renderNoAgents).not.toBeCalled();
			expect(instance.renderQueuing).toBeCalled();
			expect(instance.renderNone).not.toBeCalled();
		});
		// Is this correct?
		test('connectionStatus: unprovided', function() {
			connect();
			props = {
				...props,
				connectionStatus: ''
			};
			const wrapper = mount<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading = jest.fn();
			instance.renderFailure = jest.fn();
			instance.renderNoAgents = jest.fn();
			instance.renderQueuing = jest.fn();
			instance.renderNone = jest.fn();
			instance.render();
			expect(instance.renderLoading).not.toBeCalled();
			expect(instance.renderFailure).not.toBeCalled();
			expect(instance.renderNoAgents).not.toBeCalled();
			expect(instance.renderQueuing).not.toBeCalled();
			expect(instance.renderNone).toBeCalled();
		});
	});

	describe('ChatConnect renderLoading function', () => {
		test('should render Chat Connect Pending', function() {
			connect();
			props = {
				...props,
				connectWelcomeMessage: 'connectWelcomeMessage',
				connectMessage: 'connectMessage',
				connectionStatus: 'PENDING'
			};
			const wrapper = shallow<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderLoading();
			expect(wrapper.contains(<div className="loader-round" />)).toBe(true);
			expect(wrapper.find('span.header-text').text()).toEqual('connectWelcomeMessage');
			expect(wrapper.find('span.body-text').text()).toEqual('connectMessage');
		});
	});

	describe('ChatConnect renderFailure function', () => {
		test('should render Chat Connect Failure', function() {
			connect();
			props = {
				...props,
				connectionFailureIcon: 'connectionFailureIcon',
				connectionFailureTitle: 'connectionFailureTitle',
				connectionFailureMessage: 'connectionFailureMessage',
				connectionFailureSubMessage: 'connectionFailureSubMessage',
				connectionStatus: 'FAILURE'
			};
			const wrapper = shallow<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderFailure();
			expect(wrapper.find('img').props().src).toEqual('connectionFailureIcon');
			expect(wrapper.find('span.header-text').text()).toEqual('connectionFailureTitle');
			expect(wrapper.find('span.body-text').text()).toEqual('connectionFailureMessage');
			expect(wrapper.find('span.body-sub-text').text()).toEqual('connectionFailureSubMessage');
		});
	});

	describe('ChatConnect renderNoAgents function', () => {
		test('should render Chat Connect No Agents', function() {
			connect();
			props = {
				...props,
				noAgentIcon: 'noAgentIcon',
				noAgentTitle: 'noAgentTitle',
				noAgentMessage: 'noAgentMessage',
				connectionStatus: 'NO_AGENTS'
			};
			const wrapper = shallow<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderNoAgents();
			expect(wrapper.find('img').props().src).toEqual('noAgentIcon');
			expect(wrapper.find('span.header-text').text()).toEqual('noAgentTitle');
			expect(wrapper.find('span.body-text').text()).toEqual('noAgentMessage');
		});
	});

	describe('ChatConnect renderQueuing function', () => {
		test('should render Chat Connect Queuing', function() {
			connect();
			props = {
				...props,
				queueIcon: 'queueIcon',
				queueHeader: 'queueHeader',
				queueMessage: 'queueMessage',
				connectionStatus: 'QUEUED'
			};
			const wrapper = shallow<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderQueuing();
			expect(wrapper.find('img').props().src).toEqual('queueIcon');
			expect(wrapper.find('span.header-text').text()).toEqual('queueHeader');
			expect(wrapper.find('span.body-text').text()).toEqual('queueMessage');
		});
	});

	describe('ChatConnect renderNone function', () => {
		test('should render Chat Connect None', function() {
			connect();
			props = {
				...props,
				connectionStatus: ''
			};
			const wrapper = shallow<ChatConnect>(<ChatConnect {...props} />);
			const instance = wrapper.instance();
			instance.renderNone();
			expect(wrapper.type()).toEqual(null);
		});
	});
});
