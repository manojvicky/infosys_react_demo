import * as React from 'react';
import { mount } from 'enzyme';
import 'jest';

import { ChatAnnouncement } from '../../../../src/app/components/ChatAnnouncement/ChatAnnouncement.ui';

describe('renders the Chat Announcement', () => {
	let props;
	let mountedChatAnnouncement;

	const announcement = () => {
		if (!mountedChatAnnouncement) {
			mountedChatAnnouncement = mount(<ChatAnnouncement {...props} />);
		}
		return mountedChatAnnouncement;
	};

	beforeEach(() => {
		props = {};
		mountedChatAnnouncement = undefined;
	});

	test('should render the Chat Announcement', function() {
		announcement();
		expect(mountedChatAnnouncement).toBeDefined();
	});
});
