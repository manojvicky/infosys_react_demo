import { Reducer } from 'redux';
import { ChatEndState } from '../state/ApplicationState';
import { ChatEndActionTypes } from '../actions/ChatActionTypes';

const reducer: Reducer<ChatEndState> = (state = {}, action) => {
	switch (action.type) {

		case ChatEndActionTypes.CHAT_PRE_END: {
			return {
				...state,
				chatEndStatus: action.payload.chatEndStatus
			};
		}
		case ChatEndActionTypes.CHAT_END_REQUEST: {
			return {
				...state
			};
		}
		case ChatEndActionTypes.CHAT_END_SUCCESS: {
			return {
				...state
			};
		}
		case ChatEndActionTypes.CHAT_END_FAILURE: {
			return {
				...state
			};
		}
		default: {
			return state;
		}
	}
};

export { reducer as chatEndReducer };
