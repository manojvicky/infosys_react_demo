import { Reducer } from 'redux';
import { ChatEntryState } from '../state/ApplicationState';
import { ChatEntryActionTypes } from '../actions/ChatActionTypes';

const reducer: Reducer<ChatEntryState> = (state = {}, action) => {
	switch (action.type) {
		case ChatEntryActionTypes.CHAT_ENABLE: {
			return {
				...state,
				status: action.payload.status,
				slideout: action.payload.slideout,
				slideOutTitle: action.payload.slideOutTitle,
				slideOutBody: action.payload.slideOutBody,
				slideOutButtonText: action.payload.slideOutButtonText,
				slideOutScrollHeight: action.payload.slideOutScrollHeight,
				fabTitle: action.payload.fabTitle,
				fabIcon: action.payload.fabIcon,
				fabBackGroundColor: action.payload.fabBackGroundColor
			};
		}
		case ChatEntryActionTypes.CHAT_OPEN: {
			return { ...state, status: action.payload };
		}
		case ChatEntryActionTypes.CLOSE_SLIDEOUT: {
			return { ...state, slideout: action.payload };
		}
		case ChatEntryActionTypes.CHAT_MINIMIZE: {
			return {
				...state,
				status: action.payload
			};
		}
		case ChatEntryActionTypes.CHAT_OPEN_SLIDEOUT: {
			return { ...state, status: action.payload.status, slideout: action.payload.slideout };
		}
		case ChatEntryActionTypes.UPDATE_FAB_HEADER: {
			return {
				...state,
				fabMinimizedTitle: action.payload.fabMinimizedTitle
			};
		}
		default: {
			return state;
		}
	}
};

export { reducer as chatEntryReducer };
