import { chatEntryReducer } from './ChatEntryReducer';
import { chatSessionReducer } from './ChatSessionReducer';
import { chatEndReducer } from './ChatEndReducer';
import { combineReducers } from 'redux';
import { ApplicationState } from '../state/ApplicationState';
import { ChatGlobalActionTypes } from '../actions/ChatActionTypes';
import { Reducer } from 'redux';
import { initialState } from '../state/InitialState';

export const appReducer = combineReducers<ApplicationState>({
	chatEntry: chatEntryReducer,
	chatSession: chatSessionReducer,
	chatEnd: chatEndReducer
});

export const rootReducer: Reducer<ApplicationState> = (state, action) => {
	if (action.type === ChatGlobalActionTypes.CHAT_RESET) {
    state = initialState
  }else if (action.type === ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE) {
	    state = action.payload
	  }
  return appReducer(state, action)
}
