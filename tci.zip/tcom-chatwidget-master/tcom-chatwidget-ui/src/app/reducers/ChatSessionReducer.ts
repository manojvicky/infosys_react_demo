import { Reducer } from 'redux';
import { ChatSessionState } from '../state/ApplicationState';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';

const reducer: Reducer<ChatSessionState> = (state = {}, action) => {
	switch (action.type) {
		case ChatSessionActionTypes.CHAT_ENABLE: {
			return {
				...state,
				announcement: action.payload.announcement,
				announcementText: action.payload.announcementText,
				announcementLinkText: action.payload.announcementLinkText,
				announcementLink: action.payload.announcementLink,
				announcementLinkOpenNewTab: action.payload.announcementLinkOpenNewTab,
				connectWelcomeMessage: action.payload.connectWelcomeMessage,
				connectMessage: action.payload.connectMessage,
				connectionFailureTitle: action.payload.connectionFailureTitle,
				connectionFailureMessage: action.payload.connectionFailureMessage,
				connectionFailureIcon: action.payload.connectionFailureIcon,
				noAgentTitle: action.payload.noAgentTitle,
				noAgentMessage: action.payload.noAgentMessage,
				noAgentIcon: action.payload.noAgentIcon,
				chatEndedMsg: action.payload.chatEndedMsg,
				buttonId: action.payload.buttonId,
				organizationId: action.payload.organizationId,
				deploymentId: action.payload.deploymentId,
				queueHeader: action.payload.queueHeader,
				queueIcon: action.payload.queueIcon,
				queueMessage: action.payload.queueMessage,
				queueSubMessage: action.payload.queueSubMessage,
				welcomeMessage: action.payload.welcomeMessage,
				transferMessage: action.payload.transferMessage,
				endChatMessage: action.payload.endChatMessage,
				endChatByAgentMessage: action.payload.endChatByAgentMessage,
			};
		}
		case ChatSessionActionTypes.CLOSE_ANNOUNCEMENT: {
			return { ...state, closeAnnouncement: action.payload.closeAnnouncement };
		}
		case ChatSessionActionTypes.CHAT_ERROR: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus
			}
		}
		case ChatSessionActionTypes.UPDATE_CHAT_HEADER: {
			return {
				...state,
				chatHeaderTitle: action.payload.chatHeaderTitle,
				agentName: action.payload.agentName
			};
		}
		case ChatSessionActionTypes.CHAT_LOAD_SESSION: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				fabMinimizedTitle: action.payload.fabMinimizedTitle,
				chatHeaderTitle: action.payload.chatHeaderTitle,
				messages: action.payload.messages
			};
		}
		case ChatSessionActionTypes.CHAT_SESSION_REQUEST: {
			return {
				...state
			};
		}
		case ChatSessionActionTypes.CHAT_SESSION_SUCCESS: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				sessionId: action.payload.sessionId,
				sessionKey: action.payload.sessionKey,
				affinityToken: action.payload.affinityToken
			};
		}
		case ChatSessionActionTypes.CHAT_SESSION_FAILURE: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				chatHeaderTitle: action.payload.chatHeaderTitle
			};
		}
		case ChatSessionActionTypes.CHAT_INIT_REQUEST: {
			return {
				...state
			};
		}
		case ChatSessionActionTypes.CHAT_INIT_SUCCESS: {
			return {
				...state
			};
		}
		case ChatSessionActionTypes.CHAT_INIT_FAILURE: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				chatHeaderTitle: action.payload.chatHeaderTitle
			};
		}
		case ChatSessionActionTypes.CHAT_MESSAGES_PROCESS: {
			return {
				...state,
				messages: action.payload.messages,
				connectionStatus: action.payload.connectionStatus
			};
		}
		case ChatSessionActionTypes.CHAT_MESSAGES_FAILURE: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				chatHeaderTitle: action.payload.chatHeaderTitle
			};
		}
		case ChatSessionActionTypes.CHAT_MESSAGES_NO_AGENT: {
			return {
				...state,
				connectionStatus: action.payload.connectionStatus,
				chatHeaderTitle: action.payload.chatHeaderTitle
			};
		}
		case ChatSessionActionTypes.ADD_MESSAGE: {
			return {
				...state,
				messages: action.payload.messages
			};
		}
		case ChatSessionActionTypes.SHOW_TYPING_INDICATOR: {
			return {
				...state,
				showTypingIndicator: action.payload.showTypingIndicator
			};
		}
		case ChatSessionActionTypes.UPDATE_QUEUE_POSITION: {
			return {
				...state,
				isInQueue: action.payload.isInQueue,
				queueNum: action.payload.queueNum,
				connectionStatus: action.payload.connectionStatus
			};
		}
		case ChatSessionActionTypes.UPDATE_UNREAD_COUNTER: {
			return {
				...state,
				messageMetadata: action.payload.messageMetadata
			};
		}

		case ChatSessionActionTypes.PLAY_ALERT_AUDIO: {
			return{
				...state,
				play: action.payload.play
			}
		}
		case ChatSessionActionTypes.INCREMENT_ACK: {
			return {
				...state,
				ack: action.payload.ack
			};
		}
		case ChatSessionActionTypes.INCREMENT_PC: {
			return {
				...state,
				pc: action.payload.pc
			};
		}
		case ChatSessionActionTypes.INCREMENT_SEQ: {
			return {
				...state,
				sequenceNumber: action.payload.sequenceNumber
			};
		}
		case ChatSessionActionTypes.CHAT_MESSAGES_METADATA: {
			return {
				...state,
				messageMetadata: action.payload.messageMetadata
			};
		}
		case ChatSessionActionTypes.INCOMING_SEQUENCE: {
			return {
				...state,
				incomingMessagesSequence: action.payload.incomingMessagesSequence
			};
		}
		case ChatSessionActionTypes.CHAT_RETRIEVE_SURVEY: {
			return {
				...state,
				surveyObj: action.payload.surveyObj
			}
		}
		case ChatSessionActionTypes.SURVEY_AVAILABILITY: {
			return {
				...state,
				surveyAvailability: action.payload.surveyAvailability
			}
		}
		case ChatSessionActionTypes.SURVEY_SUBMITTED: {
			return {
				...state,
				submittedSurvey: action.payload.submittedSurvey
			}
		}
		case ChatSessionActionTypes.UPDATE_SENSITIVE_RULES: {
			return {
				...state,
				sensitiveDataRules: action.payload.sensitiveDataRules
			}
		}
		default: {
			return state;
		}
	}
};

export { reducer as chatSessionReducer };
