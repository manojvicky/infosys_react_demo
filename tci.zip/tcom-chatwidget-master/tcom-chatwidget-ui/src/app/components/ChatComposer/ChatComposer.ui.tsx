import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX, MAX_ROW_COUNT, MIN_ROW_HEIGHT, AVG_ROW_HEIGHT, MIN_ROW_COUNT, RESET_HEIGHT, MAX_TEXT_COUNT } from '@cm-constants/DefaultConstants';
import { Scrollbars } from 'react-custom-scrollbars';

import { TAB_INDEX_ORDER } from '../../constants/DefaultConstants';

interface ChatComposerProps {
	placeHolderText?: string;
	composerIcon?: string;
	composerInactiveIcon?: string;
	postMessage: (event: any) => void;
	postMessageOnClick: (message: any) => void;
	postChasitorTyping: () => void;
	postChasitorNotTyping: () => void;
}

interface ChatComposerStates {
	rows: number;
	disableButton: boolean;
	currentHeight: number;
	alreadyPostedTyping: boolean
}

export class ChatComposer extends React.Component<ChatComposerProps, ChatComposerStates> {
	messageRef: any;
	constructor(props: any) {
		super(props);
		this.state = {
			rows: MIN_ROW_COUNT,
			disableButton: true,
			currentHeight: RESET_HEIGHT,
			alreadyPostedTyping: false,
		}
	}

	componentDidMount(){
		this.setState({
      rows: MIN_ROW_COUNT
    });
	}

	handleOnClick() {
		this.props.postMessageOnClick(this.messageRef);
		this.setState({
			disableButton: true,
			rows: MIN_ROW_COUNT,
			currentHeight: RESET_HEIGHT,
			alreadyPostedTyping: false
		})
	}


	handleOnKeyDown(e) {
		if (e.key === 'Enter' && e.shiftKey === false){
			this.props.postMessage(e)
			this.setState({
				disableButton: true,
				rows: MIN_ROW_COUNT,
				currentHeight: RESET_HEIGHT,
				alreadyPostedTyping: false
			})
		}
	}

	handleChange = (event) => {
		const oneLineHeight = MIN_ROW_HEIGHT;
		const twoLinesHeight = 69;
		const previousRows = event.target.rows;
  	event.target.rows = MIN_ROW_COUNT; 

		let currentRows
		if (event.target.scrollHeight === oneLineHeight ){
			currentRows =  1
		} else if (event.target.scrollHeight === twoLinesHeight) {
			currentRows =  2
		} else {
			currentRows =  ~~(event.target.scrollHeight / AVG_ROW_HEIGHT)
		}

    if (currentRows === previousRows) {
    	event.target.rows = currentRows;
    }
		
		if (currentRows >= MAX_ROW_COUNT) {
			event.target.rows = MAX_ROW_COUNT;
			event.target.scrollTop = event.target.scrollHeight;
		}

		let pureText = event.target.value.replace(/(\r\n|\n|\r)/gm, "")

		if (pureText.length > 0 && this.state.alreadyPostedTyping === false) {
			this.props.postChasitorTyping()
			this.setState({
				alreadyPostedTyping : true
			})
		} else if(pureText.length === 0){
			this.props.postChasitorNotTyping()
			this.setState({
				alreadyPostedTyping: false
			})
		} else {
		}

  	this.setState({
			rows:  currentRows,
			disableButton: pureText.length > 0 ? false : true,
			currentHeight: event.target.scrollHeight,
    });
	};

	public render() {
		const maxComposerHeight = 127
		return (
			<div className={classNames(CSS_PREFIX + '-composer')}>
			<Scrollbars style={{ height: (this.state.currentHeight >= maxComposerHeight) ? maxComposerHeight : this.state.currentHeight + 10,  width: 'calc(100% - 45px)' }} renderThumbVertical={({ style, ...props }) =>
            <div tabIndex={TAB_INDEX_ORDER.scrollbar} {...props} style={{...style, position:'relative', width: '2px', background: '#d8d8d8' }}/>}
			renderTrackHorizontal={props => <div {...props} style={{display:"none"}}/>}>
			<textarea
			className="composer-text-area"
			rows={this.state.rows}
			aria-label={this.props.placeHolderText}
			placeholder={this.props.placeHolderText}
			tabIndex={TAB_INDEX_ORDER.textInput}
			onChange={this.handleChange}
			onKeyDown={(e)=>{
				this.handleOnKeyDown(e)
			}}
			maxLength ={MAX_TEXT_COUNT}
			ref={el => {
				this.messageRef = el
			}}
			/>
			</Scrollbars>
			<input
				type="image"
				className="send-button"
				aria-label="Send message"
				alt="Send message"
				src={this.state.disableButton ? this.props.composerInactiveIcon : this.props.composerIcon}
				disabled={this.state.disableButton}
				tabIndex={TAB_INDEX_ORDER.sendButton}
				onClick={() => {
					this.handleOnClick()
				}}
			/>
			</div>
		);
	}
}
