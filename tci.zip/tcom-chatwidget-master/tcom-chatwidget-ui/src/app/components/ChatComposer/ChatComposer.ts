import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatComposer } from './ChatComposer.ui';
import { postMessage, postChasitorTyping, postChasitorNotTyping } from '../../actions/ChatSessionActions';
// import * as _ from 'lodash';

const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	placeHolderText: chatSession.placeHolderText,
	composerIcon: chatSession.composerIcon,
	composerInactiveIcon: chatSession.composerInactiveIcon
});

const mapDispatchToProps = (dispatch: Dispatch) => ({

	postChasitorTyping: () => {
		dispatch(postChasitorTyping())
	},

	postChasitorNotTyping: () => {
		dispatch(postChasitorNotTyping())
	},

	postMessage: (e: any) => {

		const { currentTarget, key } = e;

		let { value } = currentTarget;
		if (key === 'Enter' && value.trim() != '') {
			let pureText = value.replace(/(\r\n|\n|\r)/gm, "")
			if (pureText.length >=1){
				dispatch(postMessage(value));
			}
			e.currentTarget.value = '';
			e.preventDefault();
		}

	},
	postMessageOnClick: (message: any) => {
		dispatch(postMessage(message.value));
		message.value = '';
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatComposer);
