import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, text, number } from '@storybook/addon-knobs';
import { ChatComposer } from './ChatComposer.ui';
import { ConnectionState } from '@cm-types/types';


storiesOf('Components|ChatComposer', module)
    .addDecorator(withKnobs({
        escapeHTML: false
    }))
    .add('basic', () => (
        <ChatComposer composerIcon={text('src', './icons/icon-send-btn-active.svg')} composerInactiveIcon={text('src', './icons/icon-send-btn-inactive.svg')} />
    ));
