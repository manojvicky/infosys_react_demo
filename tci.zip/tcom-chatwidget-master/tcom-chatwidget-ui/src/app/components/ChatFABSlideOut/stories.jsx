import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatFABSlideOut } from './ChatFABSlideOut.ui';


const MAXIMIZED_TITLE = "Let your fingers do the talking. Chat to a consultant online 24x7";
const MAXIMIZED_BODY = "Need help with your Telstra services or products? Need help with your Telstra services or products? Need help with your Telstra services or products?";
const MAXIMIZED_BUTTON_TEXT = "Chat with us now";

const MEDIUM_TITLE = "What can we help you with today?";
const MEDIUM_BODY = "Need help with your Telstra services or products? Let your fingers do the talking. Chat to a consultant online 24x7";
const MEDIUM_BUTTON_TEXT = "Chat with us now";

const MINIMIZED_TITLE = "Let's chat.";
const MINIMIZED_BODY = "Need help with your Telstra services or products?";
const MINIMIZED_BUTTON_TEXT = "Chat with us now";

export const actions = {
  onClickHandler: action('onClickHandler'),
};

storiesOf('Components|ChatFABSlideOut', module)
	.addDecorator(withKnobs({
     escapeHTML: false
  }))
	.add('small', () => (
    <ChatFABSlideOut  isStoryBook={true} slideOutScrollHeight={0} slideOutTitle={text('Title', MINIMIZED_TITLE)} slideOutTitleIconDisplay={boolean('Show title icon', true)} slideOutTitleIcon={text('src', '/icons/logo-telstra.svg')}  slideOutBody={text('Body', MINIMIZED_BODY)} slideOutButtonText={text('Button', MINIMIZED_BUTTON_TEXT)} {...actions}/>
	)).add('medium', () => (
    <ChatFABSlideOut isStoryBook={true}  slideOutScrollHeight={0} slideOutTitle={text('Title', MEDIUM_TITLE)} slideOutTitleIconDisplay={boolean('Show title icon', true)} slideOutTitleIcon={text('src', '/icons/logo-telstra.svg')} slideOutBody={text('Body',MEDIUM_BODY)} slideOutButtonText={text('Button', MEDIUM_BUTTON_TEXT)} {...actions}/>
	));
