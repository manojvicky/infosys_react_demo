import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatFABSlideOut } from './ChatFABSlideOut.ui';
import { closeSlideOut, initiateChatFromSlideOut } from '../../actions/ChatEntryActions';
import { resetUnreadMessagesStatus, connectToChat } from '../../actions/ChatSessionActions';


const mapStateToProps = ({ chatEntry }: ApplicationState) => ({
	slideout: chatEntry.slideout,
	slideOutTitle: chatEntry.slideOutTitle,
	slideOutTitleIconDisplay: chatEntry.slideOutTitleIconDisplay,
	slideOutTitleIcon: chatEntry.slideOutTitleIcon,
	slideOutBody: chatEntry.slideOutBody,
	slideOutButtonText: chatEntry.slideOutButtonText,
	slideOutScrollHeight: chatEntry.slideOutScrollHeight,
	slideOutCloseIcon: chatEntry.slideOutCloseIcon,
	slideOutActionIcon: chatEntry.slideOutActionIcon
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onCloseSlideOutHandler: () => dispatch(closeSlideOut()),
	onInitiateChatFromSlideOut: () => {
		dispatch(initiateChatFromSlideOut())
		dispatch(connectToChat());
		dispatch(resetUnreadMessagesStatus());
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatFABSlideOut);
