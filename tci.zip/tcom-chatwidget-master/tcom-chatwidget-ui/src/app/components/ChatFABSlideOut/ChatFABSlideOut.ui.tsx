import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { Slide } from 'react-reveal';
import { Scroll } from 'react-fns';

interface ChatFABSlideOutProps {
	slideOutTitle?: string;
	slideOutTitleIconDisplay?: boolean;
	slideOutTitleIcon?: string;
	slideOutCloseIcon?: string;
	slideOutActionIcon?: string;
	slideOutBody?: string;
	slideOutButtonText?: string;
	onCloseSlideOutHandler?: () => void;
	onInitiateChatFromSlideOut?: () => void;
	onKeyPress?: () => void;
	slideOutScrollHeight?: number;
	isStoryBook: boolean;
}

export const SlideWrapper = props => {
	let showSlideFlag = false;
	return (
		<Scroll
			render={({ x, y }) => {
				if (!showSlideFlag) {
					showSlideFlag = y > props.slideOutScrollHeight;
				}
				return (
					<Slide right when={showSlideFlag} duration={600}>
						{props.children}
					</Slide>
				);
			}}
		/>
	);
};

export class ChatFABSlideOut extends React.Component<ChatFABSlideOutProps> {

	_isMounted = false;

	state = {
		show: false
	};

	componentWillUnmount() {
    this._isMounted = false;
  }

	componentDidMount() {
		this._isMounted = true;
		this.setState({
      show: true
		});
	}

	constructor(props) {
    super(props);
  };

	public render() {
		if (this._isMounted) {
			return	this.props.isStoryBook ? (
				this.renderSlideOut()
			) : (
				<SlideWrapper slideOutScrollHeight={this.props.slideOutScrollHeight}>{this.renderSlideOut()}</SlideWrapper>
			);
		}else{
			return null;
		}
	}

	renderSlideOut() {
		let chatFabTitle = classNames(CSS_PREFIX + '-fab-slideout');
		return (
			<div className={chatFabTitle}>
				<div className="card">
					<div className="card-inner">
						<div className="card-header">
							{this.props.slideOutTitleIconDisplay && (
								<div className="card-header-avatar">
									<div className="card-header-avatar-root">
										<img alt="Telstra" src={this.props.slideOutTitleIcon} />
									</div>
								</div>
							)}
							<div className="card-title-wrapper">
								<span>{this.props.slideOutTitle}</span>
							</div>
							<div className="card-header-close" onClick={this.props.onCloseSlideOutHandler}>
								<img src={this.props.slideOutCloseIcon} alt="icon" />
							</div>
						</div>
						<div className="card-body">
							<p>{this.props.slideOutBody}</p>
						</div>
						<div className="card-action" onClick={this.props.onInitiateChatFromSlideOut}>
							<button>{this.props.slideOutButtonText}</button>
							<img src={this.props.slideOutActionIcon} alt="icon" />
						</div>
					</div>
				</div>
			</div>
		);
	}
}
