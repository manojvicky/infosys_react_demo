import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

export class ChatPanel extends React.Component {
	constructor(props: any) {
		super(props);
	}

	public render() {
		return <div className={classNames(CSS_PREFIX + '-panel')}>{this.props.children}</div>;
	}
}
