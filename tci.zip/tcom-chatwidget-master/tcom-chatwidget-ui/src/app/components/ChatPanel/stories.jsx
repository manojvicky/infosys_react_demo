import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatPanel } from './ChatPanel';

const MAXIMIZED_TEXT = "Need help? Let's chat.";
const MINIMIZED_TEXT = "Let's chat.";

export const actions = {
  onClickHandler: action('onClickHandler'),
};

storiesOf('Components|ChatPanel', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatPanel fabTitle={MINIMIZED_TEXT} displayStatus={boolean('show', true)}/>
	)).add('long', () => (
    <ChatPanel fabTitle={MAXIMIZED_TEXT} displayStatus={boolean('show', true)}/>
	));
