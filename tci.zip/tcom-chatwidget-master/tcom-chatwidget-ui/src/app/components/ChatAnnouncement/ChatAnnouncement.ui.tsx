import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface ChatAnnouncementProps {
	announcementText?: string;
	announcementLinkText?: string;
	announcementLink?: string;
	closeAnnouncementIcon?: string;
	announcementLinkOpenNewTab?: boolean;
	smallAlertIcon?: string;
	onCloseAnnoucementHandler?: () => void;
}

export class ChatAnnouncement extends React.Component<ChatAnnouncementProps> {
	public render() {
		let openNewTabFlag = this.props.announcementLinkOpenNewTab;
		let chatAnnouncement = classNames(CSS_PREFIX + '-ChatAnnouncement');
		let newTabTag = !openNewTabFlag ? { target: '_blank' } : '';
		return (
			<div className={chatAnnouncement}>
				<div className="announcement-container">
					<div className="small-alert-icon">
						<img src={this.props.smallAlertIcon} alt="alert" />
					</div>
					<div className="announcement-text">
						{this.props.announcementText}
					</div>
					<div className="close-panel" onClick={this.props.onCloseAnnoucementHandler}>
						<img src={this.props.closeAnnouncementIcon} alt="Close alert" />
					</div>
				</div>
				<div className="action-link">
					<a href={this.props.announcementLink} {...newTabTag}>
						{this.props.announcementLinkText}
					</a>
				</div>
			</div>
		);
	}
}
