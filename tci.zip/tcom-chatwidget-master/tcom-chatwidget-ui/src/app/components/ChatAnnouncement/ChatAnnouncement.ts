import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatAnnouncement } from './ChatAnnouncement.ui';
import { onCloseAnnoucementHandler } from '../../actions/ChatSessionActions';

const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	announcementText: chatSession.announcementText,
	announcementLinkText: chatSession.announcementLinkText,
	announcementLink: chatSession.announcementLink,
	announcementLinkOpenNewTab: chatSession.announcementLinkOpenNewTab,
	closeAnnouncementIcon: chatSession.closeAnnouncementIcon,
	smallAlertIcon: chatSession.messageAlertIcon,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onCloseAnnoucementHandler: () => dispatch(onCloseAnnoucementHandler())
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatAnnouncement);
