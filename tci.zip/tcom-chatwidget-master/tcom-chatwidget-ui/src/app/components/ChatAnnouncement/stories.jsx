import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatAnnouncement } from './ChatAnnouncement.ui';
import { ChatPanel, ChatHeader } from '@cm-components/ComponentList';

const MAXIMIZED_TEXT = "We're currently experiencing a mobile service outage in Melbourne metro areas. If you’re impacted, the Service Status Page will explain the interruption you’re experiencing, provide updates on the issue, and when possible, estimate when the issue should be resolved. There’s nothing further you can do until the outage is restored however the following information may help provide alternate options during the impacted period.";
const MINIMIZED_TEXT = "We're currently experiencing a mobile service outage in Melbourne metro areas.";

const LINK_TEXT = "More Information";
const MORE_LINK_TEXT = "You can find more information here";

export const actions = {
  onCloseAnnoucementHandler: action('onCloseAnnoucementHandler'),
};

storiesOf('Components|ChatAnnouncement', module)
	.addDecorator(withKnobs({
     escapeHTML: false
  }))
	.add('small', () => (
    <ChatAnnouncement announcementText={text('Text',MINIMIZED_TEXT)} announcementLinkText={text('Link Text',LINK_TEXT)} {...actions}/>
	)).add('long', () => (
    <ChatAnnouncement announcementText={text('Text',MAXIMIZED_TEXT)} announcementLinkText={text('Link Text',MORE_LINK_TEXT)}  {...actions}/>
	));
