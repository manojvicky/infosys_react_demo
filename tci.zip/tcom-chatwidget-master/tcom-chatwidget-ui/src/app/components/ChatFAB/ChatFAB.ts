import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatFAB } from './ChatFAB.ui';
import { openChatWindow } from '../../actions/ChatEntryActions';
import { resetUnreadMessagesStatus, connectToChat } from '../../actions/ChatSessionActions';

const mapStateToProps = ({ chatEntry, chatSession }: ApplicationState) => ({
	status: chatEntry.status,
	fabTitle: chatEntry.fabTitle,
	fabMinimizedTitle: chatEntry.fabMinimizedTitle,
	fabIconDisplay: chatEntry.fabIconDisplay,
	fabIcon: chatEntry.fabIcon,
	fabBackGroundColor: chatEntry.fabBackGroundColor,
	chatHeaderTitle: chatSession.chatHeaderTitle,
	connectionStatus: chatSession.connectionStatus,
	messageMetadata: chatSession.messageMetadata
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	handleClick: () => {
		dispatch(openChatWindow());
		dispatch(connectToChat());
		dispatch(resetUnreadMessagesStatus());
	},
	onKeyPress: () => {
		dispatch(openChatWindow());
		dispatch(connectToChat());
		dispatch(resetUnreadMessagesStatus());
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatFAB);
