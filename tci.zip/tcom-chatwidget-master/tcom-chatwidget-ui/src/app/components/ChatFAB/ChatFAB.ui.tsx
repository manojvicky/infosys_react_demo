import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { ChatState, ConnectionState, IMessageMetadata } from '@cm-types/types';
import { isMobile } from 'react-device-detect';
import { CSS_PREFIX, CHAT_ERROR, MAX_UNREAD_COUNTER, UNREAD_COUNT_EXCEEDED } from '@cm-constants/DefaultConstants';

interface ChatFABProps {
	fabTitle?: string;
	fabMinimizedTitle?: string;
	chatHeaderTitle?: string;
	fabIconDisplay?: boolean;
	fabIcon?: string;
	fabBackGroundColor?: string;
	status?: string;
	connectionStatus?: string;
	messageMetadata?: {};
	handleClick?: () => void;
	onKeyPress?: () => void;
}

export class ChatFAB extends React.Component<ChatFABProps> {
	isMobileFlag: boolean = isMobile;

	public render() {
		if (this.props.status === ChatState.MINIMIZE && this.isMobileFlag === false) {
				return this.renderMininizedFAB();
		}else if (this.props.status === ChatState.MINIMIZE && this.isMobileFlag === true) {
				return this.renderMininizedFABMobile();
		}else {
			return this.renderFAB();
		}
	}

	public renderFAB() {
		let btnLabel = this.props.fabTitle;
		let chatContainer = classNames(CSS_PREFIX + '-fab', CSS_PREFIX + '-bottom-right');
		let chatFabTitle = classNames(CSS_PREFIX + '-fab-title');
		return (
			<button
				className={chatContainer}
				title={btnLabel}
				aria-label={btnLabel}
				onClick={this.props.handleClick}
				type="button"
				style={{ backgroundColor: this.props.fabBackGroundColor }}
			>
				<div className={chatFabTitle}>
					<span>{btnLabel}</span>
					{this.props.fabIconDisplay && <img src={this.props.fabIcon} alt="chat icon" />}
				</div>
			</button>
		);
	}

	public renderMininizedFABMobile() {
		let btnLabel = this.props.fabTitle;
		let chatContainer = classNames(CSS_PREFIX + '-fab', CSS_PREFIX +'-bottom-right');
		let chatFabTitle = classNames(CSS_PREFIX + '-fab-title');
		let messageMetadata: IMessageMetadata = this.props.messageMetadata || {};
		let totalFailed: number = messageMetadata.totalFailed || 0;
		let unreadMessageCounter: number = messageMetadata.unreadCount || 0;
		let unsentMessage: boolean = (totalFailed > 0) ? true : false;
		let maxUnreadMessages = (unreadMessageCounter > MAX_UNREAD_COUNTER) ? UNREAD_COUNT_EXCEEDED: unreadMessageCounter;
		let displayMessageCounter = unsentMessage ? CHAT_ERROR: maxUnreadMessages;

		return (
			<button
				className={chatContainer}
				title={btnLabel}
				aria-label={btnLabel}
				onClick={this.props.handleClick}
				type="button"
				style={{ backgroundColor: this.props.fabBackGroundColor }}
			>
				<div className={chatFabTitle}>
					<span>{btnLabel}</span>
					{this.props.fabIconDisplay && <img src={this.props.fabIcon} alt="chat icon" />}
					{ this.props.connectionStatus === ConnectionState.IN_PROGRESS && displayMessageCounter != 0 &&
						<span className={'msg-label-counter'}>{ displayMessageCounter }</span>
					}
				</div>
			</button>
		);
	}

	public renderMininizedFAB() {
		let btnLabel = this.props.fabMinimizedTitle;
		let messageMetadata: IMessageMetadata = this.props.messageMetadata || {};
		let totalFailed: number = messageMetadata.totalFailed || 0;
		let unreadMessageCounter: number = messageMetadata.unreadCount || 0;
		let unsentMessage: boolean = (totalFailed > 0) ? true : false;
		let chatContainerWrapper = classNames(CSS_PREFIX + '-fab-wrapper', CSS_PREFIX +'-bottom-right');
		let chatContainer = classNames(CSS_PREFIX + '-fab-minimized');
		let chatFabTitle = classNames(CSS_PREFIX + '-fab-title');

		let maxUnreadMessages = (unreadMessageCounter > MAX_UNREAD_COUNTER) ? UNREAD_COUNT_EXCEEDED: unreadMessageCounter;
		let displayMessageCounter = unsentMessage ? CHAT_ERROR: maxUnreadMessages;

		return (
			<div className={chatContainerWrapper}>
				<button
					className={chatContainer}
					title={btnLabel}
					aria-label={btnLabel}
					onClick={this.props.handleClick}
					type="button"
				>
					<div className={chatFabTitle}>
					<span className={'msg-label'}>{btnLabel}</span>
					{ this.props.connectionStatus === ConnectionState.IN_PROGRESS && displayMessageCounter != 0 &&
						<span className={'msg-label-counter'}>{ displayMessageCounter }</span>
					}
					</div>
				</button>
			</div>
		);
	}
}
