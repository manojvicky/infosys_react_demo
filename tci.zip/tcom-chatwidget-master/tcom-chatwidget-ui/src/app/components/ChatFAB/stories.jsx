import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, radios, color } from '@storybook/addon-knobs';
import { ChatFAB } from './ChatFAB.ui';

const EXTRA_MAXIMIZED_TEXT = "Let your fingers do the talking. Chat to a consultant.";
const MAXIMIZED_TEXT = "Need help? Let's chat.";
const MEDIUM_TEXT = "Let's chat.";
const MINIMIZED_TEXT = "Chat";

export const actions = {
    onClickHandler: action('onClickHandler'),
};

storiesOf('Components|ChatFAB', module)
    .addDecorator(withKnobs({
        escapeHTML: false
    }))
    .add('small', () => (
        <ChatFAB fabTitle={text('FAB Title', MINIMIZED_TEXT)} fabIconDisplay={boolean('Show icon', true)} fabIcon={text('src', '/icons/chat.svg')} status={radios('state', ['ACTIVE', 'MINIMIZE'], 'ACTIVE')} fabMinimizedTitle={text('FAB Minimized Text', 'Adam')} fabBackGroundColor={color('FAB Background Color', '#0064d2')} {...actions} />
    )).add('medium', () => (
        <ChatFAB fabTitle={text('FAB Title', MEDIUM_TEXT)} fabIconDisplay={boolean('Show icon', true)} fabIcon={text('src', '/icons/chat.svg')} status={radios('state', ['ACTIVE', 'MINIMIZE'], 'ACTIVE')} fabMinimizedTitle={text('FAB Minimized Text', 'Rodriguez')} fabBackGroundColor={color('FAB Background Color', '#0064d2')} {...actions} />
    )).add('long', () => (
        <ChatFAB fabTitle={text('FAB Title', MAXIMIZED_TEXT)} fabIconDisplay={boolean('Show icon', true)} fabIcon={text('src', '/icons/chat.svg')} status={radios('state', ['ACTIVE', 'MINIMIZE'], 'ACTIVE')} fabMinimizedTitle={text('FAB Minimized Text', "O'Kelly Johnson")} fabBackGroundColor={color('FAB Background Color', '#0064d2')} {...actions} />
    )).add('very long', () => (
        <ChatFAB fabTitle={text('FAB Title', EXTRA_MAXIMIZED_TEXT)} fabIconDisplay={boolean('Show icon', true)} fabIcon={text('src', '/icons/chat.svg')} status={radios('state', ['ACTIVE', 'MINIMIZE'], 'ACTIVE')} fabMinimizedTitle={text('FAB Minimized Text', 'Michelle Anderson')} fabBackGroundColor={color('FAB Background Color', '#0064d2')} {...actions} />
    ));
