import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { ConnectionState } from '@cm-types/types';

interface ChatConnectProps {
	connectWelcomeMessage?: string;
	connectMessage?: string;
	connectionStatus?: string;
	connectionFailureTitle?: string;
	connectionFailureMessage?: string;
	connectionFailureSubMessage?: string;
	connectionFailureIcon?: string;
	noAgentTitle?: string;
	noAgentMessage?: string;
	noAgentIcon?: string;
	queueHeader?: string;
	queueMessage?: string;
	queueSubMessage?: string;
	queueIcon?: string;
	queueNum?: number;
	isInQueue?: boolean;
}

export class ChatConnect extends React.Component<ChatConnectProps> {
	constructor(props: any) {
		super(props);
	}

	public render() {
		if (this.props.connectionStatus === ConnectionState.PENDING) {
			return this.renderLoading();
		} else if (
			this.props.connectionStatus === ConnectionState.SUCCESS ||
			this.props.connectionStatus === ConnectionState.IN_PROGRESS
		) {
			return this.renderNone();
		} else if (this.props.connectionStatus === ConnectionState.FAILURE) {
			return this.renderFailure();
		} else if (this.props.connectionStatus === ConnectionState.NO_AGENTS) {
			return this.renderNoAgents();
		} else if (this.props.connectionStatus === ConnectionState.QUEUED) {
			return this.renderQueuing();
		} else {
			return this.renderNone();
		}
	}

	public renderLoading() {
		return (
			<div className={classNames(CSS_PREFIX + '-connect')}>
				<div className="loader-round" />
				<div className="splash-loading">
					<span className="header-text">{this.props.connectWelcomeMessage}</span>
					<span className="body-text">{this.props.connectMessage}</span>
				</div>
			</div>
		);
	}

	public renderFailure() {
		return (
			<div className={classNames(CSS_PREFIX + '-connect')}>
				<div className="oops-icon">
					<img src={this.props.connectionFailureIcon} alt="connection failure icon" />
				</div>
				<div className="splash-failed">
					<span className="header-text">{this.props.connectionFailureTitle}</span>
					<span className="body-text">{this.props.connectionFailureMessage}</span>
					<span className="body-sub-text">{this.props.connectionFailureSubMessage}</span>
				</div>
			</div>
		);
	}

	public renderNoAgents() {
		return (
			<div className={classNames(CSS_PREFIX + '-connect')}>
				<div className="oops-icon">
					<img src={this.props.noAgentIcon} alt="no agent icon" />
				</div>
				<div className="splash-failed">
					<span className="header-text">{this.props.noAgentTitle}</span>
					<span className="body-text">{this.props.noAgentMessage}</span>
				</div>
			</div>
		);
	}

	public renderQueuing() {
		return (
			<div className={classNames(CSS_PREFIX + '-connect')}>
				<div className="watch-icon">
					<img src={this.props.queueIcon} alt="queue icon" />
				</div>
				<div className="splash-queued">
					<span className="header-text">{this.props.queueHeader}</span>
					<span className="body-text">{this.props.queueMessage}</span>
					{/* SubMessage and queue number not needed at this point in time */}
					{/* <span className="body-text">{this.props.queueSubMessage}</span> */}
					{/* <span className="body-number">{this.props.queueNum}</span> */}
				</div>
			</div>
		);
	}

	public renderNone() {
		return null;
	}
}
