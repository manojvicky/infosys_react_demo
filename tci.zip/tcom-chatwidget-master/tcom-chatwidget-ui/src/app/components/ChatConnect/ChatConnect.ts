import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatConnect } from './ChatConnect.ui';

const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	connectWelcomeMessage: chatSession.connectWelcomeMessage,
	connectMessage: chatSession.connectMessage,
	connectionStatus: chatSession.connectionStatus,
	connectionFailureTitle: chatSession.connectionFailureTitle,
	connectionFailureMessage: chatSession.connectionFailureMessage,
	connectionFailureSubMessage: chatSession.connectionFailureSubMessage,
	connectionFailureIcon: chatSession.connectionFailureIcon,
	noAgentTitle: chatSession.noAgentTitle,
	noAgentMessage: chatSession.noAgentMessage,
	noAgentIcon: chatSession.noAgentIcon,
	queueHeader: chatSession.queueHeader,
	queueMessage: chatSession.queueMessage,
	queueSubMessage: chatSession.queueSubMessage,
	queueIcon: chatSession.queueIcon,
	queueNum: chatSession.queueNum,
	isInQueue: chatSession.isInQueue
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatConnect);
