import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, text, number } from '@storybook/addon-knobs';
import { ChatConnect } from './ChatConnect.ui';
import { ConnectionState } from '@cm-types/types';

export const actions = {
    connectToChat: action('connectToChat'),
};

export const inputObj = {
    connectWelcomeMessage: 'Welcome to Telstra Chat.',
    connectMessage: 'Connecting you to our chat agents. Please wait a moment.',
    connectionFailureTitle: 'Oops…',
    connectionFailureMessage: "We've encountered a connection issue. We're working on fixing this.",
    connectionFailureSubMessage: 'Please try again later.',
    connectionFailureIcon: './icons/illustration-opps.svg',
    noAgentHeader: 'Sorry',
    noAgentMessage: 'Our agents are offline. If your enquiry is urgent, please call 1800 000 000.',
    noAgentIcon: './icons/illustration-opps.svg',
    queueHeader: 'Welcome to Telstra Chat',
    queueMessage: 'Our agents are currently busy. You are in queue for the next available agent',
    queueSubMessage: 'Your queue position is:',
    queueIcon: './icons/illustration-watch.svg',
    queueNum: '20',
};

storiesOf('Components|ChatConnect', module)
    .addDecorator(withKnobs({
        escapeHTML: false
    }))
    .add('1. loading', () => (
        <ChatConnect
            connectionStatus={ConnectionState.PENDING}
            connectWelcomeMessage={text('Welcome Message', inputObj.connectWelcomeMessage)}
            connectMessage={text('Message', inputObj.connectMessage)}
            {...actions} />
    )).add('4. failure', () => (
        <ChatConnect
            connectionStatus={ConnectionState.FAILURE}
            connectionFailureIcon={text('Icon', inputObj.connectionFailureIcon)}
            connectionFailureTitle={text('Welcome Message', inputObj.connectionFailureTitle)}
            connectionFailureMessage={text('Message', inputObj.connectionFailureMessage)}
            connectionFailureSubMessage={text('Welcome Message', inputObj.connectionFailureSubMessage)}
            {...actions} />
    )).add('3. no agents', () => (
        <ChatConnect
            connectionStatus={ConnectionState.NO_AGENTS}
            noAgentIcon={text('Icon', inputObj.noAgentIcon)}
            noAgentHeader={text('Welcome Message', inputObj.noAgentHeader)}
            noAgentMessage={text('Message', inputObj.noAgentMessage)}
            {...actions} />
    )).add('2. in queue', () => (
        <ChatConnect
            connectionStatus={ConnectionState.QUEUED}
            queueIcon={text('Icon', inputObj.queueIcon)}
            queueHeader={text('Welcome Message', inputObj.queueHeader)}
            queueMessage={text('Message', inputObj.queueMessage)}
            queueSubMessage={text('Sub Message', inputObj.queueSubMessage)}
            queueNumber={number('Queue Number', inputObj.queueNum)}
            {...actions} />
    ));
