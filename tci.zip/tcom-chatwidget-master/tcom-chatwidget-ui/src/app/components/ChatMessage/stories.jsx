import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color, radios } from '@storybook/addon-knobs';
import { ChatMessage } from './ChatMessage.ui';

let messagesObj = [
      {
        id: 0,
        text: 'Welcome to Telstra Chat. You are now connected to John.',
        type: 'WelcomeMessage',
        actor: 'System',
        status: 'Recieved',
        timestamp: '10:56 PM'
      },
      {
        id: 1,
        text: "Hi there, you're chatting with Adam. How can I help you?",
        type: 'PlainMessage',
        actor: 'Agent',
        status: 'Recieved',
        timestamp: '10:56 PM'
      },
      {
        id: 2,
        text: "Hi Adam. My name is Sarah. I've lost my sim card. I have an iphone on prepaid plan. I want to get a new card and keep the number from my old sim.",
        type: 'PlainMessage',
        actor: 'Customer',
        status: 'Delivered',
        timestamp: '10:56 PM'
      },
      {
        id: 3,
        text: 'You are being transferred. Please wait while we connect you to an agent.',
        type: 'TransferMessage',
        actor: 'System',
        status: 'Recieved',
        timestamp: '10:56 PM'
      },
      {
        id: 4,
        text: 'Your chat has ended. Thanks for chatting with us today.',
        type: 'EndMessage',
        actor: 'System',
        status: 'Recieved',
        timestamp: '10:56 PM'
      },
      {
        id: 5,
        text: "Hi Adam. My name is Sarah. I've lost my sim card. I have an iphone on prepaid plan. I want to get a new card and keep the number from my old sim.",
        type: 'PlainMessage',
        actor: 'Customer',
        status: 'Failed',
        timestamp: '10:56 PM'
      },
      {
        id: 6,
        text: "Hi Adam. My name is Sarah. I've lost my sim card. I have an iphone on prepaid plan. I want to get a new card and keep the number from my old sim.",
        type: 'PlainMessage',
        actor: 'Customer',
        status: 'Retry',
        timestamp: '10:56 PM'
      },
      {
         id: 7,
         text: '{\n   "type":"template",\n   "payload":{\n      "template_type":"card",\n      "elements":[\n         {\n            "title":"Telstra Pre-Paid Extra",\n            "image_url":"https://www.w3schools.com/w3images/cars1.jpg",\n            "subtitle":"Heaps of data and calls.",\n            "default_action":{\n               "type":"web_url",\n               "url":"https://petersfancybrownhats.com/view?item=103",\n               "webview_height_ratio":"tall"\n            }\n         }\n      ]\n   }\n}',
         type: 'CustomCard',
         actor: 'Agent',
         status: 'Recieved',
         timestamp: '9:57 PM'
       }
    ];

export const actions = {
  onCloseAnnoucementHandler: action('onCloseAnnoucementHandler'),
};

storiesOf('Components|ChatMessage', module)
	.addDecorator(withKnobs({
     escapeHTML: true
  }))
	.add('1. welcome message', () => (
    <ChatMessage messages={ [messagesObj[0]] }/>
	)).add('2. agent message', () => (
      <ChatMessage messages={ [messagesObj[1]] }/>
  )).add('3. customer message', () => (
        <ChatMessage messages={ [messagesObj[2]] }/>
  )).add('4. transfer message', () => (
        <ChatMessage messages={ [messagesObj[3]] }/>
  )).add('5. end message', () => (
        <ChatMessage messages={ [messagesObj[4]] }/>
  )).add('6. failed message', () => (
        <ChatMessage messages={ [messagesObj[5]] }/>
  )).add('7. retry message', () => (
        <ChatMessage messages={ [messagesObj[6]] }/>
  )).add('8. agent typing', () => (
        <ChatMessage showTypingIndicator={ true }/>
  ));
