import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { LiveMessage } from 'react-aria-live';
import { IMessage, MessageTypes, UserTypes, MessageStatus } from '@cm-types/types';

import { TAB_INDEX_ORDER } from '../../constants/DefaultConstants';

interface ChatMessageProps {
	messages: IMessage[];
	showTypingIndicator: boolean;
	postMessageOnResend: (message?: string, id?: number) => void;
	agentIcon: string;
	messageAlertIcon: string;
	messageMetadata: {};
}


export class ChatMessage extends React.Component<ChatMessageProps> {
	messagesEnd: any;

	scrollToBottom = () => {
		this.messagesEnd.scrollIntoView({ behavior: 'smooth' });
	};

	componentDidMount() {
		this.scrollToBottom();
	}

	componentDidUpdate() {
		this.scrollToBottom();
	}

	public render() {
		let chatMessageClass = classNames(CSS_PREFIX + '-chat-message');
		return (
			<React.Fragment>
				<div className={chatMessageClass}>{...this.renderMessages()}</div>
				<div
					style={{ float: 'left', clear: 'both', marginBottom: 20 }}
					ref={el => {
						this.messagesEnd = el;
					}}
				/>
			</React.Fragment>
		);
	}

	renderMessages() {
		let messages = this.props.messages || [];
		let messagesContent = messages.map((message, index) => {
			switch (message.type) {
				case MessageTypes.WELCOME_MESSAGE:
					return this.renderWelcomeMessage(message, index);
				case MessageTypes.PLAIN_MESSAGE:
					return this.renderPlainMessage(message, index, messages.length);
				case MessageTypes.TRANSFER_MESSAGE:
					return this.renderTransferMessage(message, index);
				case MessageTypes.END_MESSAGE:
					return this.renderEndMessage(message, index);
				case MessageTypes.CUSTOM_CARD:
					return this.renderCardMessage(message, index);
				default: {
					return null;
				}
			}
		});
		if(this.props.showTypingIndicator){
					messagesContent.push(this.renderTyping(messages.length));
		}
		return messagesContent;
	}

	renderWelcomeMessage(message: IMessage, index: number) {
		let liveMessage = 'At'+ message.timestamp+ ', '+ message.text;
		return (
			<div className="welcome-message" key={index} tabIndex={TAB_INDEX_ORDER.message}>
				<LiveMessage message={liveMessage} aria-live='polite'/>
				<p>{message.text}</p>
				<p>{message.timestamp}</p>
			</div>
		);
	}

	renderPlainMessage(message: IMessage, index: number, messagesLength: number) {
		const avatarBol = message.avatar || false
		switch (message.actor) {
			case UserTypes.AGENT:
				return this.renderAgentMessage(message, index, avatarBol);
			case UserTypes.CUSTOMER:
				return this.renderCustomerMessage(message, index);
			default: {
				return null;
			}
		}
	}

	renderAgentMessage(message: IMessage, index: number, enableAvatar: boolean) {
		let liveMessage = message.actor+' wrote '+ message.text;
		return (
			<div className="message" key={index} tabIndex={TAB_INDEX_ORDER.message}>
				{ enableAvatar ?
				<figure className="avatar">
					<img src={this.props.agentIcon} alt="agent icon"/>
				</figure> : null }
				<LiveMessage message={liveMessage} aria-live='polite'/>
				{message.text}
			</div>
		);
	}

	renderCustomerMessage(message: IMessage, index: number) {
		let liveMessage = 'You wrote '+ message.text;
		return (
			<div className="bubble-container" key={index}>
				<div className="message-bubble" tabIndex={TAB_INDEX_ORDER.message}>
					<LiveMessage message={liveMessage} aria-live='polite'/>
					<p lang="en" className="message-body">
						{message.text}
					</p>
				</div>
				{message.status === MessageStatus.FAILED && (
					<div className="not-delivered" tabIndex={TAB_INDEX_ORDER.message}>
						Not delivered.{' '}
						<a
							href="javascript:void(0)"
							className="resend-link"
							tabIndex={TAB_INDEX_ORDER.message}
							onClick={() => {
								this.props.postMessageOnResend(message.text, message.key);
							}}
						>
							Resend
						</a>
						<img src={this.props.messageAlertIcon} />
					</div>
				)}
				{message.status === MessageStatus.RETRY && (
					<div className="not-delivered">
						<div className="loader-round" />
					</div>
				)}
			</div>
		);
	}

	renderTyping(index: number) {
		let liveMessage = 'Agent is typing';
		return (
			<div className="message" key={index}>
				<figure className="avatar">
					<img src={this.props.agentIcon} />
				</figure>
				<LiveMessage message={liveMessage} aria-live='polite'/>
				<div className="typing-indicator">
					<span />
					<span />
					<span />
				</div>
			</div>
		);
	}

	renderTransferMessage(message: IMessage, index: number) {
		let liveMessage = 'At'+ message.timestamp+ ', '+ message.text;
		return (
			<div className="transfer-message" key={index} tabIndex={TAB_INDEX_ORDER.message}>
				<LiveMessage message={liveMessage} aria-live='polite'/>
				<p>{message.timestamp}</p>
				<span>{message.text}</span>
			</div>
		);
	}

	renderEndMessage(message: IMessage, index: number) {
		let liveMessage = 'At'+ message.timestamp+ ', '+ message.text;
		return (
			<div className="end-message" key={index} tabIndex={TAB_INDEX_ORDER.message}>
				<LiveMessage message={liveMessage} aria-live='polite'/>
				<p>{message.timestamp}</p>
				<span>{message.text}</span>
			</div>
		);
	}

	renderCardMessage(message: IMessage, index: number) {
		let messageText: any = message.text;
		let customObj: any = JSON.parse(messageText);

		let messageObj = customObj.payload.template_type == 'card' && customObj.payload.elements[0];
		return (
			<div className="card-wrapper" key={index}>
				<figure className="avatar">
					<img src={this.props.agentIcon} />
				</figure>
				<div className="card" key={index}>
					<img src={messageObj.image_url}/>
					<div className="card-inner">
						<h4>
							<b>{messageObj.title}</b>
						</h4>
						<p>{messageObj.subtitle}</p>
					</div>
				</div>
			</div>
		);
	}
}
