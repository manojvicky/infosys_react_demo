import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatMessage } from './ChatMessage.ui';
import { onCloseAnnoucementHandler, retryPostMessage } from '../../actions/ChatSessionActions';

const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	messages: chatSession.messages,
	showTypingIndicator: chatSession.showTypingIndicator,
	agentIcon: chatSession.agentIcon,
	messageAlertIcon: chatSession.messageAlertIcon,
	messageMetadata: chatSession.messageMetadata
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onCloseAnnoucementHandler: () => dispatch(onCloseAnnoucementHandler()),
	postMessageOnResend: (message: string, key: number) => {
		if (message != '') {
			dispatch(retryPostMessage(message, key));
		}
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatMessage);
