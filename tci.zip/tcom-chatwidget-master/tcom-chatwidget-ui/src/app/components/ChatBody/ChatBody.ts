import { connect } from 'react-redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatBody } from './ChatBody.ui';

const mapStateToProps = ({ chatEnd }: ApplicationState) => ({
  chatEndStatus: chatEnd.chatEndStatus
});


export default connect(
	mapStateToProps,
	null
)(ChatBody);
