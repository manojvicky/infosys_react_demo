import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { Scrollbars } from 'react-custom-scrollbars';

interface ChatBodyProps {
	chatEndStatus?: string
}

interface ChatBodyState {
	active?: boolean;
	show?: boolean;
}

export class ChatBody extends React.Component<ChatBodyProps, ChatBodyState> {
	constructor(props: any) {
		super(props);
	}

	messagesEnd: any;

	componentDidMount(){
		if(this.props.chatEndStatus!=="END"){
			this.scrollToBottom();
		}
	}

	componentDidUpdate() {
		if(this.props.chatEndStatus!=="END"){
			this.scrollToBottom();
		}
	}

	scrollToBottom = () => {
		this.messagesEnd.scrollIntoView();
	}

	public render() {
		return (
		<Scrollbars style={{ height: '100%' }} renderThumbVertical={({ style, ...props }) =>
            <div {...props} style={{...style, width: '2px', background: '#d8d8d8' }}/>}>
		<div
		className={classNames(CSS_PREFIX + '-panel-body')}
		tabIndex={0}
		>
		{this.props.children}
		</div>
		<div
		style={{ float: 'left', clear: 'both' }}
		ref={el => {
			this.messagesEnd = el;
		}}
		/>
		</Scrollbars>);
	}
}
