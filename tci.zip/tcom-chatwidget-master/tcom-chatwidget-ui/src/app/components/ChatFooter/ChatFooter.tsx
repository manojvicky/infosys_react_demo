import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface ChatFooterProps {}

interface ChatFooterState {
	active?: boolean;
	show?: boolean;
}

export class ChatFooter extends React.Component<ChatFooterProps, ChatFooterState> {
	constructor(props: any) {
		super(props);
	}

	public render() {
		return <div className={classNames(CSS_PREFIX + '-footer')}>{this.props.children}</div>;
	}
}
