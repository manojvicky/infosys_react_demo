import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatFooter } from './ChatFooter';

const MAXIMIZED_TEXT = "Need help? Let's chat.";
const MINIMIZED_TEXT = "Let's chat.";

export const actions = {
  onClickHandler: action('onClickHandler'),
};

storiesOf('Components|ChatFooter', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatFooter fabTitle={MINIMIZED_TEXT} displayStatus={boolean('show', true)} {...actions}/>
	)).add('long', () => (
    <ChatFooter fabTitle={MAXIMIZED_TEXT} displayStatus={boolean('show', true)} {...actions}/>
	));
