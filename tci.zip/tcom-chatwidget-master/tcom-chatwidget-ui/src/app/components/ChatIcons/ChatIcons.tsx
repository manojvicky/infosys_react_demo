import * as React from 'react';

export const IconClose = props => (
	<svg width={18} height={18} {...props}>
		<title>{'icon-close-blue'}</title>
		<defs>
			<filter x="-4.6%" y="-7.7%" width="109.1%" height="115.3%" filterUnits="objectBoundingBox" id="prefix__a">
				<feOffset dy={1} in="SourceAlpha" result="shadowOffsetOuter1" />
				<feGaussianBlur stdDeviation={2} in="shadowOffsetOuter1" result="shadowBlurOuter1" />
				<feColorMatrix
					values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.11 0"
					in="shadowBlurOuter1"
					result="shadowMatrixOuter1"
				/>
				<feMerge>
					<feMergeNode in="shadowMatrixOuter1" />
					<feMergeNode in="SourceGraphic" />
				</feMerge>
			</filter>
			<path
				d="M5.09 5.09L.498 9.68 5.09 5.09l4.726 4.725L5.09 5.089zm0 0L9.641.537 5.091 5.09.377.38l4.712 4.71z"
				id="prefix__b"
			/>
		</defs>
		<g filter="url(#prefix__a)" transform="translate(-201 -12)" fill="none" fillRule="evenodd">
			<use stroke="#0064D2" strokeWidth={1.5} xlinkHref="#prefix__b" transform="translate(205 15)" />
		</g>
	</svg>
);

export const IconMinimise = props => (
	<svg width={20} height={2} {...props}>
		<title>{'icon-minimise-blue'}</title>
		<path
			d="M18.573 1H1.428"
			stroke="#0064D2"
			strokeWidth={1.5}
			fill="none"
			fillRule="evenodd"
			strokeLinecap="square"
		/>
	</svg>
);

export const IconMenu = props => (
	<svg width={20} height={4} {...props}>
		<title>{'icon-menu-blue'}</title>
		<g fill="#0064D2" fillRule="evenodd">
			<circle cx={2} cy={2} r={2} />
			<circle cx={10} cy={2} r={2} />
			<circle cx={18} cy={2} r={2} />
		</g>
	</svg>
);
