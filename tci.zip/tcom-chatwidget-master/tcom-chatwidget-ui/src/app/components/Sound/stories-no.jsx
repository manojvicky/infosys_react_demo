import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { Sound } from './Sound';


export const actions = {
  onClickHandler: action('onClickHandler'),
};

storiesOf('Components|Sound', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <Sound
      src={text('src', '/audio/chime.mp3')}
			play={boolean('play', false)}
			onStart={action('start')}
			onStop={action('stop')}
      />
	));
