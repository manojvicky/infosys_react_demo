import { Dispatch } from 'redux';
import { connect } from 'react-redux';
import { Sound } from './Sound.ui';
import { ApplicationState } from '../../state/ApplicationState';
import { playTrack } from '../../actions/ChatSessionActions';


const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	alertAudioFile: chatSession.alertAudioFile,
	play: chatSession.play,
	soundEnabled: chatSession.soundEnabled
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	handleSoundEnded: () => {
		dispatch(playTrack(false));
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(Sound);
