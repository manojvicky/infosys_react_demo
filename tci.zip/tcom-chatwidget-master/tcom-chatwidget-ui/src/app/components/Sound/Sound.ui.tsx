import './styles.scss';
import * as React from 'react';

interface SoundProps {
	alertAudioFile?: any;
	play?: boolean;
	soundEnabled?: boolean;
	handleSoundEnded(): void;
}

export class Sound extends React.Component<SoundProps> {

	audio: any;

	componentDidMount() {
			this.handlePlay();
		}

	componentDidUpdate() {
			this.handlePlay();
		}

	handlePlay = () => {
		const { play, soundEnabled } = this.props;
			if (play && soundEnabled) {
				this.play();
			}
	}

	play = () => {
		this.audio.play();
	}

	handleSoundEnded = () => {
		this.props.handleSoundEnded();
	}

	handleRef = (audio: any) => {
		this.audio = audio;
	}

	public render() {
		return (
			<audio
			src={this.props.alertAudioFile}
			ref={this.handleRef}
			onEnded = {this.handleSoundEnded}
			/>
		);
	}
}
