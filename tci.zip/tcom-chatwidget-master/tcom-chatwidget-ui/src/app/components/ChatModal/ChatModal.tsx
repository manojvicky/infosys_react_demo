import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface ChatMessageProps {
	open?: any;
}

export class ChatModal extends React.Component<ChatMessageProps> {

	constructor(props: any) {
		super(props);
	}
	public render() {
		return (
			<div className={classNames(CSS_PREFIX + '-modal')}>
				<div 	className={classNames('chat-modal-overlay')}>
				<div className= {classNames('chat-modal-wrapper')}>
					<div className= {classNames('chat-modal')}>
							{this.props.children}
						</div>
					</div>
				</div>
			</div>
			)
	}
}
