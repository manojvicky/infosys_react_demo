import * as React from 'react';
import { storiesOf,addDecorator } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs} from '@storybook/addon-knobs';
import ChatModal from './ChatModal';
import { withViewport } from '@storybook/addon-viewport';

addDecorator(withViewport('Responsive'));

export const actions = {
  onMinimize: action('onMinimize'),
};

storiesOf('Components|ChatModal', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatModal {...actions}/>
	));
