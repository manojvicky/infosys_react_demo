import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { ChatButton } from '@cm-components/ComponentList';

interface PreChatEndProps {
	open?: any;
	preChatEndTitle?: string;
	preChatEndMessage?: string;
	preChatEndBtnText?: string;
	preChatEndCancelBtnText?: string;
	preChatEndQueueTitle?: string;
	preChatEndQueueMessage?: string;
	preChatEndCloseIcon?: string;
	onCancelChatEnd?: () => void;
	onClickChatEnd?: () => void;

}

export class PreChatEnd extends React.Component<PreChatEndProps> {

	constructor(props: any) {
		super(props);
	}
	public render() {
		return this.renderConfirmation();
	}

	public renderConfirmation() {
		return (
			<div className={classNames(CSS_PREFIX + '-pre-chat-end')}>
				<div className="close-panel" onClick={this.props.onCancelChatEnd}>
					<img src={this.props.preChatEndCloseIcon} alt="Close pop up" />
				</div>
				<div className= {classNames('pre-chat-end-message')}>{this.props.preChatEndTitle}</div>
				<div className= {classNames('pre-chat-end-button-group')}>
					<ChatButton type='primary' handleClick={this.props.onClickChatEnd}>{this.props.preChatEndBtnText}</ChatButton>
					<ChatButton type='secondary' handleClick={this.props.onCancelChatEnd}>{this.props.preChatEndCancelBtnText}</ChatButton>
				</div>
			</div>
			)
	}

	public renderConfirmationWhenInQueue() {
		return (
			<div className={classNames(CSS_PREFIX + '-pre-chat-end')}>
				<div className="close-panel" onClick={this.props.onCancelChatEnd}>
					<img src={this.props.preChatEndCloseIcon} alt="Close pop up" />
				</div>
				<div className= {classNames('pre-chat-end-message')}>{this.props.preChatEndTitle}</div>
				<div className= {classNames('pre-chat-end-sub-message')}>{this.props.preChatEndQueueMessage}</div>
				<div className= {classNames('pre-chat-end-button-group')}>
					<ChatButton type='primary' handleClick={this.props.onClickChatEnd}>{this.props.preChatEndBtnText}</ChatButton>
					<ChatButton type='secondary' handleClick={this.props.onCancelChatEnd}>{this.props.preChatEndCancelBtnText}</ChatButton>
				</div>
			</div>
			)
	}
}
