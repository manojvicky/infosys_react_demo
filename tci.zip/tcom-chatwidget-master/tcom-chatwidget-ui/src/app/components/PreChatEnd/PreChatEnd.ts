import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { PreChatEnd } from './PreChatEnd.ui';
import { onPreChatEnd, onClickChatEnd } from '../../actions/ChatEndActions';
import { ApplicationState } from '../../state/ApplicationState';
import { EndState } from '@cm-types/types';

const mapStateToProps = ({ chatEnd }: ApplicationState) => ({
	preChatEndTitle: chatEnd.preChatEndTitle,
	preChatEndBtnText: chatEnd.preChatEndBtnText,
	preChatEndCancelBtnText: chatEnd.preChatEndCancelBtnText,
	preChatEndQueueTitle: chatEnd.preChatEndQueueTitle,
	preChatEndCloseIcon: chatEnd.preChatEndCloseIcon,
	preChatEndQueueMessage: chatEnd.preChatEndQueueMessage,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onCancelChatEnd: () => dispatch(onPreChatEnd(EndState.NA)),
	onClickChatEnd: () => {
		dispatch(onClickChatEnd())
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(PreChatEnd);
