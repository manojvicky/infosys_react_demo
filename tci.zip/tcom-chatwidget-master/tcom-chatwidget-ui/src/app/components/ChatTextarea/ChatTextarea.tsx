import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX, MAX_TEXT_COUNT } from '@cm-constants/DefaultConstants';

interface ChatTextareaProps {
  id?: string;
  onChange: (e:any)=> void;
}

interface ChatTextareaState {
  letterCount?: number
}

export class ChatTextarea extends React.Component<ChatTextareaProps, ChatTextareaState> {

	constructor(props: any) {
    super(props);
    this.state = {
			letterCount: 0,
		}
  }

  handleTextareaChange(e:any){
    this.props.onChange(e)
		this.setState({
			letterCount: e.currentTarget.value.length
		})
	}
  
  
	public render() {
    let chatFabTitle = classNames(CSS_PREFIX + '-chatTextarea');
    return (
      <div className={chatFabTitle}>
      <textarea className="survey-textarea" maxLength={MAX_TEXT_COUNT} 
      onChange={(e) => this.handleTextareaChange(e)}
      id = {this.props.id}
      ></textarea>
      {this.state.letterCount===2000 ?
      <p className={classNames('survey-letter-counter-alert')}> <img className={classNames('alert-small')} src="icons/icon-alert.svg" /> {MAX_TEXT_COUNT}/{MAX_TEXT_COUNT} </p>
      :
      <p className={classNames('survey-letter-counter')}> {this.state.letterCount}/{MAX_TEXT_COUNT} </p>
      }
      
      
      </div>	
    )
	}
}
