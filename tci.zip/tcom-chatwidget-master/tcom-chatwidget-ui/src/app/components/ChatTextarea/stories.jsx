import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatTextarea } from './ChatTextarea';

export const actions = {
	onChange: action('onChange'),
  };

storiesOf('Components|ChatTextarea', module)
	.addDecorator(withKnobs)
	.add('general', () => (
    <ChatTextarea id={text('Question Id', 'hellow thank you')}  {...actions}/>
	));
