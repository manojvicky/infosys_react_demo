import * as React from 'react';
import { storiesOf,addDecorator } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs} from '@storybook/addon-knobs';
import ChatButton from './ChatButton';
import { withViewport } from '@storybook/addon-viewport';

addDecorator(withViewport('Responsive'));

export const actions = {
  onMinimize: action('onMinimize'),
};

storiesOf('Components|ChatButton', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <PreChatEndProps {...actions}/>
	));
