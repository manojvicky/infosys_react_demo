import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface ChatButtonProps {
	type?: any;
	handleClick?: () => void;
	paddingTop?: string;
	disabled?: boolean
}

export class ChatButton extends React.Component<ChatButtonProps> {

	constructor(props: any) {
		super(props);
	}
	public render() {
		let typeButton = classNames(CSS_PREFIX + '-chat-button');
		if(this.props.type === 'primary'){
			typeButton = classNames(CSS_PREFIX + '-chat-button',CSS_PREFIX + '-chat-button-outline',CSS_PREFIX + '-chat-button-full-width');
		}else if(this.props.type === 'secondary'){
			typeButton = classNames(CSS_PREFIX + '-chat-button',CSS_PREFIX + '-chat-button-link');
		}
		return 	(<button type="button" disabled={this.props.disabled} style={{ paddingTop: this.props.paddingTop }} className={typeButton} onClick={this.props.handleClick}>{this.props.children}</button>);
	}
}
