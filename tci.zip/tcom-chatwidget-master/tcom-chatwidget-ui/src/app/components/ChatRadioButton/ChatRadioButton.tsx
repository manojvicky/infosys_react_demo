import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface ChatRadioButtonProps {
  onChange?: (e:any)=> void;
  text?: string;
  checked?: boolean;
  id?: string;
}

export class ChatRadioButton extends React.Component<ChatRadioButtonProps> {

	constructor(props: any) {
		super(props);
	}
	public render() {
    let chatRadioButton = classNames(CSS_PREFIX + '-chatRadioButton');
    return (
      <div className = {chatRadioButton}>
      <label
      className={classNames('radio-control radio-control--checkbox')} > &nbsp; {this.props.text}
      <input
      type="radio"
      value={this.props.text}
      name="radio"
      checked={this.props.checked}
      onChange={this.props.onChange}
      id={this.props.id}
      />
      <div className="radio-control__indicator">
      <div className="radio-inner-ellipse">
      </div>
      </div>
      </label>
      </div>
    )
	}
}
