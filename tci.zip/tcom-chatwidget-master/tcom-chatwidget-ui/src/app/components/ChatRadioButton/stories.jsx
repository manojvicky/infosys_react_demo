import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatRadioButton } from './ChatRadioButton';

export const actions = {
	onChange: action('onChange'),
  };


storiesOf('Components|ChatRadioButton', module)
	.addDecorator(withKnobs)
	.add('general', () => (
    <ChatRadioButton 
    id={text('Question Id', 'hellow thank you')} 
    text={text('Display Text', 'hellow thank you')}
    checked={boolean('Checked', true)}
      {...actions}/>
	));
