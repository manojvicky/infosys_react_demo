import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatHeader } from './ChatHeader.ui';
import { onMinimize } from '../../actions/ChatEntryActions';
import { onCloseSession } from '../../actions/ChatEndActions';


const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	chatHeaderTitle: chatSession.chatHeaderTitle
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onMinimize: () => dispatch(onMinimize()),
	onClose: () =>  {
		dispatch(onCloseSession())
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatHeader);
