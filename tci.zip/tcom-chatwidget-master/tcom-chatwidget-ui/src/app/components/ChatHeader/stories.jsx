import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatHeader } from './ChatHeader.ui';

const MAXIMIZED_TEXT = "Need help? Let's chat.";
const MINIMIZED_TEXT = "Let's chat.";

export const actions = {
  onClickHandler: action('onClickHandler'),
};

storiesOf('Components|ChatHeader', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatHeader fabTitle={MINIMIZED_TEXT} displayStatus={boolean('show', true)} {...actions}/>
	)).add('long', () => (
    <ChatHeader fabTitle={MAXIMIZED_TEXT} displayStatus={boolean('show', true)} {...actions}/>
	));
