import './styles.scss';
import * as React from 'react';
//import MenuIcon  from '@cm-icons/icon-menu-blue.svg';
//import MinimizeIcon  from '@cm-icons/icon-minimise-blue.svg';
//import CloseIcon  from '@cm-icons/icon-close-blue.svg';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { IconClose, IconMenu, IconMinimise } from '@cm-components/ComponentList';

import {TAB_INDEX_ORDER} from '../../constants/DefaultConstants'

interface ChatHeaderProps {
	onMinimize(): void;
	onClose(): void;
	chatHeaderTitle?: string;
}

export class ChatHeader extends React.Component<ChatHeaderProps> {

	state = {
		chatHeaderTitleTabIndex: TAB_INDEX_ORDER.maximumIndex
	}

	focusHeaderTitleHandler = () => {
		let tempState = { ...this.state }
		tempState.chatHeaderTitleTabIndex !== TAB_INDEX_ORDER.chatHeader.title ? tempState.chatHeaderTitleTabIndex = TAB_INDEX_ORDER.chatHeader.title : tempState.chatHeaderTitleTabIndex = TAB_INDEX_ORDER.maximumIndex;
		this.setState(tempState);
	}

	public render() {
		return (
			<div className={classNames(`${CSS_PREFIX}-header`)}>
				<div className={classNames('header-title')} id="telstra-lcp-header-title" >
					<div className={classNames('header-text')}
						tabIndex={this.state.chatHeaderTitleTabIndex}
						onFocus={this.focusHeaderTitleHandler}
						onBlur={this.focusHeaderTitleHandler}
					>
						{this.props.chatHeaderTitle}</div>
				</div>
				{/* Currently hidden, hidden as not part of MVP */}
				{false &&< button
					id="telstra-lcp-menu-button"
					className={classNames('menu-button')}
					aria-label="Chat options"
					title="Chat options"
					tabIndex={TAB_INDEX_ORDER.chatHeader.menu}
				>
					<IconMenu />
				</button>}
				<button
					id="telstra-lcp-menu-button"
					className={classNames('minimize-button')}
					aria-label="Minimise chat"
					title="Minimise chat"
					onClick={this.props.onMinimize}
					tabIndex={TAB_INDEX_ORDER.chatHeader.minimize}
				>
					<IconMinimise />
				</button>
				<button
					id="telstra-lcp-menu-button"
					className={classNames('close-button')}
					aria-label="Close chat"
					title="Close chat"
					onClick={this.props.onClose}
					tabIndex={TAB_INDEX_ORDER.chatHeader.close}
				>
					<IconClose />
				</button>
			</div>
		);
	}
}
