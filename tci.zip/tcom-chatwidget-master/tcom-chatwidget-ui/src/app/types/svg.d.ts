/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-02-11T14:51:07+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-02-11T14:51:45+11:00
 * @Copyright: Telstra 2018
 */

declare module '*.svg' {
	const content: string;
	export default content;
}
