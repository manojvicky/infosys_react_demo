export interface ConfigOptions{
  serviceUrl?: string;
  chatManagerLocation?: string;
  surveyUrl?: string;
  assetsDomainPath?: string;
}
