/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:27:40+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T18:21:45+11:00
 * @Copyright: Telstra 2018
 */

export enum Language {
	ENGLISH = 'en'
}

export enum ChatState {
	NOT_INITIALIZED = 'NOT_INITIALIZED',
	ACTIVE = 'ACTIVE',
	INACTIVE = 'INACTIVE',
	MINIMIZE = 'MINIMIZE',
	MAXIMIZE = 'MAXIMIZE'
}

export enum ConnectionState {
	INITIAL = 'INITIAL',
	PENDING = 'PENDING',
	SUCCESS = 'SUCCESS',
	FAILURE = 'FAILURE',
	NO_AGENTS = 'NO_AGENTS',
	QUEUED = 'QUEUED',
	ENDED = 'ENDED',
	IN_PROGRESS = 'IN_PROGRESS',
	TIMED_OUT = 'TIMED_OUT'
}

export enum EndState {
	NA = 'NA',
	BEFORE_END = 'BEFORE_END',
	END = 'END',
	AGENT_END_CHAT = 'AGENT_END_CHAT',
}

export enum ResponseTypes {
	CHAT_REQUEST_SUCCESS = 'ChatRequestSuccess',
	CHAT_ESTABLISHED = 'ChatEstablished',
	CHAT_REQUEST_FAIL = 'ChatRequestFail',
	CHAT_MESSAGE = 'ChatMessage',
	QUEUE_UPDATE = 'QueueUpdate',
	CHAT_IDLE_TIMEOUT = 'ChasitorIdleTimeoutWarningEvent',
	CHAT_TRANSFERRED = 'ChatTransferred',
	AGENT_TYPING = 'AgentTyping',
	AGENT_NOT_TYPING = 'AgentNotTyping',
	AGENT_DISCONNECT = 'AgentDisconnect',
	CHAT_ENDED = 'ChatEnded',
	CHASITOR_TYPING = 'ChasitorTyping'
}

export enum AgentStatus {
	UNAVAILABLE = 'Unavailable',
	AVAILABLE = 'Available'
}

export enum ChatSessionStatus {
	OK = 'OK'
}

export enum MessageStatus {
	PENDING = 'Pending',
	DELIVERED = 'Delivered',
	RECIEVED = 'Recieved',
	FAILED = 'Failed',
	RETRY = 'Retry',
	READ = 'Read',
	UNREAD = 'Unread'
}

export enum MessageTypes {
	WELCOME_MESSAGE = 'WelcomeMessage',
	SYSTEM_MESSAGE = 'SystemMessage',
	PLAIN_MESSAGE = 'PlainMessage',
	TYPING_MESSAGE = 'TypingMessage',
	TRANSFER_MESSAGE = 'TransferMessage',
	END_MESSAGE = 'EndMessage',
	CUSTOM_CARD = 'CustomCard'
}

export enum UserTypes {
	AGENT = 'Agent',
	CUSTOMER = 'Customer',
	CODI = 'Codi',
	SYSTEM = 'System'
}

export interface SurveyObj {
	choices?: string[],
	questionId: string,
	questionName: string,
	surveyId: string,
	type: string,
}

export interface IMessage {
	id: number;
	text?: string;
	type?: MessageTypes;
	actor?: UserTypes;
	status?: MessageStatus;
	timestamp?: string;
	key?: number;
	avatar?: boolean;
}

export interface IMessageMetadata {
	idCount?: number;
	keyCount?: number;
	failedIdCount?: number;
	total?: number;
	totalFailed?: number;
	unreadCount?: number;
}
