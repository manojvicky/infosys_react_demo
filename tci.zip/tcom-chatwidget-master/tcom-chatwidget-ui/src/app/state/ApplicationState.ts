import { IMessage, IMessageMetadata, SurveyObj} from '@cm-types/types';
import { SensitiveDataRules } from '../models/ChatMessagesResponse';

export interface ApplicationState {
	chatEntry: ChatEntryState;
	chatSession: ChatSessionState;
	chatEnd: ChatEndState;
}

export interface ChatEntryState {
	show?: boolean;
	status?: string;
	slideout?: boolean;
	slideOutTitle?: string;
	slideOutTitleIconDisplay?: boolean;
	slideOutTitleIcon?: string;
	slideOutCloseIcon?: string;
	slideOutActionIcon?: string;
	slideOutBody?: string;
	slideOutButtonText?: string;
	slideOutScrollHeight?: number;
	fabIconDisplay?: boolean;
	fabIcon?: string;
	fabTitle?: string;
	fabMinimizedTitle?: string;
	fabBackGroundColor?: string;
	chatManagerLocation?: string;
}

export interface ChatSessionState {
	serviceEndpointURL?: string;
	surveyEndpointURL?: string;
	grantType?: string;
  clientId?: string;
  clientSecret?: string;
  username?: string;
	password?: string;
	surveyAuthToken?: string;
	sessionId?: string;
	sessionKey?: string;
	affinityToken?: string;
	apiVersion?: number;
	organizationId?: string,
	deploymentId?: string,
	buttonId?: string,
	ack?: number;
	pc?: number;
	sequenceNumber?: number;
	chatHeaderTitle?: string;
	announcement?: boolean;
	announcementText?: string;
	announcementLinkText?: string;
	announcementLink?: string;
	announcementLinkOpenNewTab?: boolean;
	closeAnnouncement?: boolean;
	closeAnnouncementIcon?: string;
	connectHeaderTitle?: string;
	connectWelcomeMessage?: string;
	connectMessage?: string;
	connectionStatus?: string;
	connectionFailureTitle?: string;
	connectionFailureMessage?: string;
	connectionFailureSubMessage?: string;
	connectionFailureIcon?: string;
	noAgentTitle?: string;
	noAgentMessage?: string;
	noAgentIcon?: string;
	queueHeader?: string;
	queueMessage?: string;
	queueSubMessage?: string;
	queueIcon?: string;
	queueNum?: number;
	isInQueue?: boolean;
	messageMetadata?: IMessageMetadata,
	messages?: IMessage[];
	incomingMessagesSequence?: number[];
	placeHolderText?: string;
	composerIcon?: string;
	composerInactiveIcon?: string;
	showTypingIndicator?: boolean;
	agentName?: string;
	chatEndedMsg?: string;
	agentIcon?: string;
	messageAlertIcon?: string;
	surveyObj?: SurveyObj[];
	alertAudioFile?: string;
	soundEnabled?: boolean;
	play?: boolean;
	surveyAvailability?: boolean,
	sendTranscriptBtnText?: string,
	sendFeedbackBtnText?: string,
	sendCloseWindowBtnText?: string,
	submittedSurvey?: boolean,
	welcomeMessage?: string,
	transferMessage?: string,
	transferDelayMessage?: string,
	endChatMessage?: string,
	endChatByAgentMessage?: string,
	sensitiveDataRules?: SensitiveDataRules[],
	tickIcon?: string
}

export interface ChatEndState {
	chatEndStatus? : string;
	preChatEndTitle?: string;
	preChatEndMessage?: string;
	preChatEndBtnText?: string;
	preChatEndCancelBtnText?: string;
	preChatEndQueueTitle?: string;
	preChatEndQueueMessage?: string;
	preChatEndCloseIcon?: string;
}
