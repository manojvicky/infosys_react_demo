import { initialState } from '../state/InitialState';
import { ConfigOptions } from '@cm-types/ConfigOptions';
import { ChatEntryState, ChatSessionState, ChatEndState } from '../state/ApplicationState';


export default (configOptions: ConfigOptions) => {

  let mergedInitialState = initialState;

	let chatEntryState: ChatEntryState = initialState.chatEntry;
  let chatSessionState: ChatSessionState = initialState.chatSession;
  let chatEndState: ChatEndState = initialState.chatEnd;

  mergedInitialState.chatSession.serviceEndpointURL = configOptions.serviceUrl;
  mergedInitialState.chatEntry.chatManagerLocation = configOptions.chatManagerLocation;
  mergedInitialState.chatSession.surveyEndpointURL = configOptions.surveyUrl;

  if(configOptions.assetsDomainPath ){
    mergedInitialState.chatEntry.fabIcon = configOptions.assetsDomainPath + chatEntryState.fabIcon;
    mergedInitialState.chatEntry.slideOutTitleIcon = configOptions.assetsDomainPath + chatEntryState.slideOutTitleIcon;
    mergedInitialState.chatEntry.slideOutCloseIcon = configOptions.assetsDomainPath + chatEntryState.slideOutCloseIcon;
    mergedInitialState.chatEntry.slideOutActionIcon = configOptions.assetsDomainPath + chatEntryState.slideOutActionIcon;

    mergedInitialState.chatSession.closeAnnouncementIcon = configOptions.assetsDomainPath + chatSessionState.closeAnnouncementIcon;
    mergedInitialState.chatSession.connectionFailureIcon = configOptions.assetsDomainPath + chatSessionState.connectionFailureIcon;
    mergedInitialState.chatSession.noAgentIcon = configOptions.assetsDomainPath + chatSessionState.noAgentIcon;
    mergedInitialState.chatSession.queueIcon = configOptions.assetsDomainPath + chatSessionState.queueIcon;
    mergedInitialState.chatSession.composerIcon = configOptions.assetsDomainPath + chatSessionState.composerIcon;
    mergedInitialState.chatSession.composerInactiveIcon = configOptions.assetsDomainPath + chatSessionState.composerInactiveIcon;
    mergedInitialState.chatSession.agentIcon = configOptions.assetsDomainPath + chatSessionState.agentIcon;
    mergedInitialState.chatSession.messageAlertIcon = configOptions.assetsDomainPath + chatSessionState.messageAlertIcon;
    mergedInitialState.chatSession.tickIcon = configOptions.assetsDomainPath + chatSessionState.tickIcon;

    mergedInitialState.chatSession.alertAudioFile = configOptions.assetsDomainPath + chatSessionState.alertAudioFile;

    mergedInitialState.chatEnd.preChatEndCloseIcon = configOptions.assetsDomainPath + chatEndState.preChatEndCloseIcon;
  }

  return mergedInitialState;
}
