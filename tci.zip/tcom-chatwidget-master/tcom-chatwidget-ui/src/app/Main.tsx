/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:25:10+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T16:38:13+11:00
 * @Copyright: Telstra 2018
 */

import 'reflect-metadata';
import * as ReactDOM from 'react-dom';
import * as React from 'react';
import { Provider } from 'react-redux';
import configureStore from './store/configureStore';
import { PersistGate } from 'redux-persist/lib/integration/react';
import { LiveAnnouncer } from 'react-aria-live';
import { App } from './containers/ContainersList';
import { ConfigOptions } from '@cm-types/ConfigOptions';
import { LeaderBoardService } from './services/LeaderBoardService';


class Main {
	static bootstrap(appName: string, configOptions: ConfigOptions): boolean {
		let result: boolean = false;
		try {
			console.log(appName + ' bootstraping..');

			const { store, persistor } = configureStore(configOptions);

			LeaderBoardService.findLeader(store);

			ReactDOM.render(
				<Provider store={store}>
					<PersistGate loading={null} persistor={persistor}>
					<LiveAnnouncer>
						<App/>
					</LiveAnnouncer>
					</PersistGate>
				</Provider>,
				document.getElementById('chat-root')
			);
			result = true;
		} catch (err) {
			console.warn('Failed during the initialization ' + err);
		}
		return result;
	}
}

export default Main;
