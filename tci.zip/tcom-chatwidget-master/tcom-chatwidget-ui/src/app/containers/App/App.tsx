import * as React from 'react';
import {
	ChatEntry, ChatLoading, Chat, ChatFinish
} from '../../screens/ScreensList';
import { ChatWindow } from '../ContainersList';
import { ChatState } from '@cm-types/types';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { fetchChatManagerConfig } from '../../actions/ChatEntryActions';
import { initServices } from '../../actions/ChatSessionActions';
import { EndState, ConnectionState } from '@cm-types/types';

interface ChatAppProps {
	status?: string;
	slideout?: boolean;
	slideOutScrollHeight: number;
	surveyAvailability?: boolean;
	announcement?: boolean;
	closeAnnouncement?: boolean;
	connectionStatus?: string;
	chatEndStatus?: EndState;
  fetchChatManagerConfig: () => void;
	initServices: () => void;
}

class App extends React.Component<ChatAppProps> {

	componentDidMount() {
		this.initilizeChatManagerClient();
	}

	initilizeChatManagerClient = () => {
		if (this.props.status === ChatState.NOT_INITIALIZED || this.props.status === ChatState.INACTIVE || this.props.status === ChatState.ACTIVE ) {
			this.props.fetchChatManagerConfig();
		}else if (this.props.status === ChatState.MINIMIZE || this.props.status === ChatState.MAXIMIZE){
			this.props.initServices();
		}
	};

	renderFAB() {
		return <ChatEntry/>;
	}

	renderWindow() {
		let connectionStatus = this.props.connectionStatus;
		let chatEndStatus = this.props.chatEndStatus;
		let surveyAvailability = this.props.surveyAvailability;
		return (
			<ChatWindow>
			{
				(connectionStatus === ConnectionState.PENDING ||
				connectionStatus === ConnectionState.FAILURE ||
				connectionStatus === ConnectionState.NO_AGENTS ||
				connectionStatus === ConnectionState.QUEUED) ?
				<ChatLoading/>	:
				(chatEndStatus === EndState.END && surveyAvailability === true) ?
				<ChatFinish/>		:	<Chat/>
			}
			</ChatWindow>
		);
	}

	render() {
		let status = this.props.status;
		 if (status === ChatState.ACTIVE || status === ChatState.MINIMIZE) {
				return this.renderFAB();
			} else if (status === ChatState.MAXIMIZE) {
				return this.renderWindow();
			}
			return <React.Fragment/>;
		}
}

const mapStateToProps = ({ chatEntry, chatSession, chatEnd }: ApplicationState) => ({
	status: chatEntry.status,
	slideout: chatEntry.slideout,
	fabTitle: chatEntry.fabTitle,
	fabIcon: chatEntry.fabIcon,
	fabBackGroundColor: chatEntry.fabBackGroundColor,
	announcement: chatSession.announcement,
	closeAnnouncement: chatSession.closeAnnouncement,
	connectionStatus: chatSession.connectionStatus,
	chatEndStatus: chatEnd.chatEndStatus,
	surveyAvailability: chatSession.surveyAvailability,
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
		fetchChatManagerConfig: () => dispatch(fetchChatManagerConfig()),
		initServices: () => dispatch(initServices())
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(App);
