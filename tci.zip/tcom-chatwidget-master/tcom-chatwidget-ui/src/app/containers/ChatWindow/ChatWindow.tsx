import './styles.scss';
import * as React from 'react';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';
import { isMobile } from 'react-device-detect';

class ChatWindow extends React.Component {
	constructor(props: any) {
		super(props);
	}

	componentWillMount() {
		if (isMobile) {
			document.body.style.position = 'fixed';
			document.body.style.width = '100%';
			document.body.style.height = '100%';
			document.body.style.top = '0';
			document.body.style.right = '0';
			document.body.style.bottom = '0';
			document.body.style.left = '0';
			document.body.style.overflowY = 'hidden';
		}
	}

	componentWillUnmount() {
		if (isMobile) {
			document.body.style.position = null;
			document.body.style.width = null;
			document.body.style.height = null;
			document.body.style.top = null;
			document.body.style.right = null;
			document.body.style.bottom = null;
			document.body.style.left = null;
			document.body.style.overflowY = null;
		}
	}

	public render() {
		return (
			<div className={classNames(CSS_PREFIX + '-window')}>
				<div className={classNames(CSS_PREFIX + '-window-inner')}>{this.props.children}</div>
			</div>
		);
	}
}

export default ChatWindow;
