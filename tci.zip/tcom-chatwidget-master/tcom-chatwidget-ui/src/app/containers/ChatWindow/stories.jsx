import * as React from 'react';
import { storiesOf,addDecorator } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs} from '@storybook/addon-knobs';
import ChatWindow from './ChatWindow';
import { withViewport } from '@storybook/addon-viewport';

addDecorator(withViewport('Responsive'));

export const actions = {
  onMinimize: action('onMinimize'),
};

storiesOf('Components|ChatWindow', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatWindow {...actions}/>
	)).add('long', () => (
    <ChatWindow {...actions}/>
));
