/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T12:23:09+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-30T00:01:42+11:00
 * @Copyright: Telstra 2018
 */

export const IS_DEV: boolean = DEVLOPMENT_MODE || false;

export const APP_NAME = 'tcom-chatwidget-ui';

export const DELAY_CHAT_ESTABLISH: number = 2000;

export const RETRY_CLOSE_CHAT: number = 2000;

export const CSS_PREFIX = 'telstra-lpa-chat-';

export const CHAT_STATE = 'telstra-lpa-chat-state';

export const CHAT_PROPS = 'telstra-lpa-chat-props';

export const CHAT_ERROR = '!';

export const MAX_UNREAD_COUNTER = 9;

export const UNREAD_COUNT_EXCEEDED = '9+';

export const MIN_ROW_COUNT = 1;

export const MAX_ROW_COUNT = 800;

export const MAX_RETRY_COUNT = 1000;

export const AVG_ROW_HEIGHT = 21;

export const FAILURE_ID_OFFSET = 99000;

export const MAX_TEXT_COUNT = 2000;

export const MIN_ROW_HEIGHT = 50;

export const RESET_HEIGHT = 40;

export const AGENT = 'agent';

/**
*  Tab index sequence for Tab Logical Order
*/
export const TAB_INDEX_ORDER = {
    maximumIndex : 1809,
    chatHeader : {
        title : 1801,
        menu : 1802,
        minimize: 1803,
        close : 1804
    },
    scrollbar : 1805,
    textInput : 1806,
    sendButton : 1807,
    message : 1808
}
