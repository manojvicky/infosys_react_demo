import BroadcastChannel from 'broadcast-channel';
import LeaderElection from 'broadcast-channel/leader-election';
import { reInitiateLongPolling } from '../actions/ChatSessionActions';

export class LeaderBoardService {

  static isLeader: boolean = false;

  static findLeader(store: any){
    const channel = new BroadcastChannel('TCOM-CHAT-WIDGET');
    const elector = LeaderElection.create(channel);
    elector.awaitLeadership().then(()=> {
        console.log('LeaderBoardService: This is the Master hub now');
        LeaderBoardService.isLeader = true;
        store.dispatch(reInitiateLongPolling());
    });
  }

}
