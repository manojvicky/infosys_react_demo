import { ChatManagerClient } from 'tcom-chatmanager-client';
import { ChatUIUtil } from '../util/ChatUIUtil';

export class ChatManagerServicesClient {
	static loadConfig = (chatManagerConfigUrl?: string) => {
		const	cm: ChatManagerClient = new ChatManagerClient(chatManagerConfigUrl);
		return cm.loadPageConfigurations(
			ChatUIUtil.fetchPageUrl()
		);
	}
}
