import {
	APIInit,
	ChatSessionAPI,
	ChatInitAPI,
	ChatPostMessagesAPI,
	ChatFetchMessagesAPI,
	ChatChasitorTypingAPI,
	ChatChasitorNotTypingAPI,
	ChatEndAPI,
	RetrieveSurveyAPI,
	SubmitSurveyAPI,
	GenerateTokenAPI
 } from 'tcom-chatwidget-services';
export class APIServicesClient {

	static servicesInitialized: boolean = false;

	public static initializeAPI(host?: string) {
		if(!APIServicesClient.servicesInitialized){
			const api = new APIInit(host);
			APIServicesClient.servicesInitialized = true;
			return api
				.execute()
				.then((data: any) => {
					console.log(data);
					return data;
				})
				.catch((reason: any) => {
					console.log(reason);
					return false;
				});
		}
	}

	public static getSessionId(host?: string, affinity?: string, apiVersion?: number) {
		const api = new ChatSessionAPI(host, affinity, apiVersion);

		return api
			.execute()
			.then((data: any) => {
				console.log(data);
				return data;
			})
			.catch((reason: any) => {
				console.log(reason);
				return false;
			});
	}

	public static initSession(
		host?: string,
		affinity?: string,
		apiVersion?: number,
		sessionKey?: string,
		sessionId?: string,
		sequenceNumber?: string,
		organizationId?: string,
		deploymentId?: string,
		buttonId?: string,
		contactUUID?: string,
		customerAccount?: string,
		caseNumber?: string
	) {
		const api = new ChatInitAPI(host, affinity, apiVersion, sessionKey, sessionId, sequenceNumber, organizationId, deploymentId, buttonId, contactUUID, customerAccount, caseNumber);
		return api.execute();
	}


	public static chasitorTyping(
		host?: string,
		affinity?: string,
		apiVersion?: number,
		sessionKey?: string,
		sequenceNumber?: string
	) {
		const api = new ChatChasitorTypingAPI(host, affinity, apiVersion, sessionKey, sequenceNumber);
		return api
			.execute()
			.then((data: any) => {
				return data;
			})
			.catch((reason: any) => {
				console.log(reason);
				return false;
			});
	}

	public static chasitorNotTyping(
		host?: string,
		affinity?: string,
		apiVersion?: number,
		sessionKey?: string,
		sequenceNumber?: string
	) {
		const api = new ChatChasitorNotTypingAPI(host, affinity, apiVersion, sessionKey, sequenceNumber);
		return api
			.execute()
			.then((data: any) => {
				return data;
			})
			.catch((reason: any) => {
				console.log(reason);
				return false;
			});
	}

	public static chasitorEnd(
		host?: string,
		affinity?: string,
		apiVersion?: number,
		sessionKey?: string,
		sequenceNumber?: string
	) {
		const api = new ChatEndAPI(host, affinity, apiVersion, sessionKey, sequenceNumber);
		return api
			.execute()
			.then((data: any) => {
				return data;
			})
			.catch((reason: any) => {
				console.log(reason);
				return false;
			});
	}

	public static fetchMessages(host?: string, affinity?: string, apiVersion?: number, sessionKey?: string, ack?: string, pc?: string) {
		const api = new ChatFetchMessagesAPI(host, affinity, apiVersion, sessionKey, ack, pc);
		return api
			.execute()
			.then((data: any) => {
				console.log(data);
				return data;
			})
			.catch((reason: any) => {
				console.log('reason '+reason);
				throw reason;
			});
	}

	public static postMessages(
		host?: string,
		affinity?: string,
		apiVersion?: number,
		sessionKey?: string,
		sequenceNumber?: string,
		messageText?: string
	) {
		const api = new ChatPostMessagesAPI(host, affinity, apiVersion, sessionKey, sequenceNumber, messageText);
		return api
			.execute()
			.then((data: any) => {
				return data;
			})
			.catch((reason: any) => {
				console.log(reason);
				return false;
			});
	}

	public static retrieveSurvey(
		host?: string,
		) {
			const api = new RetrieveSurveyAPI(host);
			return api
				.execute()
				.then((data: any) => {
					console.log(data)
					return data;
				})
				.catch((reason: any) => {
					console.log(reason);
					return false;
				});
		}

		public static submitSurvey(
			host?: string,
			surveyResponse?
			 ) {
			const api = new SubmitSurveyAPI(host, surveyResponse);
			return api
				.execute()
				.then((data: any) => {
					return data;
				})
				.catch((reason: any) => {
					console.log(reason);
					return false;
				});
		}

		public static generateToken(
			host?: string,
			grantType?: string,
			clientId?: string,
			clientSecret?: string,
			username?: string,
			password?: string
			 ) {
			const api = new GenerateTokenAPI(
				host,
				grantType,
				clientId,
				clientSecret,
				username,
				password
				);
			return api
				.execute()
				.then((data: any) => {
					return data;
				})
				.catch((reason: any) => {
					console.log(reason);
					return false;
				});
		}

}
