import { createStore, compose, applyMiddleware } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';
//import autoMergeLevel1 from 'redux-persist/lib/stateReconciler/autoMergeLevel1';
import mergedState from '../state/IncomingState';
//import storage from 'redux-persist/lib/storage';
import thunk from 'redux-thunk';
import { rootReducer } from '../reducers';
//import { createStateSyncMiddleware } from 'redux-state-sync';
import createSagaMiddleware from 'redux-saga';
import { rootSaga } from '../sagas';
import { createStateSyncMiddleware } from '../middleware/crossTabSyncState';
import { ChatEntryActionTypes, ChatSessionActionTypes, ChatEndActionTypes, ChatGlobalActionTypes } from '../actions/ChatActionTypes';
import { ConfigOptions } from '@cm-types/ConfigOptions';


export default ( configOptions: ConfigOptions) => {
	const persistConfig = {
		key: 'telstra-lcp-chat',
		storage: storageSession
	};

	 	const config = {
		 	channel: 'telstra-lcp-chat_broadcast_channel',
			initiateWithState: true,
		  blacklist: [
				ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG,
				ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG_SUCCESS,
				ChatEntryActionTypes.CHAT_ENABLE,
				ChatSessionActionTypes.CHAT_ENABLE,
				ChatSessionActionTypes.CHAT_SESSION_REQUEST,
				ChatSessionActionTypes.CHAT_MESSAGES_REQUEST,
				ChatSessionActionTypes.CHAT_INIT_REQUEST,
				ChatSessionActionTypes.CHAT_SERVICES_INIT,
				ChatEndActionTypes.CHAT_END_REQUEST,
				ChatGlobalActionTypes.REHYDRATE
			],
			whitelist: [],
		 	broadcastChannelOption: null,
			predicate: null
	 };

	 const syncMiddleware = createStateSyncMiddleware(config);

	 const sagaMiddleware = createSagaMiddleware();

	 const middleware = [ thunk, sagaMiddleware, syncMiddleware ];

//	const middleware = [thunk];

	const composeEnhancers =
		typeof window === 'object' && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
			? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({})
			: compose;

	const enhancer = composeEnhancers(applyMiddleware(...middleware));

	const persistedReducer = persistReducer(persistConfig, rootReducer);

	let mergedInitialIncomingState = mergedState(configOptions);

	let store = createStore(persistedReducer, mergedInitialIncomingState, enhancer);
//	let store = createStore(rootReducer, initialState, enhancer);
	let persistor = persistStore(store);

//	initStateWithPrevTab(store);

	 sagaMiddleware.run(rootSaga);

	return { store, persistor };
};
