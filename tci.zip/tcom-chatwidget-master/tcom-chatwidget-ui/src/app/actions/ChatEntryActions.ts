import { ChatEntryActionTypes } from './ChatActionTypes';
import { ChatState } from '@cm-types/types';
import { NormalizedChatManagerConfig } from '@cm-types/IChatManagerConfig';
import * as CustomEvent from 'custom-event';

export const onLoadChatEntry = (pageConfig: NormalizedChatManagerConfig) => {
	dispatchStateChangeEvent(pageConfig.configuration.chatButton ? ChatState.ACTIVE : ChatState.INACTIVE);
	return {
	type: ChatEntryActionTypes.CHAT_ENABLE,
	payload: {
		status: pageConfig.configuration.chatButton ? ChatState.ACTIVE : ChatState.INACTIVE,
		slideout: pageConfig.configuration.chatSlideoutEnabled,
		slideOutTitle: pageConfig.configuration.chatSlideout.title,
		slideOutTitleIcon: pageConfig.configuration.chatSlideout.image,
		slideOutBody: pageConfig.configuration.chatSlideout.text,
		slideOutButtonText: pageConfig.configuration.chatSlideout.linkText,
		slideOutScrollHeight: pageConfig.configuration.chatSlideout.rules.scroll,
		fabTitle: pageConfig.configuration.chatButtonConfig.text,
		fabIcon: pageConfig.configuration.chatButtonConfig.image,
		fabBackGroundColor: pageConfig.configuration.chatButtonConfig.backgroundColor
	}
}
};

export const dispatchStateChangeEvent = (chatState: string) => {
	let event = new CustomEvent("@@event/salesforce/store", {
		bubbles: true,
		detail: {
			chatState: chatState
		}
	});

	let sfTag: any = document.getElementById('chat-root');
	sfTag.dispatchEvent(event);
}

export const openChatWindow = () => {

	dispatchStateChangeEvent(ChatState.MAXIMIZE);

	return {
		type: ChatEntryActionTypes.CHAT_OPEN,
		payload: ChatState.MAXIMIZE
	}
};

export const closeSlideOut = () => ({
	type: ChatEntryActionTypes.CLOSE_SLIDEOUT,
	payload: false
});

export const initiateChatFromSlideOut = () => {

	dispatchStateChangeEvent(ChatState.MAXIMIZE);

	return {
		type: ChatEntryActionTypes.CHAT_OPEN_SLIDEOUT,
		payload: {
			slideout: false,
			status: ChatState.MAXIMIZE
		}
	}
};

export const onMinimize = () => {

	dispatchStateChangeEvent(ChatState.MINIMIZE);

	return {
		type: ChatEntryActionTypes.CHAT_MINIMIZE,
		payload: ChatState.MINIMIZE
	}
};


export const fetchChatManagerConfig = () => ({
		type: ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG
});

export const refetchChatManagerConfig = () => ({
		type: ChatEntryActionTypes.REFETCH_CHAT_MANAGER_CONFIG
});

export function updateFABHeader(header?: string) {
	return {
		type: ChatEntryActionTypes.UPDATE_FAB_HEADER,
		payload: {
			fabMinimizedTitle: header
		}
	};
}
