import { ChatGlobalActionTypes } from './ChatActionTypes';
import { ChatEntryState } from '../state/ApplicationState';
import { ChatState  } from '@cm-types/types';
import { dispatchStateChangeEvent } from './ChatEntryActions';

export const resetChatState = () => {
		dispatchStateChangeEvent('CHAT_RESET');
	return {
			type: ChatGlobalActionTypes.CHAT_RESET
	}
}

export const getIniteState = () => ({
	type: ChatGlobalActionTypes.CHAT_GET_INIT_STATE
});

export const sendIniteState = () => ({
	type: ChatGlobalActionTypes.CHAT_SEND_INIT_STATE
});

export function receiveIniteState(state): any {
	return async function (dispatch: any, getState: any) {
		let chatEntryState: ChatEntryState = state.chatEntry;
		let status = chatEntryState.status;
		if (status === ChatState.MAXIMIZE || status === ChatState.MINIMIZE) {
				await dispatch(dispatchReceiveIniteState(state));
			}
	}
}

export const dispatchReceiveIniteState = (state: any) => ({
	type: ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE,
	payload: state
});
