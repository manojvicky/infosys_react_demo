import { ChatSessionActionTypes } from './ChatActionTypes';
import { ChatState, ConnectionState, ResponseTypes, AgentStatus, MessageTypes, MessageStatus, IMessageMetadata } from '@cm-types/types';
import { updateFABHeader } from './ChatEntryActions';
import { onPreChatEnd } from './ChatEndActions'
import { IMessage, UserTypes, EndState } from '@cm-types/types';
import { NormalizedChatManagerConfig } from '@cm-types/IChatManagerConfig';
import { ChatEntryState, ChatSessionState } from '../state/ApplicationState';
import { ChatMessagesResponse } from '../models/ChatMessagesResponse';
import { APIServicesClient } from '../services/APIServicesClient';
import { LeaderBoardService } from '../services/LeaderBoardService';
import { ChatUIUtil } from '../util/ChatUIUtil';
import { AGENT } from '../constants/DefaultConstants';
import * as _ from 'lodash';

export const onLoadSessionChat = (pageConfig: NormalizedChatManagerConfig) => ({
	type: ChatSessionActionTypes.CHAT_ENABLE,
	payload: {
		announcement: pageConfig.configuration.systemAnnouncement.enabled,
		announcementText: pageConfig.configuration.systemAnnouncement.message,
		announcementLinkText: pageConfig.configuration.systemAnnouncement.linkText,
		announcementLink: pageConfig.configuration.systemAnnouncement.linkUrl,
		announcementLinkOpenNewTab: pageConfig.configuration.systemAnnouncement.openLinkInNewTab,
		connectHeaderTitle: pageConfig.configuration.chatLoading.header,
		connectWelcomeMessage: pageConfig.configuration.chatLoading.title,
		connectMessage: pageConfig.configuration.chatLoading.text,
		connectionFailureTitle: pageConfig.configuration.chatLoadingConnectionError.title,
		connectionFailureMessage: pageConfig.configuration.chatLoadingConnectionError.text,
		connectionFailureIcon: pageConfig.configuration.chatLoadingConnectionError.icon,
		noAgentTitle: pageConfig.configuration.chatAgentsOffline.title,
		noAgentMessage: pageConfig.configuration.chatAgentsOffline.text,
		noAgentIcon: pageConfig.configuration.chatAgentsOffline.icon,
		chatEndedMsg: pageConfig.configuration.headerMessage.chatEnded,
		buttonId: pageConfig.configuration.buttonId,
		organizationId: pageConfig.configuration.organizationId,
		deploymentId: pageConfig.configuration.deploymentId,
		queueHeader: pageConfig.configuration.chatInQueue.header,
		queueMessage: pageConfig.configuration.chatInQueue.text,
		queueSubMessage: pageConfig.configuration.chatInQueue.subtext,
		queueIcon: pageConfig.configuration.chatInQueue.icon,
		welcomeMessage: pageConfig.configuration.interactiveMessages.welcomeMessage,
		transferMessage: pageConfig.configuration.interactiveMessages.transferMessage,
		endChatMessage: pageConfig.configuration.interactiveMessages.endChatMessage,
		endChatByAgentMessage: pageConfig.configuration.interactiveMessages.endChatByAgentMessage,
	}
});

export const onCloseAnnoucementHandler = () => ({
	type: ChatSessionActionTypes.CLOSE_ANNOUNCEMENT,
	payload: {
		closeAnnouncement: true
	}
});

export function initServices(): any {
	return async function (dispatch: any, getState: any) {
		await dispatch(requestChatServiceInit());
		await dispatch(retrieveSurvey());
	}
}

export function connectToChat(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let connectionStatus = chatSessionState.connectionStatus;
		if (connectionStatus === ConnectionState.INITIAL || connectionStatus === ConnectionState.FAILURE) {
			//if(LeaderBoardService.isLeader){
				await dispatch(fetchChatSession());
			//}
		}
	}
}

export function establishSession(): any {
	return async function (dispatch: any, getState: any) {
		await dispatch({ type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
		await new Promise(resolve => setTimeout(resolve, 1000));

		await dispatch({ type: ChatSessionActionTypes.CHAT_MESSAGES_REQUEST });
		await dispatch({ type: ChatSessionActionTypes.CHAT_INIT_REQUEST });
	}
}

export function reInitiateLongPolling(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let connectionStatus = chatSessionState.connectionStatus;
		await APIServicesClient.initializeAPI(chatSessionState.serviceEndpointURL);

		if(LeaderBoardService.isLeader && connectionStatus === ConnectionState.IN_PROGRESS){
			await dispatch({ type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
			await new Promise(resolve => setTimeout(resolve, 1000));
			await dispatch({ type: ChatSessionActionTypes.CHAT_MESSAGES_REQUEST });
		}
	}
}

export function retrieveSurvey(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		const surveyObject = await APIServicesClient.retrieveSurvey(
			chatSessionState.surveyEndpointURL,
		)
		if (surveyObject !== false ) {
			const formatSurveyObject = surveyObject.map(el => {
				return {
					questionId: el.Id,
					surveyId: el.Survey__c,
					type: el.Type__c,
					choices: el.Choices__c === undefined ? null : el.Choices__c.split('\r\n'),
					questionName: el.Name
				}
			})
			await dispatch({ type: ChatSessionActionTypes.CHAT_RETRIEVE_SURVEY, payload: { surveyObj: formatSurveyObject } })
			await dispatch({ type: ChatSessionActionTypes.SURVEY_AVAILABILITY, payload: { surveyAvailability: true } })
		} else {
			await dispatch({ type: ChatSessionActionTypes.SURVEY_AVAILABILITY, payload: { surveyAvailability: false } })
		}

	}
}


interface SingleResponse {
	id?: string;
	response?: string;
}

interface SurveyResponse {
	allQuestions? : SingleResponse[],
	chatKey?: string;
	survey?: string;
}

export function submitSurvey(surveyResponse: SurveyResponse ): any {

	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		await APIServicesClient.submitSurvey(
			chatSessionState.surveyEndpointURL,
			surveyResponse
			)
		await dispatch({ type: ChatSessionActionTypes.SURVEY_SUBMITTED, payload: { submittedSurvey: true } })
	}
}

export function postMessage(messageText: string): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		//await new Promise(resolve => setTimeout(resolve, 300));
		let sequenceNumber: any = chatSessionState.sequenceNumber;
		let encryptedMsg = encryptSensitiveData(messageText, getState);
		const chatPostMessagesResponse: ChatMessagesResponse = await APIServicesClient.postMessages(
			chatSessionState.serviceEndpointURL,
			chatSessionState.affinityToken,
			chatSessionState.apiVersion,
			chatSessionState.sessionKey,
			sequenceNumber.toString(),
			encryptedMsg
		);
		let deliveryStatus = MessageStatus.FAILED;
		if (chatPostMessagesResponse) {
			deliveryStatus = MessageStatus.DELIVERED;
			await dispatch(incrementSeq(++sequenceNumber));
		} else {
			await dispatch(onMessageFailure(true, ConnectionState.IN_PROGRESS));
		}

		let messages = postMessageHelper(deliveryStatus, chatSessionState, messageText);
		const updatedMessages = updateAvatarStatus(messages)
		await dispatch(chatPostMessage(updatedMessages));
	};
}

export function postMessageHelper(
	deliveryStatus: MessageStatus,
	chatSessionState: ChatSessionState,
	messageText: string
) {
	let messagesPrev: any = chatSessionState.messages;
	let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
	let messages: any = messagesPrev.map((item: IMessage) => {
		return Object.assign({}, item);
	});
	let idCount = messageMetadata.idCount;
	let id = (deliveryStatus === MessageStatus.FAILED) ? ChatUIUtil.getUniqueFailedId(idCount) : ChatUIUtil.getUniqueId(idCount);

	let message: IMessage = ChatUIUtil.fetchTransformedMessage(
		id,
		messageText,
		MessageTypes.PLAIN_MESSAGE,
		UserTypes.CUSTOMER,
		deliveryStatus,
		ChatUIUtil.getUniqueKey(messageMetadata.keyCount)
	);
	messages.push(message);
	return messages;
}


export function retryPostMessage(messageText: string, key?: number): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		//await new Promise(resolve => setTimeout(resolve, 300));
		let sequenceNumber: any = chatSessionState.sequenceNumber;
		let encryptedMsg = encryptSensitiveData(messageText, getState);
		let messagesBefore = retryPostMessageHelper(MessageStatus.RETRY, chatSessionState, messageText, key);
		await dispatch(chatPostMessage(messagesBefore));

		await new Promise(resolve => setTimeout(resolve, 800));

		const chatPostMessagesResponse: ChatMessagesResponse = await APIServicesClient.postMessages(
			chatSessionState.serviceEndpointURL,
			chatSessionState.affinityToken,
			chatSessionState.apiVersion,
			chatSessionState.sessionKey,
			sequenceNumber.toString(),
			encryptedMsg
		);
		let deliveryStatus = MessageStatus.FAILED;
		if (chatPostMessagesResponse) {
			deliveryStatus = MessageStatus.DELIVERED;
			await dispatch(incrementSeq(++sequenceNumber));
		} else {
			await dispatch(onMessageFailure(true, ConnectionState.IN_PROGRESS));
		}

		let messages = retryPostMessageHelper(deliveryStatus, chatSessionState, messageText, key);
		await dispatch(chatPostMessage(messages));

	};
}


export function retryPostMessageHelper(
	deliveryStatus: MessageStatus,
	chatSessionState: ChatSessionState,
	messageText: string,
	key?: number
) {
	let messagesPrev: any = chatSessionState.messages;
	let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
	let messages: any = messagesPrev.map((item: IMessage) => {
		if (key === item.key) {
			item.status = deliveryStatus;
			if (item.status === MessageStatus.FAILED) {
				item.id = item.id ? item.id : ChatUIUtil.getUniqueFailedId(messageMetadata.failedIdCount)
			} else if (item.status === MessageStatus.RETRY) {
			} else {
				item.id = ChatUIUtil.getUniqueId(messageMetadata.idCount);
			}
		}
		return Object.assign({}, item);
	});
	return messages;
}


export function postChasitorTyping(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let sequenceNumber: any = chatSessionState.sequenceNumber;
	try{
		const chatPostChasitorTypingResponse: ChatMessagesResponse = await APIServicesClient.chasitorTyping(
			chatSessionState.serviceEndpointURL,
			chatSessionState.affinityToken,
			chatSessionState.apiVersion,
			chatSessionState.sessionKey,
			sequenceNumber.toString(),
		);

		if (chatPostChasitorTypingResponse) {
			await dispatch(incrementSeq(++sequenceNumber));
		}

	}catch(err){
		if(err && err.status == 403){
			await dispatch(onChatTimeout());
		}
	}

	};
}

export function postChasitorNotTyping(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let sequenceNumber: any = chatSessionState.sequenceNumber;
		try{
		const chatPostChasitorTypingResponse: ChatMessagesResponse = await APIServicesClient.chasitorNotTyping(
			chatSessionState.serviceEndpointURL,
			chatSessionState.affinityToken,
			chatSessionState.apiVersion,
			chatSessionState.sessionKey,
			sequenceNumber.toString(),
		);

		if (chatPostChasitorTypingResponse) {
			await	dispatch(incrementSeq(++sequenceNumber));
		}

	}catch(err){
		if(err && err.status == 403){
			await dispatch(onChatTimeout());
		}
	}

	};
}


export function chatRequestNoAgent(noAgentTitle?: string) {
	return {
		type: ChatSessionActionTypes.CHAT_MESSAGES_NO_AGENT,
		payload: {
			connectionStatus: ConnectionState.NO_AGENTS,
			chatHeaderTitle: noAgentTitle
		}
	};
}

export function chatRequestFailed(failureTitle?: string) {
	return {
		type: ChatSessionActionTypes.CHAT_MESSAGES_FAILURE,
		payload: {
			connectionStatus: ConnectionState.FAILURE,
			chatHeaderTitle: failureTitle
		}
	};
}

export function updateChatHeader(name?: string) {
	return {
		type: ChatSessionActionTypes.UPDATE_CHAT_HEADER,
		payload: {
			chatHeaderTitle: name,
			agentName: name
		}
	};
}

export function requestChatServiceInit() {
	return {
		type: ChatSessionActionTypes.CHAT_SERVICES_INIT
	};
}

export function requestLoadSession(header: string) {
	return {
		type: ChatSessionActionTypes.CHAT_LOAD_SESSION,
		payload: {
			connectionStatus: ConnectionState.PENDING,
			chatHeaderTitle: header
		}
	};
}

export function requestChatSession(header: string) {
	return {
		type: ChatSessionActionTypes.CHAT_SESSION_REQUEST
	};
}

export function fetchChatSession(): any {
	return function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let header: any = chatSessionState.connectHeaderTitle;
		dispatch(requestLoadSession(header));
		dispatch(requestChatSession(header));
		dispatch(updateFABHeader(header));

	}
}

export function onMessageProcess(messages: any, connectionStatus: ConnectionState) {
	return {
		type: ChatSessionActionTypes.CHAT_MESSAGES_PROCESS,
		payload: {
			messages: _.sortBy(messages, 'id'),
			connectionStatus
		}
	};
}

export function updateAvatarStatus( messages: any ) {
	const agent_msg_array = messages.filter(message => (message.actor === UserTypes.AGENT)).map(( message ) => message.id)
	let avatar_array: number[]
	avatar_array = []
	let i:number
	let prevIndex = agent_msg_array[agent_msg_array.length-1];
	for (i = agent_msg_array.length-1; i >=0 ; i--){
		let currentIndex = agent_msg_array[i]
		// Filter out consecutive messages
			if(currentIndex === prevIndex || currentIndex + 1 !== prevIndex){
				avatar_array.push(currentIndex)
			}
		prevIndex = currentIndex
	}
	const avatarStatusUpdatedMessages = messages.map(message => {
		if(avatar_array.filter(num => num === message.id).length === 1){
			const updatedMessage = {
				...message,
				avatar: true
			}
			return updatedMessage
		} else {
			const updatedMessage = {
				...message,
				avatar: false
			}
			return updatedMessage
		}

	})

	return avatarStatusUpdatedMessages
}

export function chatPostMessage(messages: any) {
	return {
		type: ChatSessionActionTypes.ADD_MESSAGE,
		payload: {
			messages: _.sortBy(messages, 'id'),
		}
	};
}

export function chatShowTypingIndicator(flag: boolean) {
	return {
		type: ChatSessionActionTypes.SHOW_TYPING_INDICATOR,
		payload: {
			showTypingIndicator: flag
		}
	};
}

export function updateQueuePosition(isInQueue: boolean, queueNum: number, connectionStatus: any) {
	return {
		type: ChatSessionActionTypes.UPDATE_QUEUE_POSITION,
		payload: {
			isInQueue: isInQueue,
			queueNum: queueNum,
			connectionStatus: connectionStatus
		}
	};
}

export function updateUnreadCounter(messageMetadata: IMessageMetadata) {
	return {
		type: ChatSessionActionTypes.UPDATE_UNREAD_COUNTER,
		payload: {
			messageMetadata
		}
	};
}


export function resetUnreadMessages(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;

		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		messageMetadata.unreadCount = 0;
		await dispatch(updateUnreadCounter({ ...messageMetadata }));

	}
}

export function resetUnreadMessagesStatus(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;

		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		let unreadCount: number = messageMetadata.unreadCount || 0;
		if (unreadCount > 0) {
			chatSessionState = getState().chatSession;
			let messages = chatSessionState.messages || [];
			let messagesClone: any = messages.map((item: IMessage) => {
				if (item.status === MessageStatus.UNREAD) {
					item.status = MessageStatus.READ
				}
				return Object.assign({}, item);
			});

			await dispatch(onMessageProcess(messagesClone, ConnectionState.IN_PROGRESS));
			await dispatch(resetUnreadMessages());
		}

	}
}

export function incrementAck(ack: number) {
	return {
		type: ChatSessionActionTypes.INCREMENT_ACK,
		payload: {
			ack
		}
	};
}

export function playTrack(flag: boolean){
	return{
    type: ChatSessionActionTypes.PLAY_ALERT_AUDIO,
    payload:{
			play: flag
	}
};
}

export function incrementPc(pc: number) {
	return {
		type: ChatSessionActionTypes.INCREMENT_PC,
		payload: {
			pc
		}
	};
}

export function incrementSeq(sequenceNumber: number) {
	return {
		type: ChatSessionActionTypes.INCREMENT_SEQ,
		payload: {
			sequenceNumber
		}
	};
}

export function onMessageFailure(flag: boolean, connectionStatus: ConnectionState) {
	return {
		type: ChatSessionActionTypes.CHAT_ERROR,
		payload: {
			connectionStatus: connectionStatus
		}
	};
}

export function updateIncomingMessagesSequence(incomingMessagesSequence: any) {
	return {
		type: ChatSessionActionTypes.INCOMING_SEQUENCE,
		payload: {
			incomingMessagesSequence
		}
	}
}

export function updateSensitiveDataRules(sensitiveDataRules: any) {
	return {
		type: ChatSessionActionTypes.UPDATE_SENSITIVE_RULES,
		payload: {
			sensitiveDataRules
		}
	};
}

export function onMessageSuccess(messages: any, sequence: number): any {
	return function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;
		let incomingMessagesSequence = chatSessionState.incomingMessagesSequence;
		//	let itemFound = _.indexOf(incomingMessagesSequence, sequence);
		//	console.log('itemFound'+ itemFound + ' sequence '+sequence);
		//if(itemFound < 0){
		incomingMessagesSequence.push(sequence);
		let incomingMessagesSequenceClone = [...incomingMessagesSequence];
		dispatch(updateIncomingMessagesSequence(incomingMessagesSequenceClone));
		messages.map((item: any) => {
			switch (item.type) {
				case ResponseTypes.CHAT_REQUEST_FAIL:
					(async () => {
						await dispatch(onChatRequestFailure(item.message.reason));
					})();
					break;
				case ResponseTypes.CHAT_REQUEST_SUCCESS:
					(async () => {
						await dispatch(onChatRequestSuccess(item.message.queuePosition));
						await dispatch(updateSensitiveDataRules(item.message.sensitiveDataRules));
					})();
					break;
				case ResponseTypes.CHAT_ESTABLISHED:
					(async () => {
						await dispatch(onChatEstablished(item.message.name));
						await dispatch(playTrack(true));
					})();
					break;
				case ResponseTypes.QUEUE_UPDATE:
					(async () => {
						await dispatch(onQueueUpdate(item.message.position));
					})();
					break;
				case ResponseTypes.CHAT_MESSAGE:
					(async () => {
						await dispatch(chatShowTypingIndicator(false));
						await dispatch(onChatMessage(item.message.text));
					})();
					break;
				case ResponseTypes.CHAT_TRANSFERRED:
					(async () => {
						await dispatch(onChatTransfer());
						await dispatch(updateChatHeader(item.message.name));
						await dispatch(updateFABHeader(item.message.name));
					})();
					break;
				case ResponseTypes.AGENT_TYPING:
					(async () => {
						await dispatch(chatShowTypingIndicator(true));
						await dispatch(onUpdateAvatar(false));
					})();
					break;
				case ResponseTypes.AGENT_NOT_TYPING:
					(async () => {
						await dispatch(chatShowTypingIndicator(false));
						await dispatch(onUpdateAvatar(true));
					})();
					break;
				case ResponseTypes.CHAT_ENDED:
					(async () => {
					await dispatch(onChatEnd(item.message.reason));
				})();
					break;
				default: {
					break;
				}
			}
		});
		//}
	};
}

export function onChatEstablished(agentName: string): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;

		if (agentName) {
			dispatch(updateChatHeader(agentName));
			dispatch(updateFABHeader(agentName));

			let messagesPrev: any = chatSessionState.messages || [];
			let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
			let messagesClone: any = [...messagesPrev];
			let welcomeMessage = chatSessionState.welcomeMessage;
			welcomeMessage = welcomeMessage.replace('##agentName##', agentName);

			let { idCount, keyCount } = messageMetadata;
			let messageNew: IMessage = ChatUIUtil.fetchTransformedMessage(
				ChatUIUtil.getUniqueId(idCount),
				welcomeMessage,
				MessageTypes.WELCOME_MESSAGE,
				UserTypes.SYSTEM,
				MessageStatus.RECIEVED,
				ChatUIUtil.getUniqueKey(keyCount)
			);
			messagesClone.push(messageNew);
			await dispatch(onMessageProcess(messagesClone, ConnectionState.SUCCESS));
		}
	};
}

export function onChatRequestFailure(reason: string): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		if (reason === AgentStatus.UNAVAILABLE) {

				if(chatSessionState.connectionStatus == ConnectionState.IN_PROGRESS){
						await dispatch(onChatEnd(AGENT));
				}else{
					await dispatch(chatRequestNoAgent(chatSessionState.noAgentTitle));
					await dispatch(updateFABHeader(chatSessionState.noAgentTitle));
				}
			//await dispatch({type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
	}else{
		await dispatch(chatRequestFailed(chatSessionState.connectionFailureTitle));
		await dispatch(updateFABHeader(chatSessionState.connectionFailureTitle));

		await dispatch({type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
	}
}
}

export function onChatRequestSuccess(queuePosition: number): any {
	return async function (dispatch: any, getState: any) {
		if (queuePosition > 0) {
			await dispatch(updateQueuePosition(true, queuePosition, ConnectionState.QUEUED));
		} else {
			await dispatch(updateQueuePosition(false, 0, ConnectionState.SUCCESS));
		}
	};
}

export function onQueueUpdate(queuePosition: number): any {
	return async function (dispatch: any, getState: any) {
		if (queuePosition > 0) {
			await dispatch(updateQueuePosition(true, queuePosition, ConnectionState.QUEUED));
		} else {
			await dispatch(updateQueuePosition(false, 0, ConnectionState.SUCCESS));
		}
	};
}

export function onChatMessage(rawMessageText: any): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;
		let chatEntryState: ChatEntryState = getState().chatEntry;
		let messagesPrev: any = chatSessionState.messages || [];
		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		let messagesClone: any = [...messagesPrev];

		let messageText = rawMessageText;
		let messageType: any, messageObject: any;

		try {
			messageObject = JSON.parse(messageText);
		} catch (e) { }

		messageType = messageObject && messageObject.type ? MessageTypes.CUSTOM_CARD : MessageTypes.PLAIN_MESSAGE;

		let deliveryStatus = chatEntryState.status === ChatState.MINIMIZE ? MessageStatus.UNREAD : MessageStatus.DELIVERED;

		let { idCount, keyCount } = messageMetadata;
		let arrivedMessage: IMessage = ChatUIUtil.fetchTransformedMessage(
			ChatUIUtil.getUniqueId(idCount),
			messageText,
			messageType,
			UserTypes.AGENT,
			deliveryStatus,
			ChatUIUtil.getUniqueKey(keyCount),
			true
		);

		messagesClone.push(arrivedMessage);
		// Updating the message.avatar boolean to be true or false
		const updatedMessages = updateAvatarStatus(messagesClone)
		await dispatch(onMessageProcess(updatedMessages, ConnectionState.IN_PROGRESS));

		if(deliveryStatus == MessageStatus.UNREAD){
			await dispatch(playTrack(true));
		}

	};
}

export function onUpdateAvatar(avatarBol: boolean): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;
		let messagesPrev: any = chatSessionState.messages || [];
		let messagesClone: any = [...messagesPrev];
		messagesClone[messagesClone.length-1].avatar = avatarBol
		await dispatch(onMessageProcess(messagesClone, ConnectionState.IN_PROGRESS));
	};
}

export function onChatTransfer(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;
		let messagesPrev: any = chatSessionState.messages || [];
		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		let messagesClone: any = [...messagesPrev];
		let transferMessage = chatSessionState.transferMessage;
		let messageTransfer: IMessage = ChatUIUtil.fetchTransformedMessage(
			ChatUIUtil.getUniqueId(messageMetadata.idCount),
			transferMessage,
			MessageTypes.TRANSFER_MESSAGE,
			UserTypes.SYSTEM,
			MessageStatus.RECIEVED,
			ChatUIUtil.getUniqueKey(messageMetadata.keyCount)
		);
		messagesClone.push(messageTransfer);
		await dispatch(onMessageProcess(messagesClone, ConnectionState.IN_PROGRESS));
	};
}

export function onChatTimeout(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;

		dispatch(updateChatHeader(chatSessionState.chatEndedMsg));
		dispatch(updateFABHeader(chatSessionState.chatEndedMsg));

		let messagesPrev: any = chatSessionState.messages || [];
		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		let messagesClone: any = [...messagesPrev];
		let transferMessage = chatSessionState.endChatMessage;
		let messageTransfer: IMessage = ChatUIUtil.fetchTransformedMessage(
			ChatUIUtil.getUniqueId(messageMetadata.idCount),
			transferMessage,
			MessageTypes.TRANSFER_MESSAGE,
			UserTypes.SYSTEM,
			MessageStatus.RECIEVED,
			ChatUIUtil.getUniqueKey(messageMetadata.keyCount)
		);
		messagesClone.push(messageTransfer);
		await dispatch(onMessageProcess(messagesClone, ConnectionState.TIMED_OUT));

		dispatch({ type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
	};
}

export function onChatEnd(reason: string): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState = getState().chatSession;

		dispatch(updateChatHeader(chatSessionState.chatEndedMsg));
		dispatch(updateFABHeader(chatSessionState.chatEndedMsg));
		let messagesPrev: any = chatSessionState.messages || [];
		let messageMetadata: IMessageMetadata = chatSessionState.messageMetadata || {};
		let messagesClone: any = [...messagesPrev];
		let endMessage = (reason === AGENT) ? chatSessionState.endChatByAgentMessage : chatSessionState.endChatMessage;
		endMessage = endMessage.replace('##agentName##', chatSessionState.agentName);
		let messageEnded: IMessage = ChatUIUtil.fetchTransformedMessage(
			ChatUIUtil.getUniqueId(messageMetadata.idCount),
			endMessage,
			MessageTypes.END_MESSAGE,
			reason === AGENT ? UserTypes.AGENT : UserTypes.CUSTOMER,
			MessageStatus.RECIEVED,
			ChatUIUtil.getUniqueKey(messageMetadata.keyCount)
		);
		messagesClone.push(messageEnded);
		await dispatch(onMessageProcess(messagesClone, ConnectionState.ENDED));

		dispatch({type: ChatSessionActionTypes.CHAT_STOP_MESSAGES });
		dispatch(onPreChatEnd(reason === AGENT ? EndState.AGENT_END_CHAT : EndState.END));
	};
}

export function encryptSensitiveData(messageText: string, getState: any){
		let chatSessionState = getState().chatSession;
		let sensitiveDataRule = chatSessionState.sensitiveDataRules || {};

		for(let index in sensitiveDataRule) {
			while (messageText.match(new RegExp(sensitiveDataRule[index].pattern))) {
				messageText = messageText.replace(new RegExp(sensitiveDataRule[index].pattern), sensitiveDataRule[index].replacement);
			}
		}
	return messageText;
}
