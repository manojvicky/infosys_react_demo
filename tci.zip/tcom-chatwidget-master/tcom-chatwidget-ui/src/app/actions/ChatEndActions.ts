import { ChatEndActionTypes, ChatSessionActionTypes } from './ChatActionTypes';
import { ChatSessionState, ChatEndState } from '../state/ApplicationState';
import { onChatEnd, updateChatHeader } from './ChatSessionActions';
import { refetchChatManagerConfig, updateFABHeader } from './ChatEntryActions';
import { resetChatState } from './ChatGlobalActions';
import { ConnectionState, EndState, UserTypes } from '@cm-types/types';

export function onCloseSession(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		let chatEndState: ChatEndState = getState().chatEnd;
		if(chatSessionState.connectionStatus === ConnectionState.IN_PROGRESS ||
			chatSessionState.connectionStatus === ConnectionState.PENDING ||
			chatSessionState.connectionStatus === ConnectionState.QUEUED){
			await dispatch(onPreChatEnd(EndState.BEFORE_END));
		} else if (chatEndState.chatEndStatus === EndState.AGENT_END_CHAT){
			if (chatSessionState.surveyAvailability === false){
				await dispatch(resetChatState());
				await dispatch(refetchChatManagerConfig());
			} else {
				await dispatch(onPreChatEnd(EndState.END));
			}
		}
		else{
			await dispatch({type: ChatSessionActionTypes.CHAT_STOP_MESSAGES});
			await dispatch(resetChatState());
			await dispatch(refetchChatManagerConfig());
		}
	}
}

export function onClickChatEnd(): any {
	return async function (dispatch: any, getState: any) {
		let chatSessionState: ChatSessionState = getState().chatSession;
		await dispatch({type: ChatEndActionTypes.CHAT_END_REQUEST});
		await dispatch({type: ChatSessionActionTypes.CHAT_STOP_MESSAGES});
		await dispatch(onPreChatEnd(EndState.END));
		await dispatch(onChatEnd(UserTypes.CUSTOMER));
		if ( (chatSessionState.connectionStatus !== ConnectionState.PENDING && chatSessionState.connectionStatus !== ConnectionState.QUEUED)
				&& chatSessionState.surveyAvailability === true){
				await dispatch(updateChatHeader(chatSessionState.chatEndedMsg));
				await dispatch(updateFABHeader(chatSessionState.chatEndedMsg));
			} else {
				await dispatch(resetChatState());
				await dispatch(refetchChatManagerConfig());
			}
	}
}


export function onPreChatEnd(chatEndState :EndState) {
	return {
		type: ChatEndActionTypes.CHAT_PRE_END,
		payload: {
			chatEndStatus: chatEndState
		}
	};
}
