import './styles.scss';
import * as React from 'react';
import {
	ChatFAB,
	ChatFABSlideOut,
	Sound
} from '@cm-components/ComponentList';

interface ChatEntryProps {
	slideout?: string;
}
export class ChatEntry extends React.Component<ChatEntryProps> {
	constructor(props: any) {
		super(props);
	}

  render() {
    return (
      <React.Fragment>
        <ChatFAB />
        {this.props.slideout && <ChatFABSlideOut />}
				<Sound/>
      </React.Fragment>
    );
  }
}
