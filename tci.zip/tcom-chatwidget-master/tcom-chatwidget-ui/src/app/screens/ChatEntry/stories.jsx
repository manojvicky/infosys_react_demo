import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatEntry } from './ChatEntry';

storiesOf('Screens|ChatEntry', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatEntry/>
	));
