import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatEntry } from './ChatEntry.ui';

const mapStateToProps = ({ chatEntry }: ApplicationState) => ({
	slideout: chatEntry.slideout
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatEntry);
