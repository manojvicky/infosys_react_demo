import './styles.scss';
import * as React from 'react';
import {
	ChatPanel,
	ChatHeader,
	ChatBody,
	ChatButton,
	ChatRadioButton,
	ChatTextarea
} from '@cm-components/ComponentList';
import classNames from 'classnames';
import { CSS_PREFIX } from '@cm-constants/DefaultConstants';

interface SingleResponse {
	id: string;
	response: string;
	hasContent: boolean;
}

interface SurveyResponse {
	allQuestions? : SingleResponse[],
	chatKey?: string;
	survey?: string;
}

export interface SurveyObj {
	choices?: string[],
	questionId: string,
	questionName: string,
	surveyId: string,
	type: string,
}

interface ChatFinishProps {
	onClickSendTranscript?: () => void;
	sendTranscriptBtnText?: string;
	sendFeedbackBtnText?: string;
	sendCloseWindowBtnText?: string;
	sessionId: string;
	sessionKey: string;
	surveyObject: SurveyObj[];
	submittedSurvey: boolean;
	onClose(): void;
	onSendFeedback(feedback: SurveyResponse): void;
	tickIcon: string;
}

interface ChatFinishStates {
	letterCount: number;
	enableSubmit: boolean;
	surveyResponse: SurveyResponse;
}

export class ChatFinish extends React.Component<ChatFinishProps, ChatFinishStates> {
	constructor(props: any) {

		super(props);
		this.state = {
			letterCount: 0,
			enableSubmit: false,
			surveyResponse: {
				allQuestions: [],
				chatKey: '',
				survey: ''
			}
		}
		this.handleTextareaChange = this.handleTextareaChange.bind(this)
	}

	componentDidMount(){
		let allSurveyQuestions = this.props.surveyObject.map((item:SurveyObj) => {
			return {
				id: item.questionId,
				response: '',
				hasContent: false
			}
		})
		let updatedSurveyResponse = {
			...this.state.surveyResponse,
			allQuestions: allSurveyQuestions,
			chatKey: this.props.sessionId,
			survey: this.props.surveyObject[0].surveyId
		}

		this.setState({
			surveyResponse:updatedSurveyResponse
		})
	}

	handleOptionChange(e:any){
		const questionId = e.target.id
		let updatedQuestions = this.state.surveyResponse.allQuestions || []
		updatedQuestions.map((item)=>{
			if(item.id === questionId){
				item.response = e.target.value
				item.hasContent = true
				return item
			} else {
				return item
			}
		})

		let updatedSurveyResponse = this.state.surveyResponse
		updatedSurveyResponse = {
			...updatedSurveyResponse
		}

		let updatedEnableSubmit = this.checkEnableSubmit()

		this.setState({
			surveyResponse: updatedSurveyResponse,
			enableSubmit: updatedEnableSubmit
		})
	}


	handleTextareaChange(e:any){
		let updatedQuestions = this.state.surveyResponse.allQuestions || []
		const questionId = e.target.id
		updatedQuestions.map((item)=>{
			if (item.id === questionId){
				item.response = e.currentTarget.value
				if(e.currentTarget.value.length === 0){
					item.hasContent = false
				} else {
					item.hasContent = true
				}
				return item
			} else {
				return item
			}
		})

		let updatedSurveyResponse = this.state.surveyResponse
		updatedSurveyResponse = {
			...updatedSurveyResponse,
			allQuestions: updatedQuestions
		}

		let updatedEnableSubmit = this.checkEnableSubmit()

		this.setState({
			enableSubmit: updatedEnableSubmit,
			letterCount: e.currentTarget.value.length,
			surveyResponse: updatedSurveyResponse
		})
	}

	checkEnableSubmit(){
		let hasContentArry = this.state.surveyResponse.allQuestions || []
		let updatedEnableSubmit = hasContentArry.filter((item)=>(item.hasContent ===true)).length > 0
		return updatedEnableSubmit
	}

  render() {
    return (
				<ChatPanel>
					<ChatHeader />
					<ChatBody>
						<div className={classNames(CSS_PREFIX + '-chat-finish')}>
						{this.props.submittedSurvey ? null :

						this.props.surveyObject.map((data:any, i)=>{
								return (
								<div key={i} className={classNames('survey-question-block')}>
									<p className={classNames('survey-question')}>{data.questionName}</p>
									{	data.type.replace(/\s+/g, '')!=="FreeText"?(
										data.choices.map((choice:any, i)=>{
											return (
												<ChatRadioButton key = {i} text = {choice} checked={data.hasContent} id = {data.questionId}
												onChange = {(e)=>this.handleOptionChange(e)}
												/>
											)
										})
									) : (
										<ChatTextarea id = {data.questionId} onChange = {this.handleTextareaChange}/>
										)}
								</div>
								)
						}) }
						{this.props.submittedSurvey ? <div>
							<p className={classNames('survey-submitted')}>
							<img src={this.props.tickIcon} className="survey-tick" alt="survey done"/> Thank you for your feedback
							</p>
							</div> :
						<ChatButton type='primary' disabled={!this.state.enableSubmit} handleClick={this.state.enableSubmit?()=>{this.props.onSendFeedback(this.state.surveyResponse)}: undefined }>{this.props.sendFeedbackBtnText}</ChatButton>}
						<ChatButton type='secondary' paddingTop={'16px'} handleClick={this.props.onClose}>{this.props.sendCloseWindowBtnText}</ChatButton>
						</div>
					</ChatBody>
				</ChatPanel>
    );
  }
}
