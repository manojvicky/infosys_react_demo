import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatFinish } from './ChatFinish.ui';
import { onCloseSession } from '../../actions/ChatEndActions';
import { submitSurvey } from '@cm-app/actions/ChatSessionActions';

interface SingleResponse {
	id?: string;
	response?: string;
}

interface SurveyResponse {
	allQuestions? : SingleResponse[],
	chatKey?: string;
	survey?: string;
}

const mapStateToProps = ({ chatSession }: ApplicationState) => ({
	sendTranscriptBtnText: chatSession.sendTranscriptBtnText,
	sendFeedbackBtnText: chatSession.sendFeedbackBtnText,
	sendCloseWindowBtnText: chatSession.sendCloseWindowBtnText,
	sessionId: chatSession.sessionId,
	sessionKey: chatSession.sessionKey,
	surveyObject: chatSession.surveyObj,
	submittedSurvey: chatSession.submittedSurvey,
	tickIcon: chatSession.tickIcon
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
	onClose: () => dispatch(onCloseSession()),
	onSendFeedback: (surveyResponse:SurveyResponse) => {
		let finalAllQuestions = surveyResponse.allQuestions || []
		finalAllQuestions = finalAllQuestions.map((item) => {
			return {
				id: item.id,
				response: item.response
			}
		})
		let finalSurveyResponse = {
			...surveyResponse,
			allQuestions: finalAllQuestions
		}
		dispatch(submitSurvey(finalSurveyResponse))
	}
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatFinish);
