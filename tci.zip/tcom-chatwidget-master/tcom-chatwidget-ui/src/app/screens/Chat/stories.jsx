import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { Chat } from './Chat.ui';

storiesOf('Screens|Chat', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <Chat/>
	));
