import './styles.scss';
import * as React from 'react';
import {
	ChatPanel,
	ChatHeader,
	ChatBody,
	ChatMessage,
	ChatAnnouncement,
	ChatFooter,
	ChatModal,
	PreChatEnd,
	ChatComposer,
	Sound
} from '@cm-components/ComponentList';
import { ConnectionState, EndState } from '@cm-types/types';

interface ChatProps {
	announcement?: boolean;
	closeAnnouncement?: boolean;
	connectionStatus?: string;
	chatEndStatus?: EndState;
}
export class Chat extends React.Component<ChatProps> {
	constructor(props: any) {
		super(props);
	}

  render() {
    return (
			<React.Fragment>
				<ChatPanel>
					<ChatHeader />
					{this.props.announcement && !this.props.closeAnnouncement && <ChatAnnouncement />}
					<ChatBody>
						<ChatMessage />
					</ChatBody>
					<ChatFooter>
						{this.props.connectionStatus === ConnectionState.SUCCESS ||
						this.props.connectionStatus === ConnectionState.IN_PROGRESS ||
						this.props.chatEndStatus !== EndState.AGENT_END_CHAT ? (
							<ChatComposer />
						) : null}
					</ChatFooter>
				</ChatPanel>
				{this.props.chatEndStatus === EndState.BEFORE_END &&
					<ChatModal>
						<PreChatEnd/>
					</ChatModal>
				 }
				<Sound/>
			</React.Fragment>
    );
  }
}
