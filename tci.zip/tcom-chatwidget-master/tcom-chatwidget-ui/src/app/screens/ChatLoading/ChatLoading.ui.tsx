import './styles.scss';
import * as React from 'react';
import {
	ChatPanel,
	ChatHeader,
	ChatBody,
	ChatConnect,
	ChatAnnouncement,
	ChatModal,
	PreChatEnd
} from '@cm-components/ComponentList';
import { ConnectionState, EndState } from '@cm-types/types';

interface ChatLoadingProps {
	announcement?: boolean;
	closeAnnouncement?: boolean;
	connectionStatus?: string;
	chatEndStatus?: EndState;
}
export class ChatLoading extends React.Component<ChatLoadingProps> {
	constructor(props: any) {
		super(props);
	}

  render() {
    return (
			<React.Fragment>
				<ChatPanel>
					<ChatHeader />
					{this.props.announcement && !this.props.closeAnnouncement && <ChatAnnouncement />}
					<ChatBody>
						{this.props.connectionStatus === ConnectionState.PENDING ||
						this.props.connectionStatus === ConnectionState.FAILURE ||
						this.props.connectionStatus === ConnectionState.NO_AGENTS ||
						this.props.connectionStatus === ConnectionState.QUEUED ? (
							<ChatConnect />
						) : null}
					</ChatBody>
				</ChatPanel>
				{this.props.chatEndStatus === EndState.BEFORE_END &&
					<ChatModal>
						<PreChatEnd/>
					</ChatModal>
				 }
			</React.Fragment>
    );
  }
}
