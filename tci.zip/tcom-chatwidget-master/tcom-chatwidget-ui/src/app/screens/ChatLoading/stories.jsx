import * as React from 'react';
import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { withKnobs, boolean, text, color } from '@storybook/addon-knobs';
import { ChatLoading } from './ChatLoading';

storiesOf('Screens|ChatLoading', module)
	.addDecorator(withKnobs)
	.add('small', () => (
    <ChatLoading/>
	));
