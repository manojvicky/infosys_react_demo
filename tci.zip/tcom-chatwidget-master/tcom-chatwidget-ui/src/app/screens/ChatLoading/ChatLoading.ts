import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { ApplicationState } from '../../state/ApplicationState';
import { ChatLoading } from './ChatLoading.ui';

const mapStateToProps = ({ chatSession, chatEnd }: ApplicationState) => ({
	announcement: chatSession.announcement,
	closeAnnouncement: chatSession.closeAnnouncement,
	connectionStatus: chatSession.connectionStatus,
	chatEndStatus: chatEnd.chatEndStatus
});

const mapDispatchToProps = (dispatch: Dispatch) => ({
});

export default connect(
	mapStateToProps,
	mapDispatchToProps
)(ChatLoading);
