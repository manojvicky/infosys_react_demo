/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-11T08:57:19+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-11T08:58:55+11:00
 * @Copyright: Telstra 2018
 */

import { IMessage, MessageTypes, UserTypes, MessageStatus } from '@cm-types/types';

export class ChatUIUtil {
	static fetchTransformedMessage(
		id: number,
		text?: string,
		type?: MessageTypes,
		actor?: UserTypes,
		status?: MessageStatus,
		key?: number,
		avatar?: boolean
	): IMessage {
		let message: IMessage = { id };
		if (text) {
			message = {
				id,
				text,
				type,
				actor,
				status,
				timestamp: this.getTime(),
				key,
				avatar
			};
		}
		return message;
	}

	//static uniqueId: number = 0;
	//static uniqueKey: number = 0;
	//static uniqueFailedId: number = 99900;

	static getUniqueId(id: number = 0) {
		return ++id;
	}

	static getUniqueFailedId(failedId: number = 0) {
		return failedId;
	}

	static getUniqueKey(key: number = 0) {
		return ++key;
	}

	static getTime() {
		return new Date().toLocaleString('en-AU', { hour: 'numeric', minute: 'numeric', hour12: true }).replace(/ /g,'');
	}

	static fetchPageUrl(): string {
		let url: string = '';
		if (window) {
			url = window.location.href;
		}
		return url;
	}
}
