export interface ChatSessionResponse {
	id: string;
	affinityToken: string;
	key: string;
	clientPollTimeout: number;
}
