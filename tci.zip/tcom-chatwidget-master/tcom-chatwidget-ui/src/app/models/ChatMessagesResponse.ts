export interface ChatMessagesResponse {
	messages?: Messages[];
	sequence?: number;
	offset?: number;
}

interface Messages {
	type: string;
	message: Message;
}

interface Message {
	customDetails?: any[];
	connectionTimeout?: number;
	visitorId?: string;
	sensitiveDataRules?: SensitiveDataRules[];
	transcriptSaveEnabled?: boolean;
	url?: string;
	queuePosition?: number;
	geoLocation?: GeoLocation;
	postChatUrl?: string;
	name?: string;
	userId?: string;
	items?: any[];
	sneakPeekEnabled?: boolean;
	chasitorIdleTimeout?: ChasitorIdleTimeout;
	reason?: string;
}

interface ChasitorIdleTimeout {
	isEnabled: boolean;
	warningTime: number;
	timeout: number;
}

interface GeoLocation {
	organization: string;
	region: string;
	countryName: string;
	latitude: number;
	countryCode: string;
	longitude: number;
}

export interface SensitiveDataRules {
	name: string;
	pattern: string;
	id: string;
	replacement: string;
	actionType: string;
}
