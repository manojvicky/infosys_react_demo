import { all, fork, put, select, takeEvery } from 'redux-saga/effects';
import { ChatEntryActionTypes } from '../actions/ChatActionTypes';
import { ChatManagerServicesClient } from '../services/ChatManagerServicesClient';
import { NormalizedChatManagerConfig } from '@cm-types/IChatManagerConfig';
import { onLoadChatEntry } from '../actions/ChatEntryActions';
import { onLoadSessionChat, initServices } from '../actions/ChatSessionActions';
import { ChatEntryState } from '../state/ApplicationState';
import { getIniteState } from '../actions/ChatGlobalActions';

function* handleFetchConfig() {
  try {
    const state = yield select();
    let chatEntryState: ChatEntryState = state.chatEntry;
    let pageConfig: NormalizedChatManagerConfig  = yield ChatManagerServicesClient.loadConfig(chatEntryState.chatManagerLocation);
    yield put(onLoadChatEntry(pageConfig));
    yield put(onLoadSessionChat(pageConfig));
    yield put(initServices());
    yield put(getIniteState());
  } catch (err) {
      yield put(fetchError());
  }
}

export function fetchError() {
	return {
		type: ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG_FAILURE
	};
}

export function fetchSuccess() {
	return {
		type: ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG_SUCCESS
	};
}

function* watchFetchConfig() {
      yield takeEvery([ChatEntryActionTypes.FETCH_CHAT_MANAGER_CONFIG,ChatEntryActionTypes.REFETCH_CHAT_MANAGER_CONFIG, ] , handleFetchConfig);
}

function* configurationsSaga() {
  yield all([fork(watchFetchConfig)])
}

export default configurationsSaga
