import { all, select, fork, put, takeEvery } from 'redux-saga/effects';
import { ConnectionState } from '@cm-types/types';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';
import { APIServicesClient } from '../services/APIServicesClient';
import { ChatSessionState } from '../state/ApplicationState';
import { ChatSessionResponse } from '../models/ChatSessionResponse';
import { establishSession, onChatRequestFailure } from '../actions/ChatSessionActions';

function* handleFetchSessionId() {
  try {
    const state = yield select();
    let chatSessionState: ChatSessionState = state.chatSession;

    const chatSessionResponse: ChatSessionResponse = yield APIServicesClient.getSessionId(
      chatSessionState.serviceEndpointURL,
      chatSessionState.affinityToken,
      chatSessionState.apiVersion
    );

    if(chatSessionResponse) {
      yield put(fetchChatSessionSuccess(chatSessionState, chatSessionResponse));
      yield put(establishSession());
    }else{
      yield put(onChatRequestFailure('failed'));
    }

  } catch (err) {
      yield put(onChatRequestFailure('failed'));
  }
}

export function fetchChatSessionSuccess(chatSessionState: ChatSessionState, chatSessionResponse: any) {
	return {
		type: ChatSessionActionTypes.CHAT_SESSION_SUCCESS,
		payload: {
			connectionStatus: ConnectionState.PENDING,
			sessionId: chatSessionResponse.id,
			sessionKey: chatSessionResponse.key,
			affinityToken: chatSessionResponse.affinityToken
		}
	};
}

function* watchFetchSessionId() {
  yield takeEvery(ChatSessionActionTypes.CHAT_SESSION_REQUEST , handleFetchSessionId);
}

function* preSessionSaga() {
  yield all([fork(watchFetchSessionId)])
}

export default preSessionSaga
