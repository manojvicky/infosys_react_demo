import { all, select, fork, put, takeEvery } from 'redux-saga/effects';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';
import { APIServicesClient } from '../services/APIServicesClient';
import { ChatSessionState } from '../state/ApplicationState';

function* handleChatServicesInit() {
  try {
    const state = yield select();
    let chatSessionState: ChatSessionState = state.chatSession;
    yield APIServicesClient.initializeAPI(chatSessionState.serviceEndpointURL);
    yield put(handleChatServicesInitSuccess());
  } catch (err) {
  }
}

export function handleChatServicesInitSuccess() {
	return {
		type: ChatSessionActionTypes.CHAT_SERVICES_INIT_SUCCESS
	};
}

function* watchChatServicesInit() {
  yield takeEvery(ChatSessionActionTypes.CHAT_SERVICES_INIT , handleChatServicesInit);
}

function* initServicesSaga() {
  yield all([fork(watchChatServicesInit)])
}

export default initServicesSaga
