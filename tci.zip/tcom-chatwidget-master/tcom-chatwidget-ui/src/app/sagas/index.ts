import { all, fork } from 'redux-saga/effects';
import messagesSaga from  './messages';
import configurationsSaga from  './configurations';
import preSessionSaga from  './preSession';
import sessionSaga from  './session';
import chatEndSaga from  './chatEnd';
import messagesMetadataSaga from  './messagesMetadata';
import initServicesSaga from  './initServices';

export function* rootSaga() {
  yield all([
    fork(messagesSaga),
    fork(configurationsSaga),
    fork(preSessionSaga),
    fork(sessionSaga),
    fork(chatEndSaga),
    fork(messagesMetadataSaga),
    fork(initServicesSaga)
  ])
}
