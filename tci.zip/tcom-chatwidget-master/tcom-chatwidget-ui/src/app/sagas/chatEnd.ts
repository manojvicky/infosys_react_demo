import { all, select, fork, put, takeEvery } from 'redux-saga/effects';
import { ChatEndActionTypes } from '../actions/ChatActionTypes';
import { APIServicesClient } from '../services/APIServicesClient';
import { ChatSessionState } from '../state/ApplicationState';
import { incrementSeq } from '../actions/ChatSessionActions';

function* handleChatEnd() {
  const state = yield select();
  let chatSessionState: ChatSessionState = state.chatSession;
  let seq: any = chatSessionState.sequenceNumber;

  try {
    const chatInitResponse = yield APIServicesClient.chasitorEnd(
      chatSessionState.serviceEndpointURL,
      chatSessionState.affinityToken,
      chatSessionState.apiVersion,
      chatSessionState.sessionKey,
      seq.toString()
    );

    if (chatInitResponse) {
      yield put(incrementSeq(++seq));
    }

  } catch (err) {
      yield put(fetchInitError());
  }
}

export function fetchInitError() {
	return {
		type: ChatEndActionTypes.CHAT_END_FAILURE
	};
}

export function fetchChatEndSuccess() {
	return {
		type: ChatEndActionTypes.CHAT_END_SUCCESS
	};
}

function* watchChatEndSession() {
  yield takeEvery(ChatEndActionTypes.CHAT_END_REQUEST , handleChatEnd);
}

function* chatEndSaga() {
  yield all([fork(watchChatEndSession)])
}

export default chatEndSaga
