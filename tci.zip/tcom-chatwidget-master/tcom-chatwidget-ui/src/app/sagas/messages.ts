import { all, select, fork, put, take, cancel } from 'redux-saga/effects';
import { ConnectionState } from '@cm-types/types';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';
import { APIServicesClient } from '../services/APIServicesClient';
import { ChatSessionState } from '../state/ApplicationState';
import { ChatMessagesResponse } from '../models/ChatMessagesResponse';
import { onMessageSuccess, incrementPc, incrementAck, onChatTimeout } from '../actions/ChatSessionActions';

function* handleFetch() {
   while (true) {
    const state = yield select();

    let chatSessionState: ChatSessionState = state.chatSession;
    let ack: any = chatSessionState.ack;
    let pc: any = chatSessionState.pc;
    let chatMessagesResponse: ChatMessagesResponse = {};

  try {
       chatMessagesResponse = yield APIServicesClient.fetchMessages(
        chatSessionState.serviceEndpointURL,
        chatSessionState.affinityToken,
        chatSessionState.apiVersion,
        chatSessionState.sessionKey,
        ack.toString(),
        pc.toString()
      );

      if(chatMessagesResponse) {
        yield put(onMessageSuccess(chatMessagesResponse.messages, chatMessagesResponse.sequence || 0));
      }else{
        throw new Error();
      }
    } catch (err) {
        if(err && err.status == 403){
          yield put(onChatTimeout());
        }
    }

    yield put(incrementPc(++pc));

    if(chatMessagesResponse && chatMessagesResponse.messages){
      yield put(incrementAck(chatMessagesResponse.sequence || 0));
    }

    //yield delay(1000);

  }
}

export function fetchSuccess() {
	return {
		type: ChatSessionActionTypes.CHAT_MESSAGES_SUCCESS,
		payload: {
			connectionStatus: ConnectionState.IN_PROGRESS
		}
	};
}

function* watchFetchRequest() {
  while ( yield take(ChatSessionActionTypes.CHAT_MESSAGES_REQUEST ) ) {
   const bgSyncTask = yield fork(handleFetch);
   yield take(ChatSessionActionTypes.CHAT_STOP_MESSAGES)
   yield cancel(bgSyncTask)
 }
}

function* messagesSaga() {
  yield all([fork(watchFetchRequest)])
}

export default messagesSaga
