import { all, select, fork, put, takeEvery } from 'redux-saga/effects';
import { ChatSessionStatus } from '@cm-types/types';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';
import { APIServicesClient } from '../services/APIServicesClient';
import { ChatSessionState } from '../state/ApplicationState';
import { incrementSeq, onChatRequestFailure } from '../actions/ChatSessionActions';

function* handleFetchInitSession() {
  const state = yield select();
  let chatSessionState: ChatSessionState = state.chatSession;

  let contactUUID = '';
  let customerAccount = '';
  let caseNumber = '';

  try {
    let seq = 1

    const chatInitResponse = yield APIServicesClient.initSession(
      chatSessionState.serviceEndpointURL,
      chatSessionState.affinityToken,
      chatSessionState.apiVersion,
      chatSessionState.sessionKey,
      chatSessionState.sessionId,
      seq.toString(),
      chatSessionState.organizationId,
      chatSessionState.deploymentId,
      chatSessionState.buttonId,
      contactUUID,
      customerAccount,
      caseNumber
    );

    	yield put(incrementSeq(++seq));

    if (chatInitResponse !== ChatSessionStatus.OK) {
      yield put(onChatRequestFailure('failed'));
    }


  } catch (err) {
      yield put(onChatRequestFailure('failed'));
  }
}


export function fetchInitSessionSuccess() {
	return {
		type: ChatSessionActionTypes.CHAT_INIT_SUCCESS
	};
}

function* watchFetchInitSession() {
  yield takeEvery(ChatSessionActionTypes.CHAT_INIT_REQUEST , handleFetchInitSession);
}

function* sessionSaga() {
  yield all([fork(watchFetchInitSession)])
}

export default sessionSaga
