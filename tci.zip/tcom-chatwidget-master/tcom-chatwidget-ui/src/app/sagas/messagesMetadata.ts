import { all, select, fork, put, takeEvery } from 'redux-saga/effects';
import { ChatSessionActionTypes } from '../actions/ChatActionTypes';
import { ChatSessionState } from '../state/ApplicationState';
import { IMessageMetadata, IMessage, MessageStatus } from '@cm-types/types';
import { FAILURE_ID_OFFSET } from '@cm-constants/DefaultConstants';

import * as _ from 'lodash';

function* setMessageMetadata(action) {
  const state = yield select();
  let chatSessionState: ChatSessionState = state.chatSession;
  try {
    let messageMetadata: IMessageMetadata  = chatSessionState.messageMetadata || {};
    let messages: IMessage[] = action.payload.messages;

    let failedArray = _.filter(messages, function(message: IMessage) {
        return message.status == MessageStatus.FAILED;
     });

     let unreadCounter = _.filter(messages, function (message: IMessage) {
        return message.status == MessageStatus.UNREAD;
     });

    if(messages){
      messageMetadata.idCount = messages.length - failedArray.length;
      messageMetadata.keyCount = messages.length;
      messageMetadata.failedIdCount = FAILURE_ID_OFFSET - failedArray.length;
      messageMetadata.total = messages.length;
      messageMetadata.totalFailed = failedArray.length;
      messageMetadata.unreadCount = unreadCounter.length;

      yield put(populateMessageMetadta({...messageMetadata}));
    }

  } catch (err) {
  }
}

export function populateMessageMetadta(iMessageMetadata: IMessageMetadata) {
	return {
		type: ChatSessionActionTypes.CHAT_MESSAGES_METADATA,
		payload: {
			messageMetadata: iMessageMetadata
		}
	};
}

function* watchChatMessageProcess() {
  yield takeEvery([ChatSessionActionTypes.CHAT_MESSAGES_PROCESS,ChatSessionActionTypes.ADD_MESSAGE ] , setMessageMetadata);
}

function* messagesMetadataSaga() {
  yield all([fork(watchChatMessageProcess)])
}

export default messagesMetadataSaga
