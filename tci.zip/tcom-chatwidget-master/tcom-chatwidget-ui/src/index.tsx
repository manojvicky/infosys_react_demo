/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:51:36+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T11:50:16+11:00
 * @Copyright: Telstra 2018
 */
import '@cm-styles/style.scss';

import Main from './app/Main';
import { APP_NAME } from './app/constants/DefaultConstants';
import { ConfigOptions } from '@cm-types/ConfigOptions';

export function init(
  serviceUrl: string,
  chatManagerLocation: string,
  surveyUrl: string,
  assetsDomainPath: string
) {
  console.log(APP_NAME + ' initialization...');
  let configOptions: ConfigOptions = {};
  configOptions.serviceUrl = serviceUrl;
  configOptions.chatManagerLocation = chatManagerLocation;
  configOptions.surveyUrl = surveyUrl;
  configOptions.assetsDomainPath = assetsDomainPath;
  Main.bootstrap(APP_NAME, configOptions);
}
