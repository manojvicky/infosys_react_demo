module.exports = {
  plugins: [
    require('autoprefixer')({
            'browsers': ['> 0.25%', 'last 2 versions','ie >= 11']
        })
  ]
};
