
<div align="center">
  <h1>Live Chat Program : Chat Widget UI</h1>
</div>

<p align="center">
 empowering the salesforce for chat applications for customers
</p>

<p align="center">
  <em>
    JavaScript
    . React
    · TypeScript
    · Specs BDD
    · JSON
  </em>
  <br />
  <em>
    CSS
    · SCSS
    · Less
  </em>
  <br />
  <br />
</p>

<p align="center">
<a href="#">
  <img alt="TypeScript" src="https://img.shields.io/badge/Typescript-3.2.2-green.svg?style=flat-square"></a>

  <a href="https://travis-ci.org/prettier/prettier">
  <img alt="Webpack" src="https://img.shields.io/badge/webpack-4.10.2-green.svg?style=flat-square"></a>

<a href="#">
  <img alt="server" src="https://img.shields.io/badge/server-webpack--dev--server-blue.svg?style=flat-square"></a>

  <a href="#">
    <img alt="test" src="https://img.shields.io/badge/test-jest--mocha-yellow.svg?style=flat-square"></a>

  <a href="#">
    <img alt="tslint" src="https://img.shields.io/badge/tslint-5.11.0-green.svg?style=flat-square"></a>

<a href="#">
  <img alt="Prs welcome" src="https://img.shields.io/badge/styles-SCSS-brightgreen.svg?style=flat-square"></a>

  <a href="#">
    <img alt="code style: prettier" src="https://img.shields.io/badge/code_style-prettier-ff69b4.svg?style=flat-square"></a>

  <a href="#">
    <img alt="build: status" src="http://master2.ci.ae.sda.corp.telstra.com/plugins/servlet/wittified/build-status/TCOMCMUI-TCOMCMUIP"></a>

  <a href="#">
      <img alt="Storybook" src="https://cdn.jsdelivr.net/gh/storybooks/brand@master/badge/badge-storybook.svg"></a>

</p>


Building a client-side code that can be embedded on each digital page in order to load the chat UI component. This chat manager application will be supported by Telstra Agents, and also Virtual Assistants (such as Codi). Telstra C&SB has chosen SalesForce Live Agent as the chat technology platform going forward, to replace aspects of the current Live Person solution.

## Installing / Getting started

Follow the below instructions to quickly get this run.

```shell
git clone https://git02.ae.sda.corp.telstra.com/scm/lcp/tcom-chatwidget.git

cd tcom-chatmanager-client
npm(or yarn) install
npm run build:dev:no-server

cd tcom-chatwidget-services
npm(or yarn) install
npm run build:dev:no-server

cd tcom-chatwidget-ui
npm(or yarn) install
npm run build:dev
```

Open the url 'http://localhost:8082/index.html' to access the application locally.

### Initial Configuration

This application read the initial configuration from src/config/env.json

### Developing

Here's a brief intro about what a developer must do in order to start developing
the project further:

```shell
git clone https://git02.ae.sda.corp.telstra.com/scm/lcp/tcom-chatwidget.git
cd tcom-chatwidget-ui/
npm install
```

### Component Development
We are using the storybook for testing of react ui components. To run storybook, please follow the below commands.

```shell
npm run storybook
```
it will list all the components available.

### Building

There are few options to build this project for the developer, stated here:

```shell
npm run build:dev

#for continue watch
npm run build:watch

#for production
npm run build

```

### Deploying / Publishing

TBB


### Unit Test
Tests framework used are: Jest.

```
npm run test
```

Testing with coverage:

```
npm run cov
```

### Code Prettier and Linting
to run it concurrently with your code additions:

```
npm run format

#auto
npm run fix:prettier
npm run fix:tslint
```

### Code Structure

- `/src` Place your TS code under this folder. Test also following the naming convention `*.test.ts` next to file to be unit tested.
- `/dist` Output folder for transpiled project output.
- `/coverage` Output folder for coverage reports.

### Documentation
to generate the docs, we can use of the below command

```
npm run doc:html
```

### Tools used
- `React` for UI development
- `typescript` strict syntactical superset of JavaScript, and adds optional static typing to the language
- `ts-node` ts module resolution
- `jest` testing framework
- `tslint` typescript linter
- `prettier` code formatter
- `webpack` application build for dev, production
- `scss` any UI customization required

This project seed will be updated to keep the dependences up to date.

### Features

TBD

### Links

- https://github.com/Microsoft/TypeScript
- https://sass-lang.com/
- https://webpack.js.org/
- https://prettier.io/
- https://palantir.github.io/tslint/
- https://istanbul.js.org/
