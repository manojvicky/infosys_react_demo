/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T15:42:25+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:07:04+11:00
 * @Copyright: Telstra 2018
 */

const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const { prod_Path, src_Path } = require('./path');
const { selectedPreprocessor } = require('./loader');
const libraryName = 'TCOMChatWidgetUI';

module.exports = {
	entry: {
		main: './' + src_Path + '/index.tsx'
	},
	output: {
		path: path.resolve(__dirname, prod_Path),
		filename: '[name].[chunkhash].js',
		library: libraryName,
		libraryTarget: 'umd',
		umdNamedDefine: true
	},
	resolve: {
		extensions: ['.tsx', '.ts', '.js', '.css', '.scss'],
		alias: {
			'@cm-controllers': path.resolve('src/app/controllers/chat/'),
			'@cm-services': path.resolve('src/app/services/'),
			'@cm-constants': path.resolve('src/app/constants/'),
			'@cm-types': path.resolve('src/app/types/'),
			'@cm-util': path.resolve('src/app/util/'),
			'@cm-models': path.resolve('src/app/models/'),
			'@cm-validators': path.resolve('src/app/validators/'),
			'@cm-components': path.resolve('src/app/components/'),
			'@cm-app': path.resolve('src/app/'),
			'@cm-libs': path.resolve('src/libs/'),
			'@cm-config': path.resolve('src/config/'),
			'@cm-styles': path.resolve('src/styles/'),
			'@cm-icons': path.resolve('src/assets/icons/'),
			'@cm-root': path.resolve('src/')
		}
	},
	//devtool: 'cheap-module-source-map',
	devtool: 'source-map',
	module: {
		rules: [
			{
				test: /\.(ts|tsx)?$/,
				loader: 'awesome-typescript-loader'
			},
			{
				test: /\.svg$/,
				loader: 'svg-react-loader'
			},
			{
				test: /\.js?$/,
				use: 'source-map-loader',
				enforce: 'pre'
			},
			{
				test: /\.(jpg|png|gif|eot|svg|otf|ttf|woff|woff2)$/,
				loader: 'file-loader',
				include: path.resolve(__dirname, '../'),
				exclude: /\.svg$/
			},
			{
				test: selectedPreprocessor.fileRegexp,
				use: [
					{
						loader: MiniCssExtractPlugin.loader
					},
					{
						loader: 'css-loader',
						options: {
							modules: false,
							sourceMap: true
						}
					},
					{
						loader: 'postcss-loader',
						options: {
							sourceMap: true,
							config: {
								path: path.resolve(__dirname, '../postcss.config.js')
							}
						}
					},
					{
						loader: selectedPreprocessor.loaderName,
						options: {
							sourceMap: true
						}
					}
				]
			}
		]
	},
	// externals: {
	// 	react: 'React',
	// 	'react-dom': 'ReactDOM'
	// },
	plugins: [
		new MiniCssExtractPlugin({
			filename: 'style.css'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index-prod-new.html',
			filename: 'index.html'
			//  template: './' + src_Path + '/index-liveperson.html',
			//  filename: 'index-liveperson.html'
			// template: './' + src_Path + '/index-salesforce.html',
			// filename: 'index-salesforce.html'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index-prod.html',
			filename: 'index2.html'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index-prod.html',
			filename: 'index3.html'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index.html',
			filename: 'index-plain.html'
		}),
		new CopyWebpackPlugin([
			{ from: 'src/assets/icons/*', to: 'icons', flatten: true },
			{ from: 'src/assets/audio/*', to: 'audio', flatten: true },
			{ from: 'src/fonts/*', to: 'fonts', flatten: true }
		]),
		new webpack.DefinePlugin({ DEVLOPMENT_MODE: JSON.stringify(true) })
	]
};
