/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-11-17T01:22:30+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-14T10:49:37+11:00
 * @Copyright: Telstra 2018
 */

const scss = {
	fileRegexp: /\.scss$/,
	loaderName: 'sass-loader'
};

const less = {
	fileRegexp: /\.less$/,
	loaderName: 'less-loader'
};

// Set preprocessor here
const selectedPreprocessor = scss;

module.exports = {
	selectedPreprocessor
};
