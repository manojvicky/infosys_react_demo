import { Component, Prop, h } from '@stencil/core';
//import { format } from '../../utils/utils';

@Component({
  tag: 'chat-message-card',
  styleUrl: 'chat-message-card.scss',
  shadow: true
})
export class ChatMessageCardComponent {
  @Prop() imageUrl: string;
  @Prop() titleMessage: string;
  @Prop() subtitle: string;

     render() {
      return  (
        <div class="card-wrapper">
          <div class="card">
            <img src={this.imageUrl}/>
            <div class="card-inner">
              <h4>
                <b>{this.titleMessage}</b>
              </h4>
              <p>{this.subtitle}</p>
            </div>
          </div>
        </div>
       );
   }
}
