import { Component, Prop, h } from '@stencil/core';
//import { format } from '../../utils/utils';

@Component({
  tag: 'chat-message-card-buttons',
  styleUrl: 'chat-message-card-buttons.scss',
  shadow: true
})
export class ChatMessageCardButtonsComponent {
  @Prop() imageUrl: string;
  @Prop() titleMessage: string;
  @Prop() subtitle: string;

     render() {
      return  (
        <div class="card-wrapper">
          <div class="card">
            <img src={this.imageUrl}/>
            <div class="card-inner">
              <h4>
                <b>{this.titleMessage}</b>
              </h4>
              <p>{this.subtitle}</p>
            </div>
            <div class="card-button-wrapper">
               <div class="card-button">
                  <a class="card-button-link">View offer</a>
               </div>
               <div class="card-button">
                  <a class="card-button-link">Compare offer</a>
               </div>
               <div class="card-button">
                  <a class="card-button-link">Buy online</a>
               </div>
            </div>
          </div>
        </div>
       );
   }
}
