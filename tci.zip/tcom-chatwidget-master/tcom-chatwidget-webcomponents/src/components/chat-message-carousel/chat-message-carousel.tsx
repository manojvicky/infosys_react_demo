import { Component, Prop, h, Element } from '@stencil/core';
//import { format } from '../../utils/utils';

@Component({
  tag: 'chat-message-carousel',
  styleUrl: 'chat-message-carousel.scss',
  shadow: true
})
export class ChatMessageCarouselComponent {
  @Prop() imageUrl: string;
  @Prop() titleMessage: string;
  @Prop() subtitle: string;

   @Element() el: HTMLElement;

     render1() {
      return  (
        <div class="card-wrapper">
          <div class="card">
            <div class="card-inner">
              <h4>
                <b>{this.titleMessage}</b>
              </h4>
              <p>{this.subtitle}</p>
            </div>
            <div class="card-button-wrapper">
               <div class="card-button">
                  <a class="card-button-link">View offer</a>
               </div>
               <div class="card-button">
                  <a class="card-button-link">Compare offer</a>
               </div>
               <div class="card-button">
                  <a class="card-button-link">Buy online</a>
               </div>
            </div>
          </div>
        </div>
       );
   }

   render() {
    return  (
       <div class="wrapper">
          <ul class="carousel" data-target="carousel">
            <li class="card-slide" data-target="card">
            <div class="card-wrapper">
              <div class="card">
                <img src={this.imageUrl}/>
                <div class="card-inner">
                  <h4>
                    <b>{this.titleMessage}</b>
                  </h4>
                  <p></p>
                </div>
                <div class="card-button-wrapper">
                   <div class="card-button">
                      <a class="card-button-link">View offer</a>
                   </div>
                   <div class="card-button">
                      <a class="card-button-link">Compare offer</a>
                   </div>
                   <div class="card-button">
                      <a class="card-button-link">Buy online</a>
                   </div>
                </div>
              </div>
            </div>
            </li>
            <li class="card-slide" data-target="card">
            <div class="card-wrapper">
              <div class="card">
                  <img src='https://www.telstra.com.au/content/dam/tcom/personal/aem-cloud-content-migration-assets/deals/images-a/s10-efoy-f&f-takeover-banner-mobile-magenta-v3.jpg'/>
                <div class="card-inner">
                  <h4>
                    <b>Family & Friends Mobile Plan</b>
                  </h4>
                  <p></p>
                </div>
                <div class="card-button-wrapper">
                   <div class="card-button">
                      <a class="card-button-link">View offer</a>
                   </div>
                   <div class="card-button">
                      <a class="card-button-link">Compare offer</a>
                   </div>
                   <div class="card-button">
                      <a class="card-button-link">Buy online</a>
                   </div>
                </div>
              </div>
            </div>
            </li>
          </ul>
          <div class="button-wrapper">
            <button class="button-left-icon" data-action="slideLeft"></button>
            <button class="button-right-icon" data-action="slideRight"></button>
          </div>
        </div>
        );
    }

    componentDidLoad(){
              // Select the carousel you'll need to manipulate and the buttons you'll add events to
        const carousel: any = this.el.shadowRoot.querySelector("[data-target='carousel']");
        const card = carousel.querySelector("[data-target='card']");
        const leftButton = this.el.shadowRoot.querySelector("[data-action='slideLeft']");
        const rightButton = this.el.shadowRoot.querySelector("[data-action='slideRight']");

        // Prepare to limit the direction in which the carousel can slide,
        // and to control how much the carousel advances by each time.
        // In order to slide the carousel so that only three cards are perfectly visible each time,
        // you need to know the carousel width, and the margin placed on a given card in the carousel
        const carouselWidth = carousel.offsetWidth;
        const cardStyle = card.currentStyle || window.getComputedStyle(card)
        const cardMarginRight = Number(cardStyle.marginRight.match(/\d+/g)[0]);

        // Count the number of total cards you have
        const cardCount = carousel.querySelectorAll("[data-target='card']").length;

        console.log('carouselWidth '+carouselWidth);

        // Define an offset property to dynamically update by clicking the button controls
        // as well as a maxX property so the carousel knows when to stop at the upper limit
        let offset = 0;
        const maxX = -((cardCount * (carouselWidth + cardMarginRight)) - (carouselWidth + cardMarginRight + 50));

        // Add the click events
        leftButton.addEventListener("click", function() {
          if (offset < 0) {
            offset += (carouselWidth + cardMarginRight - 50);
            carousel.style.transform = `translateX(${offset}px)`;
            }
        })

        rightButton.addEventListener("click", function() {
          if (offset > maxX) {
            offset -= (carouselWidth + cardMarginRight - 50);
            carousel.style.transform = `translateX(${offset}px)`;
          }
        })
    }

}
