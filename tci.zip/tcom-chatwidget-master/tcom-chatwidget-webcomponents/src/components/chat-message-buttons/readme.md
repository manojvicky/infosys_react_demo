# my-component



<!-- Auto Generated Below -->


## Properties

| Property       | Attribute       | Description | Type     | Default     |
| -------------- | --------------- | ----------- | -------- | ----------- |
| `imageUrl`     | `image-url`     |             | `string` | `undefined` |
| `subtitle`     | `subtitle`      |             | `string` | `undefined` |
| `titleMessage` | `title-message` |             | `string` | `undefined` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
