/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-11-17T01:22:30+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-17T10:06:47+11:00
 * @Copyright: Telstra 2018
 */



const env = process.env.NODE_ENV

module.exports = env => {
  console.log(` running ${env} Mode using ./webpack/webpack.${env}.js`);
  return require(`./webpack/webpack.${env}.js`);
};
