/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T15:42:25+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:07:04+11:00
 * @Copyright: Telstra 2018
 */

const path = require('path');
const webpack = require('webpack');
const WebpackMd5Hash = require('webpack-md5-hash');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const libraryName = 'TCOMChatAppSwitch';
const CopyWebpackPlugin = require('copy-webpack-plugin');


const { prod_Path, src_Path } = require('./path');

module.exports = {
	entry: {
			main: './' + src_Path + '/index.ts'
	},
	output: {
		path: path.resolve(__dirname, prod_Path),
		filename: '[name].[chunkhash].js',
		library: libraryName,
		libraryTarget: 'umd',
		umdNamedDefine: true
	},
	resolve: {
		extensions: ['.tsx', '.ts', '.js']
	},
	devtool: 'source-map',
	module: {
		rules: [
			{
				test: /\.tsx?$/,
				loader: 'awesome-typescript-loader'
			},
			{
				test: /\.js$/,
				use: 'source-map-loader',
				enforce: 'pre'
			}
		]
	},
	plugins: [
		new CleanWebpackPlugin(path.resolve(__dirname, prod_Path), {
			root: process.cwd()
		}),
		new WebpackMd5Hash(),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index.html',
			filename: 'index.html'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index.html',
			filename: 'index2.html'
		}),
		new HtmlWebpackPlugin({
			inject: false,
			hash: false,
			template: './' + src_Path + '/index.html',
			filename: 'index3.html'
		}),
		new CopyWebpackPlugin([
			{ from: 'src/assets/icons/*', to: 'icons', flatten: true },
			{ from: 'src/assets/audio/*', to: 'audio', flatten: true },
		 	{ from: 'external-scripts/chatwidget/*', to: 'chatwidget', flatten: true },
		 	{ from: 'external-scripts/chatwidget/fonts/*', to: 'chatwidget/fonts', flatten: true }
		]),
		new webpack.DefinePlugin({ DEVLOPMENT_MODE: JSON.stringify(true) })
	]
};
