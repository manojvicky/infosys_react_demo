/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T15:41:07+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:06:48+11:00
 * @Copyright: Telstra 2018
 */

const path = require('path');
const webpack = require('webpack');
const WebpackMd5Hash = require('webpack-md5-hash');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const libraryName = 'TCOMChatAppSwitch';

const { prod_Path, src_Path } = require('./path');

module.exports = {
	entry: {
		main: './' + src_Path + '/index.ts'
	},
	output: {
		path: path.resolve(__dirname, prod_Path),
		filename: 'chatapp-switch.min.js',
		library: libraryName,
		libraryTarget: 'umd',
		umdNamedDefine: true
	},
	resolve: {
		extensions: ['.tsx', '.ts', '.js']
	},
	module: {
		rules: [
			{
				test: /\.tsx?$/,
				loader: 'awesome-typescript-loader'
			},
			{
				test: /\.js$/,
				use: 'source-map-loader',
				enforce: 'pre'
			}
		]
	},
	plugins: [
		new CleanWebpackPlugin(path.resolve(__dirname, prod_Path), {
			root: process.cwd()
		}),
		new WebpackMd5Hash(),
		new webpack.DefinePlugin({ DEVLOPMENT_MODE: JSON.stringify(false) })
	]
};
