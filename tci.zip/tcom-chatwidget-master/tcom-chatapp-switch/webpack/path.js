/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-11-17T01:22:30+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2018-12-13T14:21:15+11:00
 * @Copyright: Telstra 2018
 */

const prod_Path = '../dist';
const src_Path = 'src';

module.exports = {
	prod_Path,
	src_Path
};
