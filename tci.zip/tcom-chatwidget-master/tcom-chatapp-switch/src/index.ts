/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:51:36+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T11:50:16+11:00
 * @Copyright: Telstra 2018
 */

import { ChatAppSwitch } from './app/controllers/chat/ChatAppSwitch';
import configureStore from './app/store/configureStore';
import { fetchInitialState } from './app/actions/ChatSwitchAppActions';
import { ConfigOptions } from './app/types/ConfigOptions';
import { ChatUtil } from './app/util/ChatUtil';

export { ChatAppSwitch };

export function init(
  salesforceChatPageLocation: string,
  livePersonChatPageLocation: string,
  chatManagerLocation: string
) {

  let configOptions: ConfigOptions = {};
  configOptions.salesforceChatPageLocation = salesforceChatPageLocation;
  configOptions.livePersonChatPageLocation = livePersonChatPageLocation;
  configOptions.chatManagerLocation = chatManagerLocation;

  const { store, persistor } = configureStore(configOptions);

  store.dispatch(fetchInitialState());

  console.log('##### chatType '+ store.getState().chatAppState.chatType);
  console.log('##### status '+ store.getState().chatAppState.status);
  console.log('##### persistor '+ persistor);

}

export class TelstraLivePersonFake {
    init = (_initSetting?: any) => {
      ChatUtil.livePersonConfig =  _initSetting;
      ChatUtil.livePersonRecall = true;
    }
}

declare global {
    interface Window { livePerson: any; }
}

window.livePerson = new TelstraLivePersonFake();
