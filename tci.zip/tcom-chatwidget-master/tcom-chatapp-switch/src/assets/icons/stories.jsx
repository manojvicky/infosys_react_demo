import * as React from 'react';
import { storiesOf } from '@storybook/react';
import centered from '@storybook/addon-centered/react';
import { withKnobs, color } from '@storybook/addon-knobs';
import path from 'path';


const req = require.context('./', true, /\.svg$/);
const iconset = req.keys()
	.map((filename) => ({
		component: req(filename),
		name: path.basename(filename, '.svg'),
	}));

const IconDisplay = ({ component: Icon, name, color }) => (
	<div
		style={{
			width: '130px',
			height: '130px',
			margin: '10px',
			display: 'flex',
			flexDirection: 'column',
			alignItems: 'center',
			justifyContent: 'stretch',
			backgroundColor: '#F7F7F7'
		}}
	>
		<div style={{ flex: '1', display: 'flex', alignItems: 'center', color }}>
					<img src={'/icons/'+ name +'.svg'} alt="icon"/>
		</div>
		<div style={{ flex: '0' }}>{name}</div>
	</div>
);

storiesOf('Components|Icons', module)
	.addDecorator(centered)
	.addDecorator(withKnobs)
	.add('all', () => (
		<div style={{ width: '100%', display: 'flex', flexWrap: 'wrap' }}>
			{iconset.map((props) => <IconDisplay color={color('color', '#E0364D')} {...props} />)}
		</div>
	))
;

iconset.forEach(({ component: Icon, name }) =>
	storiesOf('Components|Icons', module)
		.addDecorator(centered)
		.addDecorator(withKnobs)
		.add(name, () => (
			<div style={{ color: color('color', '#E0364D'), backgroundColor: color('color', '#c31b96'), padding: '50px'  }}>
				<img src={'/icons/'+ name +'.svg'} alt="icon"/>
			</div>
		))
);
