import { ChatManagerClient } from 'tcom-chatmanager-client';
import { ChatUtil } from '../util/ChatUtil';

export class ChatManagerServicesClient {š
	static loadConfig = (chatManagerConfigUrl: string) => {

		//const chatManagerConfigUrl = '/content/dam/tcom/virtualassistant/custom-ui/chatmanager.en.json';
		//const chatManagerConfigUrl = '/server/mocks/chatmanager.en.json';

		const	cm: ChatManagerClient = new ChatManagerClient(chatManagerConfigUrl);

		return cm.loadPageConfigurations(
			ChatUtil.fetchPageUrl()
		);
	}
}
