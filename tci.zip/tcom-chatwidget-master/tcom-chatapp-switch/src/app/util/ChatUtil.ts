/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-11T08:57:19+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-11T08:58:55+11:00
 * @Copyright: Telstra 2018
 */

declare var window: Window;

interface Window {
	readonly location: any;
}

export class ChatUtil {
	static fetchPageUrl(): string {
		let url: string = '';
		if (window) {
			url = window.location.href;
		}
		return url;
	}

	static parseURL(url: string) {
		var parser = document.createElement('a'),
			searchObject = {},
			queries,
			split,
			i;
		// Let the browser do the work
		parser.href = url;
		// Convert query string to object
		queries = parser.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i++) {
			split = queries[i].split('=');
			searchObject[split[0]] = split[1];
		}
		return {
			protocol: parser.protocol,
			host: parser.host,
			hostname: parser.hostname,
			port: parser.port,
			pathname: parser.pathname,
			search: parser.search,
			searchObject: searchObject,
			hash: parser.hash
		};
	}

static addElementToDOM = (id: string) => {
	let msgContainer = document.createElement('div');
	msgContainer.id = id;
	document.body.appendChild(msgContainer);
}

 // static loadScriptfile = (filename: string, filetype: string) => {
	// 	 let fileref: any;
	//     if (filetype=="js"){
	//         fileref=document.createElement('script')
	//         fileref.setAttribute("type","text/javascript")
	//         fileref.setAttribute("src", filename)
	//     }
	//     else if (filetype=="css"){
	//         fileref=document.createElement("link")
	//         fileref.setAttribute("rel", "stylesheet")
	//         fileref.setAttribute("type", "text/css")
	//         fileref.setAttribute("href", filename)
	//     }
	//     if (typeof fileref!="undefined")
	//         document.getElementsByTagName("head")[0].appendChild(fileref)
	// }

	static loadScriptfile = (src, callback?: any) => {
			let script: any = document.createElement('script'),loaded;
			script.setAttribute("type","text/javascript");
			script.setAttribute('src', src);
			if (callback) {
				script.onreadystatechange = script.onload = function() {
					if (!loaded) {
						callback();
					}
					loaded = true;
				};
			}
			document.getElementsByTagName('head')[0].appendChild(script);
	}

	static loadCss = (src, callback?: any) => {
		let link: any = document.createElement('link'),loaded;
		link.setAttribute("type","text/css");
		link.setAttribute("rel", "stylesheet")
		link.setAttribute('href', src);
		if (callback) {
			link.onreadystatechange = link.onload = function() {
				if (!loaded) {
					callback();
				}
				loaded = true;
			};
		}
		document.getElementsByTagName('head')[0].appendChild(link);
	}

	static chatAppLoaded = false;

	static livePersonRecall = false;

	static livePersonConfig: any;

}
