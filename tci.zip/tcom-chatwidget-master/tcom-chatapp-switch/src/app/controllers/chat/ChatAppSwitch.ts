/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-11T16:53:06+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:45:34+11:00
 * @Copyright: Telstra 2018
 */

import { NormalizedChatManagerConfig, Configuration } from '../../../app/types/IChatManagerConfig';
import { ChatManagerServicesClient } from '../../../app/services/ChatManagerServicesClient';
import { ChatUtil } from '../../util/ChatUtil';
//import { Dispatch } from 'redux';
import { loadChatApp, listenLPChatState, listnerSFChatState } from '../../actions/ChatSwitchAppActions';
import { ChatType, ChatState } from '../../types/types';
import { storeRef } from '../../store/configureStore';

declare global {
    interface Window { livePerson: any; }
}

window.livePerson = window.livePerson || {};

export class ChatAppSwitch {

  public async processRequest(
    salesforceChatPageLocation: string,
    livePersonChatPageLocation: string,
    chatManagerLocation: string,
    chatType: string,
    chatStatus: string
  ) {
    let normalizedChatManagerConfig: NormalizedChatManagerConfig = await ChatManagerServicesClient.loadConfig(chatManagerLocation);
    let pageConfig: Configuration = normalizedChatManagerConfig.configuration;

    if(chatType == ChatType.SALESFORCE && chatStatus == ChatState.INPROGRESS){
      this.loadSalesforceChat(salesforceChatPageLocation);

      ChatUtil.chatAppLoaded = true;
      storeRef.dispatch(loadChatApp(ChatType.SALESFORCE));
      storeRef.dispatch(listnerSFChatState());
    }else if(chatType == ChatType.LIVEPERSON &&  chatStatus == ChatState.INPROGRESS){
      this.loadLivePersonChat(livePersonChatPageLocation);

      ChatUtil.chatAppLoaded = true;
      storeRef.dispatch(loadChatApp(ChatType.LIVEPERSON));
      storeRef.dispatch(listenLPChatState());
    }else{
      if (pageConfig.chatButton && pageConfig.chatProvider === ChatType.SALESFORCE) {
          this.loadSalesforceChat(salesforceChatPageLocation);

          ChatUtil.chatAppLoaded = true;
          storeRef.dispatch(loadChatApp(ChatType.SALESFORCE));
          storeRef.dispatch(listnerSFChatState());
  		 } else if (pageConfig.chatProvider === ChatType.LIVEPERSON){
          this.loadLivePersonChat(livePersonChatPageLocation);

          ChatUtil.chatAppLoaded = true;
          storeRef.dispatch(loadChatApp(ChatType.LIVEPERSON));
          storeRef.dispatch(listenLPChatState());
      }
   }
  }

 loadSalesforceChat = (salesforceChatPageLocation: string) => {
    ChatUtil.addElementToDOM('chat-root');
    ChatUtil.loadScriptfile(salesforceChatPageLocation);
    //ChatUtil.loadScriptfile('../external-scripts/chatwidget/chatwidget.min.js', "js");
    //ChatUtil.loadScriptfile('../external-scripts/chatwidget/chatwidget.min.css', "css");
  }

 loadLivePersonChat = (livePersonChatPageLocation: string) => {
    ChatUtil.loadScriptfile(livePersonChatPageLocation, () => {
      if(ChatUtil.livePersonRecall){
        let config: any = ChatUtil.livePersonConfig;
        window.livePerson.init(config);
        ChatUtil.livePersonRecall = false;
      }
    });
  }
}
