export const enum ChatSwitchAppActionTypes {
	CHAT_TYPE = '@@chatSwitchApp/CHAT_TYPE',
	CHAT_LOADED = '@@chatSwitchApp/CHAT_LOADED',
	CHAT_STATUS_UPDATED = '@@chatSwitchApp/CHAT_STATUS_UPDATED'
}

export const enum ChatGlobalActionTypes {
	CHAT_GET_INIT_STATE = '@@chatSwitchApp/CHAT_SWITCH_GET_INIT_STATE',
	CHAT_SEND_INIT_STATE = '@@chatSwitchApp/CHAT_SWITCH_SEND_INIT_STATE',
	CHAT_RECEIVE_INIT_STATE = '@@chatSwitchApp/CHAT_SWITCH_RECEIVE_INIT_STATE',
	CHAT_DEFAULT_INIT_STATE = '@@chatSwitchApp/CHAT_DEFAULT_INIT_STATE',
	REHYDRATE = 'persist/REHYDRATE'
}
