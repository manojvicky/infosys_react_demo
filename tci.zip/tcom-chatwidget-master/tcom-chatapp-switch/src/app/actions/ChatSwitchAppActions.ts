import { ChatSwitchAppActionTypes } from './ChatActionTypes';
import { ChatType, ChatState, LivePersonChatState  } from '../types/types';
import { getIniteState, defaultInitialState } from './ChatGlobalActions';

declare global {
    interface lpEvents { events: any;}
    interface Window { lpTag: lpEvents; sfTag: any }
}

export const initialChat = () => ({
	type: ChatSwitchAppActionTypes.CHAT_TYPE,
	payload: {
		chatType: ChatType.NONE
	}
});

export const loadChatApp = (chatType: ChatType) => ({
	type: ChatSwitchAppActionTypes.CHAT_LOADED,
	payload: {
		chatType: chatType
	}
});

export const updateStatusChat = (chatStatus: ChatState) => ({
	type: ChatSwitchAppActionTypes.CHAT_STATUS_UPDATED,
	payload: {
		status: chatStatus
	}
});

export function fetchInitialState(): any {
	return async function (dispatch: any, getState: any) {
		await dispatch(getIniteState());
		await new Promise(resolve => setTimeout(resolve, 2000));
		await dispatch(defaultInitialState());
	}
}

export function listenLPChatState(): any {
return async function (dispatch: any, getState: any) {
  	await new Promise(resolve => setTimeout(resolve, 2000));
	  window.lpTag.events.bind("lpUnifiedWindow","state",function(data) {
			if( data.state == LivePersonChatState.INIT ||
				data.state == LivePersonChatState.INITIALISED ||
				data.state == LivePersonChatState.WAITING ||
				data.state == LivePersonChatState.RESUMING ||
				data.state == LivePersonChatState.RESUMEPAUSEDCHAT ||
				data.state == LivePersonChatState.PAUSECHAT ||
				data.state == LivePersonChatState.CHATTING
			){
				dispatch(updateStatusChat(ChatState.INPROGRESS));
			}else if( data.state == LivePersonChatState.NOTFOUND ||
					data.state == LivePersonChatState.UNINITIALISED ||
					data.state == LivePersonChatState.ENDED
				){
					dispatch(updateStatusChat(ChatState.INACTIVE));
				}

		});
  }
}

export function listnerSFChatState(): any {
	return function (dispatch: any, getState: any) {
      window.sfTag = document.getElementById('chat-root');
      window.sfTag.addEventListener("@@event/salesforce/store",function(data: any) {
        console.log('Salesforce chatstate '+ JSON.stringify(data.detail));
        if( data.detail.chatState === 'MINIMIZE' || data.detail.chatState === 'MAXIMIZE'){
          dispatch(updateStatusChat(ChatState.INPROGRESS));
        }else if(data.detail.chatState === 'CHAT_RESET'){
          //ChatUtil.chatAppLoaded = false;
          //dispatch(defaultInitialState());
        }else{
          dispatch(updateStatusChat(data.detail.chatState));
        }
      });
    }
	}
