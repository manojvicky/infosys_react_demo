import { ChatGlobalActionTypes } from './ChatActionTypes';

export const getIniteState = () => ({
	type: ChatGlobalActionTypes.CHAT_GET_INIT_STATE
});

export const sendIniteState = () => ({
	type: ChatGlobalActionTypes.CHAT_SEND_INIT_STATE
});

export const receiveIniteState = (state: any) => ({
	type: ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE,
	payload: state.chatAppState
});

export const defaultInitialState = () => ({
	type: ChatGlobalActionTypes.CHAT_DEFAULT_INIT_STATE
});
