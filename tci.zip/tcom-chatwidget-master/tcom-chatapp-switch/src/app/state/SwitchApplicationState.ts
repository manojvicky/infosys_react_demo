import { ChatType, ChatState } from '../types/types';

export interface ChatAppState {
	chatType?: ChatType;
	status?: ChatState;
	salesforceChatPageLocation?: string;
	livePersonChatPageLocation?: string;
	chatManagerLocation?: string;
}


export interface SwitchApplicationState {
	chatAppState: ChatAppState;
}
