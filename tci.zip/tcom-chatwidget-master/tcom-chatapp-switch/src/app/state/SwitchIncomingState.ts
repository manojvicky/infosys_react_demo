import { switchInitialState } from '../state/SwitchInitialState';
import { ConfigOptions } from '../types/ConfigOptions';


export default (configOptions: ConfigOptions) => {

  let mergedInitialState = switchInitialState;
  mergedInitialState.chatAppState.salesforceChatPageLocation = configOptions.salesforceChatPageLocation;
  mergedInitialState.chatAppState.livePersonChatPageLocation  = configOptions.livePersonChatPageLocation;
  mergedInitialState.chatAppState.chatManagerLocation  = configOptions.chatManagerLocation;

  return mergedInitialState;
}
