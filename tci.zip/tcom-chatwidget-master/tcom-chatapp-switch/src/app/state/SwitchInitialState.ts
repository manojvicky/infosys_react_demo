import { SwitchApplicationState, ChatAppState } from '../state/SwitchApplicationState';
import { ChatType, ChatState } from '../types/types';

export const chatAppState: ChatAppState = {
	chatType: ChatType.NONE,
	status: ChatState.NOT_INITIALIZED,
	salesforceChatPageLocation: '',
	livePersonChatPageLocation: '',
	chatManagerLocation: ''
}

export const switchInitialState: SwitchApplicationState = {
	chatAppState: chatAppState
};
