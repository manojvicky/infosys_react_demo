import { all, fork, takeEvery, select } from 'redux-saga/effects';
import { ChatGlobalActionTypes } from '../actions/ChatActionTypes';
import { ChatAppState } from '../state/SwitchApplicationState';
import { ChatAppSwitch } from '../controllers/chat/ChatAppSwitch';
import { ChatUtil } from '../util/ChatUtil';

function* handleChatServicesInit() {
  try {
    const state = yield select();
    let chatAppState: ChatAppState = state.chatAppState;
    let salesforceChatPageLocation: any = chatAppState.salesforceChatPageLocation;
    let livePersonChatPageLocation: any = chatAppState.livePersonChatPageLocation;
    let chatManagerLocation: any = chatAppState.chatManagerLocation;
    let chatType: any = chatAppState.chatType;
    let chatStatus: any = chatAppState.status;

    if(!ChatUtil.chatAppLoaded){
      let chatApp: ChatAppSwitch = new ChatAppSwitch();

      ChatUtil.loadScriptfile(chatManagerLocation, function(){
        chatApp.processRequest(salesforceChatPageLocation, livePersonChatPageLocation, chatManagerLocation, chatType, chatStatus);
        console.log('handle chat services init');
      });
    }
  } catch (err) {
  }
}


function* watchChatServicesInit() {
  yield takeEvery([ ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE, ChatGlobalActionTypes.CHAT_DEFAULT_INIT_STATE ], handleChatServicesInit);
}

function* initServicesSaga() {
  yield all([fork(watchChatServicesInit)])
}

export default initServicesSaga
