import { all, fork } from 'redux-saga/effects';
import initServicesSaga from  './initServices';

export function* rootSaga() {
  yield all([
    fork(initServicesSaga)
  ])
}
