import { Reducer } from 'redux';
import { ChatAppState } from '../state/SwitchApplicationState';
import { ChatSwitchAppActionTypes } from '../actions/ChatActionTypes';

const reducer: Reducer<ChatAppState> = (state = {}, action) => {
	switch (action.type) {
		case ChatSwitchAppActionTypes.CHAT_TYPE: {
			return {
				...state,
				chatType: action.payload.chatType
			};
		}
		case ChatSwitchAppActionTypes.CHAT_STATUS_UPDATED: {
			return {
				...state,
				status: action.payload.status
			};
		}
		case ChatSwitchAppActionTypes.CHAT_LOADED: {
			return {
				...state,
				chatType: action.payload.chatType,
				chatAppLoaded:  action.payload.chatAppLoaded
			};
		}
		default: {
			return state;
		}
	}
};

export { reducer as chatSwitchAppReducer };
