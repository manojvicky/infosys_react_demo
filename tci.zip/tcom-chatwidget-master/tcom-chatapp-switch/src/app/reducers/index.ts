import { chatSwitchAppReducer } from './ChatSwitchAppReducer';
import { combineReducers } from 'redux';
import { Reducer } from 'redux';
import { SwitchApplicationState } from '../state/SwitchApplicationState';
import { ChatGlobalActionTypes } from '../actions/ChatActionTypes';

export const appReducer = combineReducers<SwitchApplicationState>({
	chatAppState: chatSwitchAppReducer
});

export const rootReducer: Reducer<SwitchApplicationState> = (state, action) => {
	if (action.type === ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE) {
		console.log('rootReducer');
			 let chatAppState = {
				chatType: action.payload.chatType,
				status: action.payload.status,
				salesforceChatPageLocation: action.payload.salesforceChatPageLocation,
				livePersonChatPageLocation:  action.payload.livePersonChatPageLocation,
				chatManagerLocation: action.payload.chatManagerLocation
			};

			state = {
				chatAppState: chatAppState
			}
	  }
  return appReducer(state, action)
}
