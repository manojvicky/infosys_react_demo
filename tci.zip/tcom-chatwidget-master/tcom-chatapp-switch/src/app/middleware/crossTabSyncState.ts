import BroadcastChannel from 'broadcast-channel';
import { ChatGlobalActionTypes } from '../actions/ChatActionTypes';
import { getIniteState, sendIniteState, receiveIniteState } from '../actions/ChatGlobalActions';

function guid() {
  return (
    `${createId()}${createId()}-${createId()}-${createId()}-${createId()}-${createId()}${createId()}${createId()}`
  );
}

function createId() {
  return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
}

const WINDOW_STATE_SYNC_ID = guid();

let isMessageListenerCreated = false;

let lastUuid = 0;

export function generateUuidForAction(action: any) {
  const stampedAction = action;
  stampedAction.$uuid = guid();
  stampedAction.$wuid = WINDOW_STATE_SYNC_ID;
  return stampedAction;
}

export function isActionAllowed({ predicate, blacklist, whitelist }) {
  let allowed = (type: any) => true;

  if (predicate && typeof predicate === 'function') {
    allowed = predicate;
  } else if (Array.isArray(blacklist)) {
    allowed = (type: any) => blacklist.indexOf(type) < 0;
  } else if (Array.isArray(whitelist)) {
    allowed = (type: any) => whitelist.indexOf(type) >= 0;
  }
  return allowed;
}

export function createMessageListener({ channel, dispatch, allowed }) {
  let isSynced = false;
  const tabs = {};
  const messageChannel = channel;
  messageChannel.onmessage = (stampedAction: any) => {
    // ignore if this action is triggered by this window
    // IE bug https://stackoverflow.com/questions/18265556/why-does-internet-explorer-fire-the-window-storage-event-on-the-window-that-st
    if (stampedAction.$wuid === WINDOW_STATE_SYNC_ID || stampedAction.type === ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE) {
      return;
    }
    // ignore other values that saved to localstorage.
    if (stampedAction.$uuid && stampedAction.$uuid !== lastUuid) {
      if (stampedAction.type === ChatGlobalActionTypes.CHAT_GET_INIT_STATE && !tabs[stampedAction.$wuid]) {
        tabs[stampedAction.$wuid] = true;
        dispatch(sendIniteState());
      } else if (stampedAction.type === ChatGlobalActionTypes.CHAT_SEND_INIT_STATE && !tabs[stampedAction.$wuid]) {
        if (!isSynced) {
          isSynced = true;
          dispatch(receiveIniteState(stampedAction.payload));
        }
        return;
      } else if (allowed(stampedAction.type)) {
        lastUuid = stampedAction.$uuid;
        dispatch(stampedAction);
      }
    }
  };
}

export const createStateSyncMiddleware = (config: any) => {
  const allowed = isActionAllowed(config);
  const channel = new BroadcastChannel(config.channel, config.broadcastChannelOption);

  return ({ getState, dispatch }) => next => (action: any) => {
    if (!isMessageListenerCreated) {
      isMessageListenerCreated = true;
      createMessageListener({ channel, dispatch, allowed });
    }

    if (action && !action.$uuid) {
      const stampedAction = generateUuidForAction(action);
      lastUuid = stampedAction.$uuid;
      try {
        if (action.type === ChatGlobalActionTypes.CHAT_SEND_INIT_STATE) {
          if (getState()) {
            stampedAction.payload = getState();
            channel.postMessage(stampedAction);
          }
          return next(action);
        }
        if (allowed(stampedAction.type) || action.type === ChatGlobalActionTypes.CHAT_GET_INIT_STATE) {
          channel.postMessage(stampedAction);
        }
      } catch (e) {
        console.error("Your browser doesn't support cross tab communication");
      }
    }
    return next(action);
  };
};

export const withReduxStateSync = appReducer =>
  ((state, action) => {
    let initState = state;
    if (action.type === ChatGlobalActionTypes.CHAT_RECEIVE_INIT_STATE) {
      initState = action.payload;
    }
    return appReducer(initState, action);
  });

export const initStateWithPrevTab = ({ dispatch }) => {
  dispatch(getIniteState());
};
