export interface ConfigOptions{
  salesforceChatPageLocation?: string;
  livePersonChatPageLocation?: string;
  chatManagerLocation?: string
}
