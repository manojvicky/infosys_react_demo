/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-03T18:21:18+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T18:21:52+11:00
 * @Copyright: Telstra 2018
 */

 export interface NormalizedChatManagerConfig{
 	 configuration: Configuration;
 }

 export interface IChatManagerConfig{
 	global: Global;
 	system: System;
 }

 interface Global {
   configuration: Configuration;
   groups: Group[];
 }

 interface Group {
   groupIdentifier: GroupIdentifier;
 }

 interface GroupIdentifier {
   configuration: Configuration;
   pages: Page[];
 }

 interface Page {
   pageIdentifier: PageIdentifier;
 }

 interface PageIdentifier {
   pageUrl: string;
   configuration: Configuration;
 }

 export interface Configuration {
  chatButton?: boolean;
  chatSlideoutEnabled?: boolean;
  chatProvider?: string;
 	buttonId?: string;
 	organizationId?: string;
 	deploymentId?: string;
   chatButtonConfig?: ChatButtonConfig;
   staticParams?: any[];
   chatSlideout?: ChatSlideout;
   chatLoading?: ChatLoading;
   chatInQueue?: ChatInQueue;
   chatAgentsOffline?: ChatAgentsOffline;
   chatLoadingConnectionError?: chatLoadingConnectionError;
   headerMessage?: HeaderMessage;
 	chatConfirmation?: ChatConfirmation;
 	systemAnnouncement?: SystemAnnouncement;
 }

 interface ChatConfirmation {
   title: string;
   endButtonLabel: string;
   cancelButtonLabel: string;
 }

 interface HeaderMessage {
   chatEnded: string;
   chatInProgress: string;
   chatInProgressUnreadMessages: string;
   noAgentAvailable: string;
 }

 interface ChatAgentsOffline {
   icon: string;
   title: string;
   text: string;
   header: string;
 }

 interface chatLoadingConnectionError {
   icon: string;
   title: string;
   text: string;
   header: string;
 }

 interface ChatLoading {
   icon: string;
   title: string;
   text: string;
 	header: string;
 }

 interface ChatInQueue {
  icon: string;
  title: string;
  text: string;
  subtext: string;
  header: string;
}

 interface ChatSlideout {
   rules: Rules;
   title: string;
   image: string;
   text: string;
   linkUrl: string;
   linkText: string;
 }

 interface Rules {
   type: string;
   duration: number;
   scroll: number;
 }

 interface ChatButtonConfig {
   backgroundColor: string;
   font: string;
   image: string;
   text: string;
 }

 interface SystemAnnouncement {
   message: string;
   linkUrl: string;
   linkText: string;
   enabled: boolean;
 	openLinkInNewTab: boolean;
 }

 /*
 	Not into parent child relation
 */

 interface System {
   configuration: SystemConfiguration;
 }

 interface SystemConfiguration {
   systemAnnouncement: SystemAnnouncement;
   buttonIds: ButtonIds[];
 }

 interface ButtonIds {
   buttonId: ButtonId;
 }

 interface ButtonId {
   announcement: SystemAnnouncement;
 }
