/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-15T14:04:04+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T16:51:55+11:00
 * @Copyright: Telstra 2018
 */

declare module '*.json' {
	const value: any;
	export default value;
}
