/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:27:40+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T18:21:45+11:00
 * @Copyright: Telstra 2018
 */

export enum Language {
	ENGLISH = 'en'
}

export enum ChatType {
	LIVEPERSON = 'liveperson',
	SALESFORCE = 'salesforce',
	NONE = 'none'
}

export enum ChatState {
	NOT_INITIALIZED = 'NOT_INITIALIZED',
	ACTIVE = 'ACTIVE',
	INACTIVE = 'INACTIVE',
	INPROGRESS = 'INPROGRESS'
}

export enum LivePersonChatState {
	CHATTING = 'chatting',
	ENDED = 'ended',
	INIT = 'init',
	INITIALISED = 'initialised',
	NOTFOUND = 'notfound',
	PAUSECHAT = 'paused',
	RESUMEPAUSEDCHAT = 'resumepaused',
	RESUMING = 'resume',
	UNINITIALISED = 'uninitialised',
	WAITING = 'waiting'
}
