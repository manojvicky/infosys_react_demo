import { createStore, compose, applyMiddleware } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';
import storageSession from 'redux-persist/lib/storage/session';
import { rootReducer } from '../reducers';
import createSagaMiddleware from 'redux-saga';
import thunk from 'redux-thunk';
import { rootSaga } from '../sagas';
import { createStateSyncMiddleware } from '../middleware/crossTabSyncState';
import mergedState from '../state/SwitchIncomingState';
import { ChatGlobalActionTypes, ChatSwitchAppActionTypes } from '../actions/ChatActionTypes';
import { ConfigOptions } from '../types/ConfigOptions';

export default (configOptions: ConfigOptions) => {
	const persistConfig = {
		key: 'telstra-chatapp-switch',
		storage: storageSession
	};

	 	const config = {
		 	channel: 'telstra-chatapp-switch-broadcast-channel',
			initiateWithState: true,
		  blacklist: [
				ChatGlobalActionTypes.REHYDRATE,
				ChatSwitchAppActionTypes.CHAT_TYPE,
				ChatSwitchAppActionTypes.CHAT_LOADED,
				ChatSwitchAppActionTypes.CHAT_STATUS_UPDATED,
				ChatGlobalActionTypes.CHAT_DEFAULT_INIT_STATE
			],
			whitelist: [],
		 	broadcastChannelOption: null,
			predicate: null
	 };

	 const syncMiddleware = createStateSyncMiddleware(config);

	 const sagaMiddleware = createSagaMiddleware();

	 const middleware = [ thunk, sagaMiddleware, syncMiddleware ];

	//const composeEnhancers = compose;

	const composeEnhancers =
		typeof window === 'object' && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
			? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({})
			: compose;

	const enhancer = composeEnhancers(applyMiddleware(...middleware));

	const persistedReducer = persistReducer(persistConfig, rootReducer);

	let mergedInitialIncomingState = mergedState(configOptions);

	let store = createStore(persistedReducer, mergedInitialIncomingState, enhancer);

	let persistor = persistStore(store);

	sagaMiddleware.run(rootSaga);

	storeRef = store;

	return { store, persistor };
};

export let storeRef: any;
