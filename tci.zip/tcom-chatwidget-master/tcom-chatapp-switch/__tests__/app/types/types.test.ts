/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:27:40+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-04T10:43:10+11:00
 * @Copyright: Telstra 2018
 */

import { Language } from '../../../src/app/types/types';
import 'jest';

// NOTE: Units tests are not required for types.
describe('TypesSpec', function() {
	test('should import the types', function() {
		expect(Language.ENGLISH).toEqual('en');
	});
});
