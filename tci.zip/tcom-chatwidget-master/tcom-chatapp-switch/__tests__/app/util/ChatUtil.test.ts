/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-11T15:41:30+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-11T15:43:08+11:00
 * @Copyright: Telstra 2018
 */

import { ChatUtil } from '../../../src/app/util/ChatUtil';
import 'jest';

//let mockChatInitialize = jest.fn();

describe('ChatUtilSpec', function() {
	test('should fetch the current page url', function() {
		window.location.href = '/';
		expect(ChatUtil.fetchPageUrl()).toEqual('/');
	});
});
