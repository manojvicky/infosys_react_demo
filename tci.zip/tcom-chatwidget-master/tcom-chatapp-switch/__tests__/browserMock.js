Object.defineProperty(document, 'currentScript', {
	value: document.createElement('script')
});
