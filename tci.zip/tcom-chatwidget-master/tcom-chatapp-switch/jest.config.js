module.exports = {
  // preset: 'ts-jest',
  testEnvironment: 'jsdom',
  transform: {
    "^.+\\.tsx?$": "ts-jest"
  },
  testRegex: "(/__tests__/.*|(\\.|/)(test|spec))\\.ts?$",
  testPathIgnorePatterns: ["/node_modules/"],
  moduleFileExtensions: ["ts", "tsx", "js", "jsx", "json"],
  collectCoverage: true,
  moduleNameMapper: {
      "\\.(css|less|scss|sass)$": "identity-obj-proxy",
      "\\.(json)$": "identity-obj-proxy",
      "@cm-controllers/(.*)$": "<rootDir>/src/app/controllers/chat/$1",
      "@cm-services/(.*)$": "<rootDir>/src/app/services/$1",
      "@cm-util/(.*)$": "<rootDir>/src/app/util/$1",
      "@cm-constants/(.*)$": "<rootDir>/src/app/constants/$1",
      "@cm-types/(.*)$": "<rootDir>/src/app/types/$1",
      "@cm-app/(.*)$": "<rootDir>/src/app/$1",
      "@cm-root/(.*)$": "<rootDir>/src/$1"
    },
  collectCoverageFrom: [
    "src/**/*.ts"
  ],
  modulePaths: [ "<rootDir>" ],
  setupFiles: ["<rootDir>/__tests__/browserMock.js"],
  coverageReporters: [
    "json",
    "text",
    "lcov",
    "clover"
  ],
  globals: {
    "window": true,
    "DEVLOPMENT_MODE": true
  },
  testResultsProcessor: "jest-bamboo-reporter",
  automock: false
};
