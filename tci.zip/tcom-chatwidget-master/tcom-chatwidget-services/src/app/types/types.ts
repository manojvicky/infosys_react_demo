/**
 * @Author: kirankumar.parepalli
 * @Date:   2018-12-13T15:27:40+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-03T18:21:45+11:00
 * @Copyright: Telstra 2018
 */

export enum Features {
	LIVE_AGENT = 'LiveAgent'
}

export enum Language {
	ENGLISH = 'en'
}

export enum CommunicationModelType {
	IFRAME = 'IFRAME',
	DIRECT = 'DIRECT'
}

export enum ResponseType {
	SUCCESS = 'success',
	ERROR = 'error'
}

export enum APIEndpoints {
	sessionId = '/chat/rest/System/SessionId',
	init = '/chat/rest/Chasitor/ChasitorInit',
	messages = '/chat/rest/System/Messages',
	postMessage = '/chat/rest/Chasitor/ChatMessage',
	chasitorTyping = '/chat/rest/Chasitor/ChasitorTyping',
	chasitorNotTyping = '/chat/rest/Chasitor/ChasitorNotTyping',
	endChat = '/chat/rest/Chasitor/ChatEnd',
	agentAvailability = '/chat/rest/Visitor/Availability'
}
