import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';

export interface IRequestHeader {
  'Content-Type': string;
}


export class GenerateTokenAPI extends BaseAPI {
  constructor(
    readonly host: string,
    readonly grantType: string,
    readonly clientId: string,
    readonly clientSecret: string,
    readonly username: string,
    readonly password: string
  ) {
    super();
  }

  private endpoint = '/services/oauth2/token?';

  protected getUrl(): string {
    let finalUrl = this.host + this.endpoint + `grant_type=${this.grantType}&` + `client_id=${this.clientId}&`+ `client_secret=${this.clientSecret}&` + `username=${this.username}&` + `password=${this.password}`;
    return finalUrl
  }

  protected getOptions(): any {
    let headerValues: IRequestHeader = {
      'Content-Type': 'application/json'
    };


    let optionsObj: IRequestOptions = {
      method: 'POST',
      headers: headerValues,
    };

    return optionsObj;
  }

  protected validate(): boolean {
    return true;
  }

  protected handleSuccess(obj: any) {
    console.log(obj);
  }

  protected handleFailure(obj: any) {
    console.log(obj);
  }

  public async execute() {
    let validation = this.validate();
    if (validation) {
      let response = await fetch(this.getUrl(), this.getOptions());
      console.log(response)
      return await response.json();
    }
    return;
  }
}
