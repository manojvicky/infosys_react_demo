import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';
import * as queryString from 'query-string';
import { APIEndpoints } from '../../types/types';


export interface IRequestHeader {
	'Content-Type': string;
	'X-LIVEAGENT-API-VERSION': number;
}

export interface AgentAvailabilityAPIResponse {
	key: string;
	id: string;
	clientPollTimeout: number;
	affinityToken: string;
}

export class AgentAvailabilityAPI extends BaseAPI {
	constructor(readonly host: string, readonly apiVersion: number) {
		super();
	}

	private endpoint = APIEndpoints.agentAvailability;

	protected getUrl(): string {
		let paramsConfig = {
			'Availability.prefix':'Visitor',
			'deployment_id':'5722O000000008x',
			'org_id':'00D2O0000008qWo',
			'Availability.ids':'5732O0000000063'
		};
		const urlParamsConfig = '?' + queryString.stringify(paramsConfig);
		return this.endpoint+ urlParamsConfig;
	}

	protected getOptions(): any {
		let headerValues: IRequestHeader = {
			'Content-Type': 'application/json',
			'X-LIVEAGENT-API-VERSION': this.apiVersion
		};

		let optionsObj: IRequestOptions = {
			method: 'get',
			headers: headerValues
		};

		return optionsObj;
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

	public async execute() {
		let validation = this.validate();
		if (validation) {
			let response: any = await this.APIGatewayServices.fetch(this.getUrl(), this.getOptions());
			return await response.json();
		}
		return;
	}
}
