import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';
import { APIEndpoints } from '../../types/types';


export interface IRequestHeader {
	'X-LIVEAGENT-AFFINITY': string;
	'X-LIVEAGENT-API-VERSION': number;
}

export interface ChatSessionAPIResponse {
	key: string;
	id: string;
	clientPollTimeout: number;
	affinityToken: string;
}

export class ChatSessionAPI extends BaseAPI {
	constructor(
		readonly host: string,
		readonly affinity: string,
		readonly apiVersion: number) {
		super();
	}

	private endpoint = APIEndpoints.sessionId;

	protected getUrl(): string {
		return this.endpoint;
	}

	protected getOptions(): any {
		let headerValues: IRequestHeader = {
			'X-LIVEAGENT-AFFINITY': this.affinity,
			'X-LIVEAGENT-API-VERSION': this.apiVersion
		};

		let optionsObj: IRequestOptions = {
			method: 'get',
			headers: headerValues
		};

		return optionsObj;
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

	public async execute() {
		let validation = this.validate();
		if (validation) {
			let response: any = await this.APIGatewayServices.fetch(this.getUrl(), this.getOptions());
			return await response.json();
		}
		return;
	}
}
