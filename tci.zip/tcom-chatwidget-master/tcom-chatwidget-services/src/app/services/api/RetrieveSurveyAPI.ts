import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';

export interface IRequestHeader {
  'Content-Type': string;
}

export class RetrieveSurveyAPI extends BaseAPI {
  constructor(
    readonly host: string,
  ) {
    super();
  }

  private endpoint = '/services/apexrest/RetrieveSurveyQuestions/';

  protected getUrl(): string {
    return this.host + this.endpoint;
  }

  protected getOptions(): any {
    let headerValues: IRequestHeader = {
      'Content-Type': 'application/json',
    };

    let optionsObj: IRequestOptions = {
      method: 'get',
      headers: headerValues
    };

    return optionsObj;
  }

  protected validate(): boolean {
    return true;
  }

  protected handleSuccess(obj: any) {
    console.log(obj);
  }

  protected handleFailure(obj: any) {
    console.log(obj);
  }

  public async execute() {
    let validation = this.validate();
    if (validation) {
      let response = await fetch(this.getUrl(), this.getOptions());
      console.log(response)
      return await response.json();
    }
    return;
  }
}
