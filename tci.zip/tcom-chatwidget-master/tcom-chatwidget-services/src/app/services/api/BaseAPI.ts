import 'whatwg-fetch';
import { polyfill } from 'es6-promise';
import { GatewayFactory } from '../gateway/GatewayFactory';

export abstract class BaseAPI {

  APIGatewayServices: GatewayFactory = GatewayFactory.getInstance();

	protected abstract getUrl(): string;

	protected abstract validate(): boolean;

	protected abstract getOptions(): any;

	protected abstract handleSuccess(obj: any): any;

	protected abstract handleFailure(obj: any): any;
}

polyfill();
