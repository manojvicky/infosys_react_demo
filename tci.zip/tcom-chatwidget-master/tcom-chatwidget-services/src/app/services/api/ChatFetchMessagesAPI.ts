import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';
import { APIEndpoints } from '../../types/types';


export interface IRequestHeader {
	'Content-Type': string;
	'X-LIVEAGENT-AFFINITY': string;
	'X-LIVEAGENT-API-VERSION': number;
	'X-LIVEAGENT-SESSION-KEY': string;
}

export class ChatFetchMessagesAPI extends BaseAPI {
	constructor(
		readonly host: string,
		readonly affinity: string,
		readonly apiVersion: number,
		readonly sessionKey: string,
		readonly ack: string,
		readonly pc: string
	) {
		super();
	}

	private endpoint = APIEndpoints.messages+'?ack=' + this.ack + '&pc=' + this.pc;

	protected getUrl(): string {
		return this.endpoint;
	}

	protected getOptions(): any {
		let headerValues: IRequestHeader = {
			'Content-Type': 'application/json',
			'X-LIVEAGENT-AFFINITY': this.affinity,
			'X-LIVEAGENT-API-VERSION': this.apiVersion,
			'X-LIVEAGENT-SESSION-KEY': this.sessionKey
		};

		let optionsObj: IRequestOptions = {
			method: 'get',
			headers: headerValues
		};

		return optionsObj;
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

	public async execute() {
		let validation = this.validate();
		if (validation) {
			try{
			let response: any = await this.APIGatewayServices.fetch(this.getUrl(), this.getOptions());
			let responseObj = await response.text();
			if(response.status === 403){
				throw new Error('Session expired');
			}
			else if(response.status === 204){
				return {};
			}

			let returnObj: any = {};
			try{
				returnObj = JSON.parse(responseObj);
			}catch(e){
				//console.log('Failed in fetch messages '+e);
			}
			return returnObj;
		}catch(e){
			if(e && e.name === 'TypeError'){
					throw new Error('Service unavailable');
			}
			throw e;
		}
		}
		return;
	}
}
