import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';
import { APIEndpoints } from '../../types/types';


export interface IRequestHeader {
	'Content-Type': string;
	'X-LIVEAGENT-AFFINITY': string;
	'X-LIVEAGENT-API-VERSION': number;
	'X-LIVEAGENT-SESSION-KEY': string;
	'X-LIVEAGENT-SEQUENCE': string;
}

export class ChatEndAPI extends BaseAPI {
	constructor(
		readonly host: string,
		readonly affinity: string,
		readonly apiVersion: number,
		readonly sessionKey: string,
		readonly sequenceNumber: string,
	) {
		super();
	}

	private endpoint = APIEndpoints.endChat;

	protected getUrl(): string {
		return this.endpoint;
	}

	protected getOptions(): any {
		let headerValues: IRequestHeader = {
			'Content-Type': 'application/json',
			'X-LIVEAGENT-AFFINITY': this.affinity,
			'X-LIVEAGENT-API-VERSION': this.apiVersion,
			'X-LIVEAGENT-SESSION-KEY': this.sessionKey,
			'X-LIVEAGENT-SEQUENCE': this.sequenceNumber
		};

		let optionsObj: IRequestOptions = {
			method: 'POST',
			headers: headerValues,
			body: JSON.stringify({
				reason: 'client'
			})
		};

		return optionsObj;
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

	public async execute() {
		let validation = this.validate();
		if (validation) {
			let response: any = await this.APIGatewayServices.fetch(this.getUrl(), this.getOptions());
			return await response.text();
		}
		return;
	}
}
