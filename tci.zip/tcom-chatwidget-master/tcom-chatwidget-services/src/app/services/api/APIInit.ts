import { BaseAPI } from './BaseAPI';

export class APIInit extends BaseAPI {

	constructor(
		readonly endpointUrl: string
	) {
		super();
	}

	protected getUrl(): string {
		return '';
	}

	protected getOptions(): any {
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

  public async execute(){
    await this.APIGatewayServices.init(this.endpointUrl);
    return true;
  }

}
