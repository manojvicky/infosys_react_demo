import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';

export interface IRequestHeader {
  'Content-Type': string;
}


interface SingleResponse {
	id?: string;
	response?: string;
}

interface SurveyResponse {
	allQuestions? : SingleResponse[],
	chatKey?: string;
	survey?: string;
}


export class SubmitSurveyAPI extends BaseAPI {
  constructor(
    readonly host: string,
    readonly surveyResponse: SurveyResponse
  ) {
    super();
  }

  private endpoint = '/services/apexrest/SubmitSurveyQuestions/';

  protected getUrl(): string {
    return this.host + this.endpoint
  }

  protected getOptions(): any {
    let headerValues: IRequestHeader = {
      'Content-Type': 'application/json',
    };

    let contentObj = this.surveyResponse

    let optionsObj: IRequestOptions = {
      method: 'POST',
      headers: headerValues,
      body: JSON.stringify(contentObj)
    };

    return optionsObj;
  }

  protected validate(): boolean {
    return true;
  }

  protected handleSuccess(obj: any) {
    console.log(obj);
  }

  protected handleFailure(obj: any) {
    console.log(obj);
  }

  public async execute() {
    let validation = this.validate();
    if (validation) {
      let response = await fetch(this.getUrl(), this.getOptions());
      return await response.json();
    }
    return;
  }
}
