import { BaseAPI } from './BaseAPI';
import { IRequestOptions } from '../../types/IRequestDetails';
import { APIEndpoints } from '../../types/types';

export interface IRequestHeader {
	'Content-Type': string;
	'X-LIVEAGENT-AFFINITY': string;
	'X-LIVEAGENT-API-VERSION': number;
	'X-LIVEAGENT-SESSION-KEY': string;
	'X-LIVEAGENT-SEQUENCE': string;
}

export class ChatInitAPI extends BaseAPI {
	constructor(
		readonly host: string,
		readonly affinity: string,
		readonly apiVersion: number,
		readonly sessionKey: string,
		readonly sessionId: string,
		readonly sequenceNumber: string,
		readonly organizationId: string,
		readonly deploymentId: string,
		readonly buttonId: string,
		readonly contactUUID: string,
		readonly customerAccount: string,
		readonly caseNumber: string
	) {
		super();
	}

	private endpoint = APIEndpoints.init;

	protected getUrl(): string {
		return this.endpoint;
	}

	protected getOptions(): any {
		let headerValues: IRequestHeader = {
			'Content-Type': 'application/json',
			'X-LIVEAGENT-AFFINITY': this.affinity,
			'X-LIVEAGENT-API-VERSION': this.apiVersion,
			'X-LIVEAGENT-SESSION-KEY': this.sessionKey,
			'X-LIVEAGENT-SEQUENCE': this.sequenceNumber
		};

		let contentObj = {
			organizationId: this.organizationId,
			deploymentId: this.deploymentId,
			buttonId: this.buttonId,
			sessionId: this.sessionId,
			userAgent: navigator.userAgent,
			language: navigator.language,
			screenResolution: screen.width + 'x' + screen.height,
			visitorName: '',
			prechatDetails: [
					this.preparePreChatField('Contact UUID', this.contactUUID,'Contact_UUID__c',true),
					this.preparePreChatField('Customer Account (CAC)', this.customerAccount,'CAC__c',true),
					this.preparePreChatField('Case number', this.caseNumber,'Case_number__c',true)
			],
			buttonOverrides: [],
			receiveQueueUpdates: true,
			prechatEntities: [],
			isPost: true
		};

		let optionsObj: IRequestOptions = {
			method: 'post',
			headers: headerValues,
			body: JSON.stringify(contentObj)
		};

		return optionsObj;
	}

	protected preparePreChatField(fieldLabel: string, fieldValue: string, transcriptField: string, displayFlag: boolean){
		return {
        label: fieldLabel,
        value: fieldValue,
        entityMaps: [
				],
        transcriptFields: [
					transcriptField
				],
        displayToAgent: displayFlag,
        doKnowledgeSearch: false
		}
	}

	protected validate(): boolean {
		return true;
	}

	protected handleSuccess(obj: any) {
		console.log(obj);
	}

	protected handleFailure(obj: any) {
		console.log(obj);
	}

	public async execute() {
		let validation = this.validate();
		if (validation) {
			let response: any = await this.APIGatewayServices.fetch(this.getUrl(), this.getOptions());
			return await response.text();
		}
		return;
	}
}
