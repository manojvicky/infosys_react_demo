import { IframeAPIGateway } from './IframeAPIGateway';
import { DirectAPIGateway } from './DirectAPIGateway';
import { CommunicationModelType } from '../../types/types';

export class GatewayFactory {

  static commModelType = CommunicationModelType.IFRAME;

	private static _instance: any;

	static getInstance() {
		if (!GatewayFactory._instance) {
      if(GatewayFactory.commModelType === CommunicationModelType.IFRAME) {
        GatewayFactory._instance =  new IframeAPIGateway();
      }else{
        GatewayFactory._instance =  new DirectAPIGateway();
      }
		}
		return GatewayFactory._instance;
	}

  public init(url: string): void{

  }

  public fetch(url: string, options: any){

  }
}
