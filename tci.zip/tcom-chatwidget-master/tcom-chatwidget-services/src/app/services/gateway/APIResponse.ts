
export class APIResponse {

  ok: string;

  data: string;

  statusText: string;

  status: string;

  headers: {};

  constructor(e) {
    this.ok = 'true';
    this.statusText = e.result;
    this.status = e.status;
    this.data = e.data;
  }

  text = () => {
    return Promise.resolve(this.data);
  }

  json = () => {
    let response = this.data;
    let object: any;
    if (response) {
      try {
        object = JSON.parse(this.data);
        return Promise.resolve(object);
      } catch (e) {
        console.log('error caught ' + e);
      }
      return Promise.resolve(response);
    }
    return;
  }

  blob = () => Promise.resolve(new Blob([this.data]));
}
