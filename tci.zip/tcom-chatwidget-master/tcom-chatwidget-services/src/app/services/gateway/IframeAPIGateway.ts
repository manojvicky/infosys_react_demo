import { IRequestOptions } from '../../types/IRequestDetails';
import { ResponseType } from '../../types/types';
import { ChatUtil } from '../../util/ChatUtil';
import { APIResponse } from './APIResponse';

import * as _ from 'lodash';

export class IframeAPIGateway {

  child: any;
  childOrigin: any;
  iframeUrl: any;

  serviceCallers: any[] = [];

  init(url: string) {
    this.iframeUrl = url;
    return new Promise((resolve, reject) => {
      if (!this.childOrigin) {
        const messageEventCallBack = (e) => {
          if (this.sanitize(e.origin, 'salesforceliveagent.com')) {
            window.removeEventListener('message', messageEventCallBack)
            if (e.origin) {
              this.childOrigin = e.origin;
              resolve(true);
            } else {
              reject(true);
            }
          }
        }

        window.addEventListener("message", messageEventCallBack);
        this.createIframe('chat-root-iframe');
      } else {
        resolve(true);
      }
    });
  }

  createIframe(id: string) {
    let frame: any = document.createElement("iframe");
    frame.src = this.iframeUrl;
    frame.id = id;
    frame.style.display = "none";
    document.body.appendChild(frame);

    this.child = frame.contentWindow || frame.contentDocument.parentWindow
  }

  fetch(urlPart: string, options: any) {
    let inputObj = this.translateOptions(options, urlPart);
    return this.fetchService(inputObj);
  }

  listenerAttached: boolean = false;

  registerCallback() {
    if (!this.listenerAttached) {
      window.addEventListener('message', this.messageCallBack, false);
      this.listenerAttached = true;
    }
  }

  messageCallBack = (callbackData: any) => {
    if (this.sanitize(callbackData.origin, 'salesforceliveagent.com')) {
      this.callbackPromise(callbackData);
    }
  }

  fetchService(inputObj: any) {
    return this.preparePromise(inputObj);
  }

  preparePromise(inputObj: any) {
    var me = this;
    let serviceCallerId = inputObj.id;
    let inputData = JSON.stringify(inputObj);
    let newPromise = new Promise((resolve, reject) => {
      this.registerCallback();
      me.child.postMessage(inputData, '*');
      this.serviceCallers.push({ id: serviceCallerId, promise: newPromise, resolve: resolve, reject: reject });
    });

    return newPromise;
  }


  callbackPromise = (callbackData: any) => {
    let responseData: any = {
      result: 'error',
      status: 400,
      data: ''

    };

    if (callbackData && callbackData.data) {
      try {
        responseData = JSON.parse(callbackData.data);
      } catch (e) {
        console.log('Could not parse ' + e.data);
      }

      const filteredServiceCallers: any = this.serviceCallers.filter(i => {
        return i.id === responseData.id
      })[0];

      if (filteredServiceCallers) {
        let resolve = filteredServiceCallers.resolve;
        let reject = filteredServiceCallers.reject;
        if (responseData.result === ResponseType.SUCCESS) {
          return resolve(new APIResponse(responseData));
        }
        else {
          return reject(new APIResponse(responseData));
        }
      }
    }
  }

  protected sanitize = (origin: string, allowedOrigin: string) => {
    if (ChatUtil.endsWith(origin, allowedOrigin)) return true;

    return false;
  }

  /**
 * A unique message ID that is used to ensure responses are sent to the correct requests
 * @type {Number}
 */
  messageId: number = 0;

  /**
   * Increments and returns a message ID
   * @return {Number} A unique ID for a message
   */
  protected generateNewMessageId = () => {
    return ++this.messageId;
  }

  protected translateOptions(options: IRequestOptions, urlPart: string) {

    let objResult = _.toPairs(options.headers);

    let headerArrayTranslated = objResult.map(item => {
      return {
        name: item[0],
        value: item[1]
      }
    });

    let translatedOptions = {
      action: "send",
      async: true,
      headers: headerArrayTranslated,
      method: options.method,
      url: this.getUrl(urlPart),
      data: options.body || null,
      expectError: false,
      id: this.generateNewMessageId()
    };

    console.log('translatedOptions ' + JSON.stringify(translatedOptions));

    return translatedOptions;
  }

  protected getUrl(urlPart: string): string {
    return this.childOrigin + urlPart;
  }

}
