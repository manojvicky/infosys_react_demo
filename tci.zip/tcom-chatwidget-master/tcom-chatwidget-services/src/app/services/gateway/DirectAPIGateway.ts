import 'whatwg-fetch';

export class DirectAPIGateway {

  host = 'https://dev.cognitive-messaging.openaiplatform.telstra.com/v1/chat-widget-proxy/configuration/proxy';

  init(url: string){
    this.host = url;
  }

  fetch(url: string, options: any){
      return fetch(this.host+url, options);
  }

}
