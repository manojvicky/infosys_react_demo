/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-11T08:57:19+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-11T08:58:55+11:00
 * @Copyright: Telstra 2018
 */

declare var window: Window;

interface Window {
	readonly location: any;
}

export class ChatUtil {
	static fetchPageUrl(): string {
		let url: string = '';
		if (window) {
			url = window.location.pathname;
		}
		return url;
	}

	static parseURL(url: string) {
		var parser = document.createElement('a'),
			searchObject = {},
			queries,
			split,
			i;
		// Let the browser do the work
		parser.href = url;
		// Convert query string to object
		queries = parser.search.replace(/^\?/, '').split('&');
		for (i = 0; i < queries.length; i++) {
			split = queries[i].split('=');
			searchObject[split[0]] = split[1];
		}
		return {
			protocol: parser.protocol,
			host: parser.host,
			hostname: parser.hostname,
			port: parser.port,
			pathname: parser.pathname,
			search: parser.search,
			searchObject: searchObject,
			hash: parser.hash
		};
	}

	static endsWith(str: any, suffix: any) {
		return str.indexOf(suffix, str.length - suffix.length) !== -1;
	}
}
