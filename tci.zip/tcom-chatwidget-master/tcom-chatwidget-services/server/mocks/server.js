/**
 * @Author: kirankumar.parepalli
 * @Date:   2019-01-02T15:07:31+11:00
 * @Last modified by:   kirankumar.parepalli
 * @Last modified time: 2019-01-02T15:14:03+11:00
 * @Copyright: Telstra 2018
 */

 const jsonServer = require('json-server')
 const server = jsonServer.create()
 const router = jsonServer.router('chatManagerDev.json')
 const middlewares = jsonServer.defaults()

 server.use(middlewares)

 server.use('/chatManager/',router)

 server.listen(3004, () => {
   console.log('JSON Server is running')
 })
