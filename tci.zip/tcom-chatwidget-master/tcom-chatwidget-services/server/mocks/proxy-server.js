const axios = require('axios');
var proxy = require('http-proxy-middleware');
var express = require('express');
var cors = require('cors');
var request = require('request');

var app = express();

app.use(cors());

process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

console.log('tcom-chatwidget-services services started...');

app.use('/', function(req, res) {

  var proxyUsr = process.argv[2];
  var proxyPwd = process.argv[3];
  var proxyUrl = 'http://'+proxyUsr+':'+proxyPwd+'@http-gw.tcif.telstra.com.au:8080/';
  var proxiedRequest = request.defaults({'proxy': proxyUrl});
  var url = 'https://d.la1-c1cs-syd.salesforceliveagent.com' + req.url;
  req.pipe(proxiedRequest(url).on('response', function(response) {
    if(response){
          console.log(response.statusCode);
    }

    //console.log(response.headers['content-type'])
  })).pipe(res);
});

app.listen(process.env.PORT || 4001);
