var express = require('express');
var cors = require('cors');
var request = require('request');
var bodyParser = require('body-parser');

var app = express();

app.use(cors());
app.use(bodyParser());

process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

let sendMessageSwitch = false;
let sentMessage = '';
let sequenceNumber = 4;

app.use('/chat/rest/System/SessionId', function (req, res) {
  let response = {
    "key": "019990fa-e9a6-4599-806c-ac7d57b617fb!1553045380133!qRZbTiK6Qg+w6PKuoh5Yr43LWYM=",
    "id": "019990fa-e9a6-4599-806c-ac7d57b617fb",
    "clientPollTimeout": 40,
    "affinityToken": "950c1fa0"
  }
  res.send(response);
});

app.use('/chat/rest/Chasitor/ChasitorInit', function (req, res) {
  let response = 'OK';
  res.send(response);
});

app.use('/chat/rest/Chasitor/ChasitorTyping', function (req, res) {
  let response = 'OK';
  res.send(response);
});

app.use('/chat/rest/Chasitor/ChasitorNotTyping', function (req, res) {
  let response = 'OK';
  res.send(response);
});

app.use('/chat/rest/Chasitor/ChatEnd', function (req, res) {
  let response = 'OK';
  res.send(response);
});

app.use('/chat/rest/System/Messages', function (req, res) {

  let agentNotAvailableresponse = {
    "messages": [
      {
        "type": "ChatRequestFail",
        "message": {
          "reason": "Unavailable",
          "attachedRecords": [

          ],
          "postChatUrl": "https://telstra-retail--b2cdev29--c.cs116.visual.force.com/apex/takesurveyLA?id=a4e2O0000004pElQAI&cId=none&caId=none"
        }
      }
    ],
    "sequence": 0
  };

  let chatInProgress = {
    "messages": [
      {
        "type": "ChatRequestSuccess",
        "message": {
          "customDetails": [
          ],
          "connectionTimeout": 80000,
          "visitorId": "13779da5-6f72-41f0-8852-dcc2a9938654",
          "sensitiveDataRules": [
            {
              "name": "Credit_Card_All",
              "pattern": "3\\d{3}[ -/\\\\]*\\d{6}[ -/\\\\]*\\d{5}\n4\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}\n5\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}",
              "id": "0GO2O000000001d",
              "replacement": "crc*****",
              "actionType": "Replace"
            }
          ],
          "transcriptSaveEnabled": true,
          "url": "",
          "queuePosition": 1,
          "geoLocation": {
            "organization": "Telstra Internet",
            "region": "NSW",
            "countryName": "Australia",
            "latitude": -33.8615,
            "countryCode": "AU",
            "longitude": 151.2055
          },
          "postChatUrl": "https://telstra-retail--b2cdev29--c.cs116.visual.force.com/apex/takesurveyLA?id=a4e2O0000004pElQAI&cId=none&caId=none"
        }
      },
      {
        "type": "ChatEstablished",
        "message": {
          "name": "Kiran P",
          "userId": "0052O000000dfX2",
          "items": [

          ],
          "sneakPeekEnabled": false,
          "chasitorIdleTimeout": {
            "isEnabled": true,
            "warningTime": 10,
            "timeout": 20
          }
        }
      },
      {
        "type": "QueueUpdate",
        "message": {
          "position": 0
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "Hi John and welcome to 24x7 chat.",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      }
    ],
    "sequence": 3,
    "offset": 83623832
  };

  let chatInProgressMaxUnread = {
    "messages": [
      {
        "type": "ChatRequestSuccess",
        "message": {
          "customDetails": [
          ],
          "connectionTimeout": 80000,
          "visitorId": "13779da5-6f72-41f0-8852-dcc2a9938654",
          "sensitiveDataRules": [
            {
              "name": "Credit_Card_All",
              "pattern": "3\\d{3}[ -/\\\\]*\\d{6}[ -/\\\\]*\\d{5}\n4\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}\n5\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}",
              "id": "0GO2O000000001d",
              "replacement": "crc*****",
              "actionType": "Replace"
            }
          ],
          "transcriptSaveEnabled": true,
          "url": "",
          "queuePosition": 1,
          "geoLocation": {
            "organization": "Telstra Internet",
            "region": "NSW",
            "countryName": "Australia",
            "latitude": -33.8615,
            "countryCode": "AU",
            "longitude": 151.2055
          },
          "postChatUrl": "https://telstra-retail--b2cdev29--c.cs116.visual.force.com/apex/takesurveyLA?id=a4e2O0000004pElQAI&cId=none&caId=none"
        }
      },
      {
        "type": "ChatEstablished",
        "message": {
          "name": "Kiran P",
          "userId": "0052O000000dfX2",
          "items": [

          ],
          "sneakPeekEnabled": false,
          "chasitorIdleTimeout": {
            "isEnabled": true,
            "warningTime": 10,
            "timeout": 20
          }
        }
      },
      {
        "type": "QueueUpdate",
        "message": {
          "position": 0
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "Hi John and welcome to 24x7 chat.",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "2",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "3",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "4",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "5",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "6",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "7",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "8",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "9",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      },
      {
        "type": "ChatMessage",
        "message": {
          "text": "10",
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      }
    ],
    "sequence": 3,
    "offset": 83623832
  };

  let connectingMsg = {
    "messages": [
      {
        "type": "ChatRequestSuccess",
        "message": {
          "customDetails": [
          ],
          "connectionTimeout": 80000,
          "visitorId": "13779da5-6f72-41f0-8852-dcc2a9938654",
          "sensitiveDataRules": [
            {
              "name": "Credit_Card_All",
              "pattern": "3\\d{3}[ -/\\\\]*\\d{6}[ -/\\\\]*\\d{5}\n4\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}\n5\\d{3}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}[ -/\\\\]*\\d{4}",
              "id": "0GO2O000000001d",
              "replacement": "crc*****",
              "actionType": "Replace"
            }
          ],
          "transcriptSaveEnabled": true,
          "url": "",
          "queuePosition": 1,
          "geoLocation": {
            "organization": "Telstra Internet",
            "region": "NSW",
            "countryName": "Australia",
            "latitude": -33.8615,
            "countryCode": "AU",
            "longitude": 151.2055
          },
          "postChatUrl": "https://telstra-retail--b2cdev29--c.cs116.visual.force.com/apex/takesurveyLA?id=a4e2O0000004pElQAI&cId=none&caId=none"
        }
      },]
  };



  let successResponse2 = {
    "messages": [
      {
        "type": "ChatMessage",
        "message": {
          "text": fetchNextMessage(),
          "name": "Kiran P",
          "schedule": {
            "responseDelayMilliseconds": 0.0
          },
          "agentId": "0052O000000dfX2"
        }
      }
    ],
    "sequence": sequenceNumber++,
    "offset": 83624155
  };

  let agentTypingResponse = {
    "messages": [
      {
        "type": "AgentTyping",
        "message": {
        }
      }
    ],
    "sequence": sequenceNumber++,
    "offset": 84055253
  };

  let agentNotTypingResponse = {
    "messages": [
      {
        "type": "AgentNotTyping",
        "message": {
        }
      }
    ],
    "sequence": sequenceNumber++,
    "offset": 84055253
  };

  let chatTransferResponse = {
    "messages": [
      {
        "type": "ChatTransferred",
        "message": {
          "attachedRecords": [],
          "reason": "agent"
        }
      }
    ],
    "sequence": sequenceNumber++,
    "offset": 84055253
  };

  let chatEndResponse = {
    "messages": [
      {
        "type": "ChatEnded",
        "message": {
          "attachedRecords": [],
          "reason": "agent"
        }
      }
    ],
    "sequence": sequenceNumber++,
    "offset": 84055253
  }

  setTimeout(() => {

    if (req.query.ack == -1 && req.query.pc == 0) {
      // res.send(connectingMsg)
      res.send(chatInProgress)
      // res.send(chatInProgressMaxUnread)
      // res.send(agentNotAvailableresponse) //Agents offline
      // } else if (req.query.ack !=-1 && req.query.pc==8){
      //   res.send(chatEndResponse)
    } else {
      if (sendMessageSwitch) {
        if(sentMessage === '#transfer@'){
            res.send(chatTransferResponse);
        }else if(sentMessage === '#ended@'){
          res.send(chatEndResponse);
        }else if(sentMessage === '#typing@'){
          res.send(agentTypingResponse);
        }else if(sentMessage === '#not_typing@'){
          res.send(agentNotTypingResponse);
        }else{
          res.send(successResponse2);
        }
        sendMessageSwitch = false;
      } else {
        res.send();
      }
    }
  }, 3000);
});

app.use('/chat/rest/Chasitor/ChatMessage', function (req, res) {

  sentMessage = req.body.text;
  let response = 'OK';
  sendMessageSwitch = true;
  res.send(response);
});

let fakeMessages = [
  { id: 0, message: 'Welcome!!' },
  { id: 1, message: 'Hi there, I\'m Kiran and you?' },
  { id: 2, message: 'Nice to meet you' },
  { id: 3, message: 'How are you?' },
  { id: 4, message: 'Not too bad, thanks' },
  { id: 5, message: 'What do you do?' },
  { id: 6, message: 'That\'s awesome' },
  { id: 7, message: 'Melbourne is a nice place to stay' },
  { id: 8, message: 'I think you\'re a nice person' },
  { id: 9, message: 'Why do you think that?' },
  { id: 10, message: 'Can you explain?' },
  { id: 11, message: 'Anyway I\'ve gotta go now' },
  { id: 12, message: 'It was a pleasure chat with you' },
  { id: 13, message: 'Time to take leave for today' },
  { id: 14, message: 'Bye' },
  { id: 15, message: ':)' }
];

let messageCounter = 0;

function fetchNextMessage() {
  if (messageCounter === fakeMessages.length)
    messageCounter = 0;

  let text = fakeMessages.filter(function (el) {
    return el.id == messageCounter
  })[0].message;

  messageCounter++;
  return text;
}

app.listen(process.env.PORT || 4001);
