import { SET_ERROR, RESET_ERROR } from 'constants/actions';

export const setError = (error, errorStatusCode, errorMessage) => {
  return {
    type: SET_ERROR,
    hasErrored: error,
    errorStatusCode,
    errorMessage
  };
};

export const resetError = () => {
  return {
    type: RESET_ERROR,
    hasErrored: false,
    errorStatusCode: '',
    errorMessage: ''
  };
};
