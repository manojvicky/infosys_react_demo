import {RECEIVE_UNENROLE_USER, REQUEST_UNENROLE_USER,
  OPTOUT_RESULT_SUCCESS, OPTOUT_RESULT_NOT_ENROLLED, OPTOUT_RESULT_FAIL} from 'constants/actions';

import OptOutApi from 'api/optOutApi';
import GenericUtil from 'utils/GenericUtil';
import { LOGGER } from 'utils/AppLog';


export function requestUnenroleAction() {  
  return {
    type: REQUEST_UNENROLE_USER
  };
}

export function receiveUnenroleAction(response) {
  return {
    type: RECEIVE_UNENROLE_USER,
    unenrolResponse: response
  };
}


export default function unenrolUser(token){
  return (dispatch) => {
    dispatch(requestUnenroleAction());
    return OptOutApi(token).then( response => {
      LOGGER.debug("Unenroll response JSON", response);
      let status = GenericUtil.nvl(response, 'status');
      let loyaltyOptIn = GenericUtil.nvl(response, 'data.data.individual.loyaltyOptIn');
      if (loyaltyOptIn != null && loyaltyOptIn === false) { //correct response
        dispatch(receiveUnenroleAction({result: OPTOUT_RESULT_SUCCESS, errorMsg: null}));
      } else if (status && status === 422) {
        let errorMsg = GenericUtil.nvl(response, 'data.errors.0.message', null);
        dispatch(receiveUnenroleAction({result: OPTOUT_RESULT_NOT_ENROLLED, errorMsg: errorMsg}));
      } else {
        let errorMsg = GenericUtil.nvl(response, 'data.errors.0.message', null);
        dispatch(receiveUnenroleAction({result: OPTOUT_RESULT_FAIL, errorMsg: errorMsg}));
      }
    });
  }
}

