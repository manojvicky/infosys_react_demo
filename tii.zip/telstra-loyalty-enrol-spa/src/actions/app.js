// Action Types, Describe what is happening
import {
  SET_INITIALISED,
  SET_AUTHENTICATED,
  SET_AUTH_PREFLIGHT,
  SET_ORIGINURL
} from 'constants/actions';

// Action Creators
export const toggleInitialised = initialised => {
  return { type: SET_INITIALISED, initialised };
};

export const toggleAuthenticated = authenticated => {
  return { type: SET_AUTHENTICATED, authenticated };
};

export const setAuthPreFlight = isPreFlight => {
  return { type: SET_AUTH_PREFLIGHT, isPreFlight };
};

export const setOriginURL = originUrl => {
  return {
    type: SET_ORIGINURL,
    originUrl
  };
};
