import * as types from 'constants/actions';
import * as appActions from 'actions/app';
import * as enrolActions from 'actions/enrolment';
import * as eligibleActions from 'actions/eligibility';
import * as errorActions from 'actions/error';

describe('Dispatching actions', () => {
  const boolVariable = true;
  it('Should set "initialised" to true', () => {
    const expectedAction = {
      type: types.SET_INITIALISED,
      initialised: true
    };
    expect(appActions.toggleInitialised(boolVariable)).toEqual(expectedAction);
  });

  it('Should set "authenticated" to true', () => {
    const expectedAction = {
      type: types.SET_AUTHENTICATED,
      authenticated: true
    };
    expect(appActions.toggleAuthenticated(boolVariable)).toEqual(
      expectedAction
    );
  });

  it('Should set "enrolled" to true', () => {
    const expectedAction = {
      type: types.SET_ENROLLED,
      enrolled: true
    };
    expect(enrolActions.toggleEnrolled(boolVariable)).toEqual(expectedAction);
  });

  it('Should set "enrolling" to true', () => {
    const expectedAction = {
      type: types.SET_ENROLLING,
      enrolling: true
    };
    expect(enrolActions.toggleEnrolling(boolVariable)).toEqual(expectedAction);
  });

  it('Should set "eligible" to true', () => {
    const expectedAction = {
      type: types.SET_ELIGIBLE,
      eligible: true
    };
    expect(eligibleActions.toggleEligible(boolVariable)).toEqual(
      expectedAction
    );
  });

  it('Should set "enrolling" to true', () => {
    const expectedAction = {
      type: types.SET_ENROLLING,
      enrolling: true
    };
    expect(enrolActions.toggleEnrolling(boolVariable)).toEqual(expectedAction);
  });

  it('Should set "error" to true', () => {
    const expectedAction = {
      type: types.SET_ERROR,
      hasErrored: true
    };
    expect(errorActions.setError(boolVariable)).toEqual(expectedAction);
  });

  it('Should set "enrolFailed" to true', () => {
    const expectedAction = {
      type: types.SET_ENROLFAILED,
      enrolFailed: true
    };
    expect(enrolActions.toggleEnrolFailed(boolVariable)).toEqual(
      expectedAction
    );
  });

  it('Should set "hasCheckedEligibility" to true', () => {
    const expectedAction = {
      type: types.SET_HASCHECKEDELIGIBILITY,
      hasCheckedEligibility: true
    };
    expect(eligibleActions.toggleHasCheckedEligibility(boolVariable)).toEqual(
      expectedAction
    );
  });

  it('Should update test with "true", "401" and "Error message test"', () => {
    const errorStatusCode = 401;
    const errorMessage = 'Error message test';
    const expectedAction = {
      type: types.SET_ERROR,
      hasErrored: true,
      errorStatusCode,
      errorMessage
    };
    expect(
      errorActions.setError(boolVariable, errorStatusCode, errorMessage)
    ).toEqual(expectedAction);
  });
});
