import {
  SET_ENROLLING,
  SET_ENROLLED,
  SET_ENROLFAILED
} from 'constants/actions';

export const toggleEnrolled = enrolled => {
  return { type: SET_ENROLLED, enrolled };
};

export const toggleEnrolling = enrolling => {
  return { type: SET_ENROLLING, enrolling };
};

export const toggleEnrolFailed = enrolFailed => {
  return { type: SET_ENROLFAILED, enrolFailed };
};
