import * as types from 'constants/actions';
//import * as accountDetails from 'actions/accountDetails';  - the file is empty, causes test run error

describe('Dispatching actions', () => {
  const boolVariable = true;
  xit('Should set "initialised" to true', () => {
    const expectedAction = {
      type: types.SET_INITIALISED,
      initialised: true
    };
    expect(accountDetails.toggleInitialised(boolVariable)).toEqual(
      expectedAction
    );
  });
});
