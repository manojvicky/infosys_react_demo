
import optOutReducer from 'reducers/optOut'; 
import unenrolUser, {receiveUnenroleAction, requestUnenroleAction} from 'actions/optOut';
import {OPTOUT_RESULT_SUCCESS, OPTOUT_RESULT_NOT_ENROLLED, OPTOUT_RESULT_FAIL} from 'constants/actions';

import OptOutApi from 'api/optOutApi';
jest.mock('api/optOutApi');


describe('optOut Module', ()=>{

    xit('testing deep copy', ()=>{
        let f = {g: "hello"};
        let a = {b: {c: {d: 'e', f: f}}}
        
        let var1 = Object.assign({}, a, {isLoading: true});
        let var2 = {...a, isLoading:true};
        let var3 = Object.assign({}, JSON.parse(JSON.stringify(a)), {isLoading: true});

        expect(var1.b.c.f.g).toEqual("hello");
        expect(var2.b.c.f.g).toEqual("hello");
        expect(var3.b.c.f.g).toEqual("hello");

        f["g"] = "hello World";

        expect(var1.b.c.f.g).toEqual("hello");
        expect(var2.b.c.f.g).toEqual("hello");
        expect(var3.b.c.f.g).toEqual("hello");
    });

    describe('reducer and action combined', ()=>{
        it('returns success optout state on success unenrol action', ()=>{
            let successOptOutRespAction = receiveUnenroleAction({result: OPTOUT_RESULT_SUCCESS, errorMsg: null})
            expect(optOutReducer(undefined, successOptOutRespAction)).toEqual({
                    isLoading: false,
                    optOutResult: OPTOUT_RESULT_SUCCESS,
                    optOutErrorMsg: null
                });
        });

        it('returns loading optout state on calling unenrol action', ()=>{
            let callingOptOutReqAction = requestUnenroleAction();
            expect(optOutReducer(undefined, callingOptOutReqAction)).toEqual({
                    isLoading: true,
                    optOutResult: null,
                    optOutErrorMsg: null
                });
        });

        it('returns success optout state on fail unenrol action', ()=>{
            let successOptOutRespAction = receiveUnenroleAction({result: "random result", errorMsg: "random error message"})
            expect(optOutReducer(undefined, successOptOutRespAction)).toEqual({
                    isLoading: false,
                    optOutResult: "random result",
                    optOutErrorMsg: "random error message"
                });
        });
        
    });

    describe('unenrol user api calling handling', ()=>{
        const dispatch = jest.fn();
        it('should call received action success on success response from api', async ()=>{
            OptOutApi.mockResolvedValue({status: 200,data:{data:{individual:{loyaltyOptIn:false}}}});
            let a = await unenrolUser(123)(dispatch);
            expect(dispatch).toHaveBeenCalledWith(receiveUnenroleAction({result: OPTOUT_RESULT_SUCCESS, errorMsg: null}));
        });

        it('should call received action fail on incorrect response from api', async ()=>{
            OptOutApi.mockResolvedValue({status: 200,data:{data:{individual:{loyaltyOptIn: true}}}});
            let a = await unenrolUser(123)(dispatch);
            expect(dispatch).toHaveBeenCalledWith(receiveUnenroleAction({result: OPTOUT_RESULT_FAIL, errorMsg: null}));
        });

        it('should call received action unenrolled on error 442 response from api', async ()=>{
            OptOutApi.mockResolvedValue({status: 422, data:{errors:[{message: "random 503 error message"}]}});
            let a = await unenrolUser(123)(dispatch);
            expect(dispatch).toHaveBeenCalledWith(receiveUnenroleAction({result: OPTOUT_RESULT_NOT_ENROLLED, errorMsg: "random 503 error message"}));
        });

        it('should call received action fail on error 503 response from api', async ()=>{
            OptOutApi.mockResolvedValue({status: 503, data:{errors:[{message: "random 422 error message"}]}});
            let a = await unenrolUser(123)(dispatch);
            expect(dispatch).toHaveBeenCalledWith(receiveUnenroleAction({result: OPTOUT_RESULT_FAIL, errorMsg: "random 422 error message"}));
        });
    });




});