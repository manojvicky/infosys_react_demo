// Action Types, Describe what is happening
import * as actions from 'constants/actions';

import getPoints from 'api/getPoints';
import getPointsHistory from 'api/getPointsHistory';

import { fetchPointsPending } from 'reducers/points';
import { fetchPointsHistoryPending } from 'reducers/pointsHistory';

// Action Creators
export const fetchPoints = (accessToken, cac) => (dispatch, getState) => {
  if (fetchPointsPending(getState())) {
    return Promise.resolve();
  }

  dispatch({
    type: actions.GET_POINTS_PENDING
  });

  return getPoints(accessToken, cac).then(
    response => {
      dispatch({
        type: actions.GET_POINTS_SUCCESS,
        response
      });
    },
    () => {
      dispatch({
        type: actions.GET_POINTS_FAILURE
      });
    }
  );
};

export const fetchPointsHistory = (accessToken, cac) => (
  dispatch,
  getState
) => {
  if (fetchPointsHistoryPending(getState())) {
    return Promise.resolve();
  }

  dispatch({
    type: actions.GET_POINTS_PENDING
  });

  return getPointsHistory(accessToken, cac).then(
    response => {
      dispatch({
        type: actions.GET_POINTS_SUCCESS,
        response
      });
    },
    () => {
      dispatch({
        type: actions.GET_POINTS_FAILURE
      });
    }
  );
};

export const updatePoints = pointsvalue => {
  return { type: actions.GET_POINTS_SUCCESS, points: pointsvalue };
};
