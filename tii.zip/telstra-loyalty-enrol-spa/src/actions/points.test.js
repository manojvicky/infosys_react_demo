import * as actions from 'constants/actions';
import reducers from './app.js';

const defaultState = {
  initialised: false,
  authenticated: false,
  originUrl: null
};

describe('reducers', () => {
  xtest('should return the initial state', () => {
    const initialState = {
      ...defaultState
    };

    expect(reducers(undefined, {})).toEqual(initialState);
  });
});
