// Action Types, Describe what is happening
import { SET_ELIGIBLE, SET_HASCHECKEDELIGIBILITY } from 'constants/actions';

// Action Creators

export const toggleEligible = eligible => {
  return { type: SET_ELIGIBLE, eligible };
};

export const toggleHasCheckedEligibility = () => {
  return { type: SET_HASCHECKEDELIGIBILITY, hasCheckedEligibility: true };
};
