import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';

// Import all reducers
import app from './app';
import activeAccount from './activeAccount';
import error from './error';
import enrolment from './enrolment';
import eligibility from './eligibility';
import points from './points';
import pointsHistory from './pointsHistory';
import optOut from './optOut';

export default history =>
  combineReducers({
    app,
    activeAccount,
    error,
    enrolment,
    eligibility,
    points,
    pointsHistory,
    optOut,
    router: connectRouter(history)
  });

export const testReducers = () => {
  combineReducers({
    app,
    error,
    enrolment,
    points,
    eligibility
  });
};
