// Action Types, Describe what is happening
import * as actions from 'constants/actions';

const initialState = {
  initialised: false,
  authenticated: false,
  authPreFlight: false,
  originUrl: { pathname: '', search: '' }
};

export default function appChange(state = initialState, action) {
  switch (action.type) {
    case actions.SET_INITIALISED:
      return {
        ...state,
        initialised: action.initialised
      };
    case actions.SET_AUTHENTICATED:
      return {
        ...state,
        authenticated: action.authenticated
      };
    case actions.SET_AUTH_PREFLIGHT:
      return {
        ...state,
        authPreFlight: action.authPreFlight
      };
    case actions.SET_ORIGINURL:
      return {
        ...state,
        originUrl: action.originUrl
      };
    default:
      return state;
  }
}
