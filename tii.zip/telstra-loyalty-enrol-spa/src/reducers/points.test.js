describe('Points Tests', () => {
  it('placeholder', () => {});
});
