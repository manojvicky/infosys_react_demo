import * as actions from 'constants/actions';
import reducers from './app.js';

// would usually have mock data to test with
// import products from '../data/products';

const defaultState = {
  initialised: false,
  authenticated: false,
  authPreFlight: false,
  originUrl: { pathname: '', search: '' }
};

describe('reducers', () => {
  test('should return the initial state', () => {
    const initialState = {
      ...defaultState
    };

    expect(reducers(undefined, {})).toEqual(initialState);
  });

  it('should handle SET_AUTHENTICATED', () => {
    const pageAuthenticatedState = {
      ...defaultState,
      authenticated: true
    };

    const expectedState = {
      ...defaultState,
      authenticated: true
    };

    const action = {
      type: actions.SET_AUTHENTICATED,
      authenticated: true
    };
    expect(reducers(pageAuthenticatedState, action)).toEqual(expectedState);
  });

  it('should handle SET_INITIALISED', () => {
    const intialisedState = {
      ...defaultState,
      authenticated: true,
      initialised: true
    };

    const expectedState = {
      ...defaultState,
      authenticated: true,
      initialised: true
    };

    const action = {
      type: actions.SET_INITIALISED,
      initialised: true
    };
    expect(reducers(intialisedState, action)).toEqual(expectedState);
  });

  it('should handle SET_HASCHECKEDELIGIBILITY', () => {
    const hasCheckedState = {
      ...defaultState,
      initialised: true,
      authenticated: true,
      hasCheckedEligibility: true
    };

    const expectedState = {
      ...defaultState,
      initialised: true,
      authenticated: true,
      hasCheckedEligibility: true
    };

    const action = {
      type: actions.SET_HASCHECKEDELIGIBILITY,
      hasCheckedEligibility: true
    };
    expect(reducers(hasCheckedState, action)).toEqual(expectedState);
  });

  it('should handle SET_ELIGIBLE', () => {
    const pageEligibleState = {
      ...defaultState,
      intialised: true,
      authenticated: true,
      eligible: true
    };

    const expectedState = {
      ...defaultState,
      intialised: true,
      authenticated: true,
      eligible: true
    };

    const action = {
      type: actions.SET_ELIGIBLE,
      eligible: true
    };
    expect(reducers(pageEligibleState, action)).toEqual(expectedState);
  });

  it('should handle SET_ENROLLING', () => {
    const enrollingState = {
      ...defaultState,
      enrolling: true
    };

    const expectedState = {
      ...defaultState,
      enrolling: true
    };

    const action = {
      type: actions.SET_ENROLLING,
      enrolling: true
    };
    expect(reducers(enrollingState, action)).toEqual(expectedState);
  });

  it('should handle SET_ENROLLED', () => {
    const enrolledState = {
      ...defaultState,
      enrolled: true
    };

    const expectedState = {
      ...defaultState,
      enrolled: true
    };

    const action = {
      type: actions.SET_ENROLLED,
      enrolled: true
    };
    expect(reducers(enrolledState, action)).toEqual(expectedState);
  });

  it('should handle SET_ENROLFAILED', () => {
    const enrolledState = {
      ...defaultState,
      enrolFailed: true,
      enrolled: false
    };

    const expectedState = {
      ...defaultState,
      enrolFailed: true,
      enrolled: false
    };

    const action = {
      type: actions.SET_ENROLFAILED,
      enrolFailed: true
    };
    expect(reducers(enrolledState, action)).toEqual(expectedState);
  });

  it('should handle SET_ERROR', () => {
    const errorState = {
      ...defaultState,
      hasErrored: true,
      errorStatusCode: 401,
      errorMessage: 'Test error message'
    };

    const expectedState = {
      ...defaultState,
      hasErrored: true,
      errorStatusCode: 401,
      errorMessage: 'Test error message'
    };

    const action = {
      type: actions.SET_ERROR,
      hasErrored: true,
      errorStatusCode: 401,
      errorMessage: 'Test error message'
    };
    expect(reducers(errorState, action)).toEqual(expectedState);
  });

  it('should handle SET_ORIGINURL', () => {
    const originUrlState = {
      ...defaultState,
      originUrl: {
        ancestorOrigins: {},
        hash: '',
        host: 'plus.np.in.telstra.com.au',
        hostname: 'plus.np.in.telstra.com.au',
        href: 'https://plus.np.in.telstra.com.au/',
        origin: 'https://plus.np.in.telstra.com.au',
        pathname: '/',
        port: '',
        protocol: 'https:',
        search: ''
      }
    };

    const expectedState = {
      ...defaultState,
      originUrl: {
        ancestorOrigins: {},
        hash: '',
        host: 'plus.np.in.telstra.com.au',
        hostname: 'plus.np.in.telstra.com.au',
        href: 'https://plus.np.in.telstra.com.au/',
        origin: 'https://plus.np.in.telstra.com.au',
        pathname: '/',
        port: '',
        protocol: 'https:',
        search: ''
      }
    };

    const action = {
      type: actions.SET_ORIGINURL,
      originUrl: {
        ancestorOrigins: {},
        hash: '',
        host: 'plus.np.in.telstra.com.au',
        hostname: 'plus.np.in.telstra.com.au',
        href: 'https://plus.np.in.telstra.com.au/',
        origin: 'https://plus.np.in.telstra.com.au',
        pathname: '/',
        port: '',
        protocol: 'https:',
        search: ''
      }
    };
    expect(reducers(originUrlState, action)).toEqual(expectedState);
  });

  //   it('should handle REMOVE_PRODUCT_FROM_CART', () => {
  //     const cartLoadedState = {
  //       products,
  //       cartProducts: [products[0], products[2]],
  //       pageProducts: {
  //         initialised: true,
  //         products: [products[1]]
  //       }
  //     };

  //     const expectedState = {
  //       products,
  //       cartProducts: [products[0]],
  //       pageProducts: {
  //         initialised: true,
  //         products: [products[1], products[2]]
  //       }
  //     };

  //     const action = {
  //       type: actions.REMOVE_PRODUCT_FROM_CART,
  //       product: products[2]
  //     };
  //     expect(reducers(cartLoadedState, action)).toEqual(expectedState);
  //   });
});
