// Action Types, Describe what is happening
import _ from 'lodash';

import { SET_ELIGIBLE, SET_HASCHECKEDELIGIBILITY } from 'constants/actions';

const defaultState = {
  eligible: false,
  hasCheckedEligibility: false,
  getDetails: {
    data: {
      accounts: [
        {
          accountId: '',
          loyaltyTier: 'MEMBER'
        }
      ]
    }
  }
};

export default function appChange(state = defaultState, action) {
  switch (action.type) {
    case SET_ELIGIBLE: {
      const { accounts } = action.getDetails.data;
      const orderedAcc = _.orderBy(accounts, ['accountId'], ['asc']);

      action.getDetails.data.accounts = orderedAcc;

      return {
        ...state,
        eligible: action.eligible,
        getDetails: action.getDetails || defaultState.getDetails
      };
    }
    case SET_HASCHECKEDELIGIBILITY:
      return {
        ...state,
        hasCheckedEligibility: true
      };
    default:
      return state;
  }
}
