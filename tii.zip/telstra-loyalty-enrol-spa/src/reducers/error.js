import { SET_ERROR, RESET_ERROR } from 'constants/actions';

const errorState = {
  hasErrored: false,
  errorMessage: '',
  errorStatusCode: ''
};

export default function error(state = errorState, action) {
  switch (action.type) {
    case SET_ERROR:
      return {
        hasErrored: action.hasErrored,
        errorMessage: action.errorMessage,
        errorStatusCode: action.errorStatusCode
      };
    case RESET_ERROR:
      return {
        hasErrored: false,
        errorMessage: '',
        errorStatusCode: ''
      };
    default: {
      return state;
    }
  }
}
