import {REQUEST_UNENROLE_USER, RECEIVE_UNENROLE_USER} from 'constants/actions';


export default function reducer(state = {
  isLoading: false,
  optOutResult: null,
  optOutErrorMsg: null
}, action) {
  switch (action.type) {
      //DONE - jack - to check if ...state does the same as object assign,
      // for objects that's multiple levels deep. (deep copy vs shallow copy)
      //ANSWER: turns out both Object.assign and ... does shallow copies
      // JSON.parse(JSON.stringify(a)) would do a deep copy
      case REQUEST_UNENROLE_USER:
          return {...state, isLoading: true};
      case RECEIVE_UNENROLE_USER:
          return { ...state, 
            isLoading: false,
            optOutResult: action.unenrolResponse.result,
            optOutErrorMsg: action.unenrolResponse.errorMsg};
      default:
          return state;
  }

};
