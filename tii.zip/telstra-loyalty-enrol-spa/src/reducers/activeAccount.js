// Action Types, Describe what is happening
import _ from 'lodash';

import {
  SWITCH_ACCOUNT,
  SET_INITIAL_ACCOUNT,
  SET_INITIAL_POINTS,
  SET_ACCOUNTS_LIST,
  MERGE_ACCOUNTS_LIST
} from 'constants/actions';

const activeAccountState = {
  membershipIndex: 1,
  pointsValue: '',
  sortedAccounts: [{}],
  cacList: ''
};

export default function appChange(state = activeAccountState, action) {
  let accountsWithPoints;
  switch (action.type) {
    case SWITCH_ACCOUNT:
      return {
        ...state,
        ...action.cac,
        membershipIndex: action.membershipIndex,
        pointsValue: action.pointsValue
      };
    case SET_INITIAL_ACCOUNT:
      return {
        ...state,
        ...action.cac,
        membershipIndex: 1
      };
    case SET_INITIAL_POINTS:
      return {
        ...state,
        pointsValue: action.pointsValue
      };
    case SET_ACCOUNTS_LIST:
      return {
        ...state,
        cacList: action.cacList,
        sortedAccounts: action.sortedAccounts
      };
    case MERGE_ACCOUNTS_LIST:
      accountsWithPoints = _.merge(
        state.sortedAccounts,
        action.sortedPointsAccounts
      );

      accountsWithPoints = accountsWithPoints.filter(orderedCac => {
        return orderedCac.enrollmentStatus === 'ENROLLED';
      });

      return {
        ...state,
        sortedAccounts: accountsWithPoints
      };
    default:
      return state;
  }
}
