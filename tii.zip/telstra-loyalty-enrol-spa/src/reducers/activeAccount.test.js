import reducers from './activeAccount';

describe('activeAccount tests', () => {
  it('activeAccount Placeholder', () => {});
});

const activeAccountState = {
  membershipIndex: 1,
  pointsValue: '',
  sortedAccounts: [{}],
  cacList: ''
};

describe('activeAccount', () => {
  test('should return the initial state', () => {
    const initialState = {
      ...activeAccountState
    };

    expect(reducers(undefined, {})).toEqual(initialState);
  });
});

// @TODO More Unit Tests
