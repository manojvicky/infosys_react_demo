import {
  SET_ENROLLING,
  SET_ENROLLED,
  SET_ENROLFAILED
} from 'constants/actions';

const enrolmentState = {
  enrolled: false,
  enrolFailed: false,
  enrolling: false,
  membership: {
    joinDate: '14 May 2019',
    tier: 'Gold'
  }
};

export default function enrolment(state = enrolmentState, action) {
  switch (action.type) {
    case SET_ENROLLING:
      return {
        ...state,
        enrolling: action.enrolling
      };
    case SET_ENROLLED:
      return {
        ...state,
        enrolled: action.enrolled
      };
    case SET_ENROLFAILED:
      return {
        ...state,
        enrolFailed: action.enrolFailed
      };
    default: {
      return state;
    }
  }
}
