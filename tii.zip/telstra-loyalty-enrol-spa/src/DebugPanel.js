import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import Checkbox from 'components/Checkbox';

import AppLog from 'utils/AppLog';

/* eslint-disable */
class DebugPanel extends React.Component {
  constructor(props) {
    super(props);
    this.log = new AppLog('DebugPanel');

    this.genRoutesFromChildren(props.children);
  }

  genRoutesFromChildren(children) {
    //this method currently doesn't handle nulls too well, but low priority as this is only for local dev
    this.routes = [];
    let childSwitch = React.Children.toArray(children)[0];
    //console.log("generating routes - switch", childSwitch, typeof childSwitch === Switch);
    if (childSwitch) {
      React.Children.toArray(childSwitch.props.children).map(child => {
        console.log('generating Route: ', child);
        //if (child.type.name === "Route") {  //if seems after building for CI, the child.type.name doesn't work
        this.routes.push({ ...child.props });
        //}
      });
    }
  }

  render() {
    const { dispatch, app, error, enrolment, eligibility } = this.props;
    let routes = this.routes;
    return (
      <div className="debug-panel">
        <marquee>
          <p>Developers Debug Panel</p>
        </marquee>
        <ul>
          {routes.slice(0, routes.length - 1).map((route, i) => {
            return (
              <li key={route.path + i}>
                <Link style={{ textTransform: 'capitalize' }} to={route.path}>
                  {route.path.replace(/^\/+/g, '')}
                </Link>
              </li>
            );
          })}
        </ul>
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({
              type: 'SET_AUTHENTICATED',
              authenticated: !app.authenticated
            });
          }}
          id="auth-debug"
          label="Authenticated"
          checked={app.authenticated}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({
              type: 'SET_INITIALISED',
              intialised: !app.initialised
            });
          }}
          id="auth-debug"
          label="Initialised"
          checked={app.initialised}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({ type: 'SET_ERROR', hasErrored: !error.hasErrored });
          }}
          id="error-debug"
          label="Error"
          checked={error.hasErrored}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({
              type: 'SET_ENROLLING',
              enrolling: !enrolment.enrolling
            });
          }}
          id="enrolling-debug"
          label="Enrolling"
          checked={enrolment.enrolling}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({ type: 'SET_ELIGIBLE', eligible: !eligibility.eligible });
          }}
          id="eligible-debug"
          label="Eligible"
          checked={eligibility.eligible}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({ type: 'SET_ENROLLED', enrolled: !enrolment.enrolled });
          }}
          id="enrolled-debug"
          label="Enrolled"
          checked={enrolment.enrolled}
        />
        <Checkbox
          type="switch"
          handleChange={() => {
            dispatch({
              type: 'SET_ENROLFAILED',
              enrolFailed: !enrolment.enrolFailed
            });
          }}
          id="enrolFailed-debug"
          label="enrolFailed"
          checked={enrolment.enrolFailed}
        />
        <span>
          Error Status Code: {app.errorStatusCode}
          {/* <input value={app.errorStatusCode} /> */}
        </span>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  error: state.error,
  enrolment: state.enrolment,
  eligibility: state.eligibility
});

export default connect(mapStateToProps)(DebugPanel);
