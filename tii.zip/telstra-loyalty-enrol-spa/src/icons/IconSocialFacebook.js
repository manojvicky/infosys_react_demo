import React from 'react';

export default function IconSocialFacebook() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 99.1 99.1"
      fill="currentColor"
    >
      <path d="M49.6 0C22.2 0 0 22.2 0 49.6s22.2 49.6 49.6 49.6C77 99.2 99.2 77 99.2 49.6S76.9 0 49.6 0zm14.5 30.8h-5.3c-4.1 0-4.9 2-4.9 4.9v6.4h9.9l-1.3 10h-8.6v25.6H43.6V52.1H35v-10h8.6v-7.4c0-8.5 5.2-13.2 12.8-13.2 2.6 0 5.1.1 7.7.4v8.9z" />
    </svg>
  );
}
