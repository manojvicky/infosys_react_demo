import React from 'react';

export default function IconTick() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="32"
      height="32"
      fill="currentColor"
      strokeWidth="1"
      stroke="currentColor"
    >
      <path
        fill="currentColor"
        d="M27.067 7.867c-.267-.267-.6-.267-.867 0l-14.933 15-5.533-5.533c-.267-.267-.6-.267-.867 0s-.267.6 0 .867l5.933 5.933c.133.133.267.2.4.2s.333-.067.4-.2L27 8.734c.333-.267.333-.6.067-.867z"
      />
    </svg>
  );
}
