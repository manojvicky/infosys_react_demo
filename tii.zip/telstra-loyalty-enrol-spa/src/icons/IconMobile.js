import React from 'react';

export default function IconMobile() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      width="32"
      height="32"
    >
      <path d="M17 0H7C5.9 0 5 .9 5 2v20c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V2c0-1.1-.9-2-2-2zm.8 22c0 .4-.4.8-.8.8H7c-.4 0-.8-.4-.8-.8V2c0-.4.4-.8.8-.8h10c.4 0 .8.4.8.8v20z" />
      <path d="M13.4 2h-2.8c-.3 0-.6.3-.6.6s.3.6.6.6h2.8c.3 0 .6-.3.6-.6s-.3-.6-.6-.6z" />
      <circle cx="12" cy="21" r="1" />
    </svg>
  );
}
