import React from 'react';

export default function IconLoadingSpinner() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 120 120"
      width="120"
      height="120"
      preserveAspectRatio="xMidYMid meet"
      style={{
        width: '100%',
        height: '100%',
        transform: 'translate3d(0px, 0px, 0px)'
      }}
    >
      <defs>
        <clipPath id="animationMask_BC5kBivW8t">
          <rect width="120" height="120" x="0" y="0" />
        </clipPath>
        <linearGradient
          id="gr_Q7b4XRAg9u"
          spreadMethod="pad"
          gradientUnits="userSpaceOnUse"
          x1="-0.765999972820282"
          y1="-22.040000915527344"
          x2="22.468000411987305"
          y2="1.843000054359436"
        >
          <stop offset="0%" stopColor="rgb(91,192,242)" />
          <stop offset="17%" stopColor="rgb(145,174,222)" />
          <stop offset="35%" stopColor="rgb(198,157,201)" />
          <stop offset="68%" stopColor="rgb(167,139,192)" />
          <stop offset="100%" stopColor="rgb(135,121,183)" />
        </linearGradient>
        <linearGradient
          id="gr_rF2gzNDhqi"
          spreadMethod="pad"
          gradientUnits="userSpaceOnUse"
          x1="-18.78581428527832"
          y1="-5.626023292541504"
          x2="5.062746047973633"
          y2="-21.749956130981445"
        >
          <stop offset="18%" stopColor="rgb(135,151,182)" />
          <stop offset="35%" stopColor="rgb(151,144,186)" />
          <stop offset="52%" stopColor="rgb(167,136,190)" />
          <stop offset="76%" stopColor="rgb(202,88,190)" />
          <stop offset="100%" stopColor="rgb(237,40,190)" />
        </linearGradient>
        <mask id="mk_8SuNUkT29t">
          <path
            stroke="url(#op_Yy45rdwQxu)"
            strokeWidth="4"
            d=" M-22.68600082397461,-7.8460001945495605 C-19.43199920654297,-17.243999481201172 -10.498000144958496,-24 0,-24 C0,-24 0,-24 0,-24 C9.376999855041504,-24 17.506000518798828,-18.610000610351562 21.45400047302246,-10.76099967956543"
          />
        </mask>
        <linearGradient
          id="op_Yy45rdwQxu"
          spreadMethod="pad"
          gradientUnits="userSpaceOnUse"
          x1="-18.78581428527832"
          y1="-5.626023292541504"
          x2="5.062746047973633"
          y2="-21.749956130981445"
        >
          <stop stopColor="rgb(255,255,255)" offset="0%" stopOpacity="0" />
          <stop stopColor="rgb(255,255,255)" offset="12%" stopOpacity="0.5" />
          <stop stopColor="rgb(255,255,255)" offset="26%" stopOpacity="1" />
          <stop stopColor="rgb(255,255,255)" offset="63%" stopOpacity="1" />
          <stop stopColor="rgb(255,255,255)" offset="100%" stopOpacity="1" />
        </linearGradient>
      </defs>
      <g clipPath="url(#animationMask_BC5kBivW8t)">
        <g
          transform="matrix(1,0,0,1,0,0)"
          opacity="1"
          style={{ display: 'block' }}
        >
          <rect width="120" height="120" fill="#ffffff" />
        </g>
        <g
          transform="matrix(0.7071067690849304,-0.7071067690849304,0.7071067690849304,0.7071067690849304,64.35295104980469,59.29289245605469)"
          opacity="1"
          style={{ display: 'block' }}
        >
          <g opacity="1" transform="matrix(1,0,0,1,0,0)">
            <path
              stroke="url(#gr_Q7b4XRAg9u)"
              strokeLinecap="butt"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
              strokeOpacity="1"
              strokeWidth="2"
              d="M0 0"
            />
          </g>
          <g
            opacity="1"
            transform="matrix(1,0,0,1,-3.563999891281128,-2.38700008392334)"
          >
            <path fill="rgb(255,0,0)" fillOpacity="1" d="M0 0" />
            <path
              strokeLinecap="butt"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
              stroke="rgb(64,192,199)"
              strokeOpacity="1"
              strokeWidth="0"
              d=" M-22.68600082397461,-7.8460001945495605 C-19.43199920654297,-17.243999481201172 -10.498000144958496,-24 0,-24 C0,-24 0,-24 0,-24 C9.376999855041504,-24 17.506000518798828,-18.610000610351562 21.45400047302246,-10.76099967956543"
            />
            <path
              stroke="url(#gr_rF2gzNDhqi)"
              mask="url(#mk_8SuNUkT29t)"
              strokeLinecap="butt"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
              strokeOpacity="1"
              strokeWidth="4"
              d="M0 0 M-22.68600082397461,-7.8460001945495605 C-19.43199920654297,-17.243999481201172 -10.498000144958496,-24 0,-24 C0,-24 0,-24 0,-24 C9.376999855041504,-24 17.506000518798828,-18.610000610351562 21.45400047302246,-10.76099967956543"
            />
          </g>
        </g>
        <g style={{ display: 'none' }}>
          <g>
            <path
              strokeLinecap="butt"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
            />
          </g>
        </g>
        <g style={{ display: 'none' }}>
          <g>
            <path />
            <path
              strokeLinecap="round"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
            />
          </g>
        </g>
        <g style={{ display: 'none' }}>
          <g>
            <path />
            <path
              strokeLinecap="round"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
            />
          </g>
        </g>
        <g style={{ display: 'none' }}>
          <g>
            <path />
            <path
              strokeLinecap="round"
              strokeLinejoin="miter"
              fillOpacity="0"
              strokeMiterlimit="4"
            />
          </g>
        </g>
      </g>
    </svg>
  );
}
