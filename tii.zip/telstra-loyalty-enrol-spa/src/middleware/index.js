import each from 'lodash/each';
import keys from 'lodash/keys';
import intersection from 'lodash/intersection';
import extend from 'lodash/extend';

const files = {};

// Loop through the imported constant files and check for duplicates
let middlewaresMutable = {};

each(keys(files), filename => {
  const file = files[filename];
  const duplicates = intersection(keys(middlewaresMutable), keys(file));

  each(duplicates, duplicate => {
    console.warn(
      'Duplicate middlewares key found. Please fix this immediately.',
      { filename, duplicate }
    ); // eslint-disable-line no-console
  });

  middlewaresMutable = extend(middlewaresMutable, file);
});

const middlewares = middlewaresMutable;

export default middlewares;
