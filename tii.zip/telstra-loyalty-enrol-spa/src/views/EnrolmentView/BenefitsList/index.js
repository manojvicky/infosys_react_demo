import BenefitsList from './BenefitsList';

export default BenefitsList;
