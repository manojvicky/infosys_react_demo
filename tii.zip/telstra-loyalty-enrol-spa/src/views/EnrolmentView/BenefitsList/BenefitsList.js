import React, { Fragment } from 'react';
// Image Assets
import enjoybenefits from 'assets/images/enrol/enjoybenefits.png';
import redeempoints from 'assets/images/enrol/redeempoints.png';
import earnpoints from 'assets/images/enrol/earnpoints.png';

import './BenefitsList.scss';

const BenefitsList = () => {
  return (
    <Fragment>
      <h1>You&#39;re almost there</h1>
      <div className="clear-div-xs" />

      <ul className="enrol-benefit-list">
        <li>
          <img src={earnpoints} alt="Earn points" />
          <p>
            Earn 10 Telstra Plus points per eligible dollar every time you pay
            your bill or recharge your prepaid service.
          </p>
        </li>
        <li>
          <img src={enjoybenefits} alt="Enjoy benefits" />
          <p>
            Enjoy exciting member benefits like discounted tickets and
            entertainment extras on us.
          </p>
        </li>
        <li>
          <img src={redeempoints} alt="Redeem points" />
          <p>
            Stay tuned for details on how you can turn your points into rewards
            at the Rewards Store.
          </p>
        </li>
      </ul>
    </Fragment>
  );
};

export default BenefitsList;
