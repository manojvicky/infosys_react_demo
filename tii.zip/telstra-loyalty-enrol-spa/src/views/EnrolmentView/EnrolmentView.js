import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import Checkbox from 'components/Checkbox';
import PropTypes from 'prop-types';

import * as Analytics from 'utils/analytics';

import alertSvg from 'assets/images/enrol/alert.svg';

import BenefitsList from './BenefitsList';
import './EnrolmentView.scss';

class EnrolmentView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      termsAndConditionsChecked: false,
      formError: false
    };
  }

  componentDidMount() {
    Analytics.setPageName('Enrolment Landing Page');
  }

  handleCheckboxChange = event => {
    this.setState({
      formError: false,
      termsAndConditionsChecked: event.checked
    });
  };

  handleDisbledBtnClick = e => {
    e.preventDefault();
    const { termsAndConditionsChecked } = this.state;
    if (!termsAndConditionsChecked) {
      this.setState({
        formError: true
      });
    } else {
      this.props.handleEnrolment();
    }
  };

  render() {
    const { termsAndConditionsChecked, formError } = this.state;

    return (
      <div className="page container">
        <div className="row">
          <div className="enrol-container">
            <BenefitsList />
            <div className="clear-div-xl" />
            <form onSubmit={() => this.props.handleEnrolment()}>
              {formError && (
                <div className="error-msg">{formError.message}</div>
              )}
              <div className="enrol-tnc-field-wrap">
                <div className="checkbox-content">
                  <Checkbox
                    type="tick"
                    handleChange={this.handleCheckboxChange}
                    id="rewards-enrol-tnc"
                  />

                  <label className="tnc-content" htmlFor="rewards-enrol-tnc">
                    {'I have read and accepted the '}
                    <a
                      href="https://www.telstra.com.au/plus/terms-and-conditions"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Terms & Conditions
                    </a>
                    {' and '}
                    <a
                      href="https://www.telstra.com.au/privacy/privacy-statement"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Privacy Statement
                    </a>
                    {`. I agree to receive marketing communications from Telstra.`}
                  </label>
                </div>
              </div>
              {formError && (
                <p className="enrol-submit-error">
                  <img src={alertSvg} alt="An alert icon" />
                  Please select the checkbox to agree.
                </p>
              )}
              <div className="clear-div-xs" />
              <button
                className={`enrol-submit-btn ${!termsAndConditionsChecked &&
                  'disabled'}`}
                type="submit"
                onClick={e => {
                  this.handleDisbledBtnClick(e);
                }}
              >
                Join Telstra Plus
              </button>
              <div className="clear-div-xs" />
            </form>
            <div className="clear-div-xl" />
          </div>
        </div>
      </div>
    );
  }
}

EnrolmentView.propTypes = {
  handleEnrolment: PropTypes.func.isRequired
};

export default withRouter(EnrolmentView);
