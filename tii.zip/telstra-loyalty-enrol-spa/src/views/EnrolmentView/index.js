import EnrolmemntView from './EnrolmentView';

export default EnrolmemntView;
