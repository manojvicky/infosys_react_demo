import TechnicalIssue from './TechnicalIssue';

export default TechnicalIssue;
