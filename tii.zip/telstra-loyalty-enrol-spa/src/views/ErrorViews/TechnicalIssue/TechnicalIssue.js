import React, { Fragment, Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter, Link } from 'react-router-dom';
import { connect } from 'react-redux';
import _ from 'lodash';

import * as Analytics from 'utils/analytics';
import AppLog from 'utils/AppLog';

import AlertPNG from 'assets/images/Alert.png';
import IconArrow from 'icons/IconArrow';
import './TechnicalIssue.scss';

import * as ERRCODES from 'constants/errorCodes.js';
import * as ERRMSGS from 'constants/errorMessages.js';

import {
  SET_ELIGIBLE,
  SET_ENROLLED,
  SET_ENROLLING,
  SET_ERROR,
  SET_ENROLFAILED
} from 'constants/actions';

import registerApi from 'api/register';

const { REACT_APP_PLUS_HOME_URL } = process.env;

class TechnicalIssue extends Component {
  constructor() {
    super();
    this.log = new AppLog('TechnicalIssue');
  }

  handleRetryEnrolment = () => {
    const { dispatch, history } = this.props;
    dispatch({ type: SET_ENROLLING, enrolling: true });
    const token = sessionStorage.getItem('accessToken');
    this.log.debug('accessToken for enrolment: ', token);

    registerApi(token)
      .then(response => {
        this.log.debug('Register Resp:', response);

        // Connection timed-out
        if (response.code === ERRCODES.ERR_CONNABORTED) {
          this.log.debug('Request cancelled');
          dispatch({
            type: SET_ERROR,
            hasErrored: true,
            errorMessage: ERRMSGS.REGISTRATIONERROR
          });
          history.push('/error');
          return;
        }

        // Server Returned a 200 Response
        if (_.has(response, 'data')) {
          this.log.debug('Successful Enrolment Response');
          dispatch({ type: SET_ENROLLED, enrolled: true });

          Analytics.setPageName('Member Landing Page');
          Analytics.addEvent('loyaltyEnrolComplete');

          history.push('/benefits');
        }
      })
      .then(() => {
        this.log.debug('Final enrolment THEN');
        dispatch({ type: SET_ENROLLING, enrolling: false });
      })
      .catch(error => {
        this.log.debug('Caught error is: ', error);

        if (typeof error.response !== 'undefined') {
          this.log.debug('enrolment response', error);

          const { code } = error.response.data;

          this.log.debug('Server error', code);

          if (code === ERRCODES.ERR_LA_CAC) {
            // Limited Authority && No Active Service Accounts
            dispatch({
              type: SET_ELIGIBLE,
              eligible: false,
              getDetails: error.response.data
            });
            dispatch({ type: SET_ENROLLED, enrolled: false });
            dispatch({
              type: SET_ERROR,
              hasErrored: true,
              errorStatusCode: code
            });

            history.push('/not-eligible');
          } else if (code === ERRCODES.ERR_ALREADY_ENROLLED) {
            // Already Enrolled
            // Setting Enrolled here will push the error screen with an already enrolled messaged
            // from the API and a Link to go to the Plus Homepage

            dispatch({ type: SET_ENROLLED, enrolled: true });
            dispatch({
              type: SET_ERROR,
              hasErrored: true,
              errorMessage: ERRMSGS.ALREADYENROLLED
            });
            // Analytics.setPageName('Already Enrolled Error');
            history.push('/error');
          } else {
            // Setting enrolFailed to true will display the error screen with a retry button
            // To retry the enrolment call

            dispatch({
              type: SET_ERROR,
              hasErrored: true,
              errorMessage: ERRMSGS.REGISTRATIONERROR
            });

            dispatch({ type: SET_ENROLFAILED, enrolFailed: true });
            Analytics.setPageName('Enrolment Error');
            history.push('/error');
          }
        } else {
          // Setting enrolFailed to true will display the error screen with a retry button
          // To retry the enrolment call

          dispatch({
            type: SET_ERROR,
            hasErrored: true,
            errorMessage: ERRMSGS.REGISTRATIONERROR
          });

          dispatch({ type: SET_ENROLFAILED, enrolFailed: true });
          Analytics.setPageName('Enrolment Error');
          history.push('/error');
        }
      });
  };

  renderErrorMessage = () => {
    const {
      enrolment: { enrolled },
      error: { errorMessage }
    } = this.props;

    if (errorMessage) {
      return errorMessage;
    }
    if (enrolled) {
      return ERRMSGS.ALREADYENROLLED;
    }
    return ERRMSGS.DEFAULTMESSAGE;
  };

  render() {
    const {
      enrolment: { enrolled, enrolFailed }
    } = this.props;
    return (
      <div className="container">
        <div className="technical-issue">
          <div className="clear-div-m" />
          <div className="icon-contain">
            <img src={AlertPNG} alt="An error icon" />
          </div>
          <div className="clear-div-m" />
          <h1 className="sub-heading">Sorry something went wrong</h1>
          <div className="clear-div-m" />
          <p>{this.renderErrorMessage()}</p>
          <div className="clear-div-s" />

          {enrolled && (
            <Fragment>
              <div className="clear-div-m" />
              <Link
                role="button"
                aria-pressed="false"
                className="primary-cta-18 go-to-thanks"
                to="/benefits"
              >
                Go to Telstra Plus <IconArrow />
              </Link>
            </Fragment>
          )}

          {enrolFailed && !enrolled && (
            <Fragment>
              <div className="clear-div-s" />
              <button
                onClick={this.handleRetryEnrolment}
                className="enrol-submit-btn"
                type="button"
              >
                Try again
              </button>
              <div className="clear-div-m" />
              <a
                role="button"
                aria-pressed="false"
                className="primary-cta-18 enrol-learn-more-btn"
                href={REACT_APP_PLUS_HOME_URL}
              >
                Cancel without joining
              </a>
            </Fragment>
          )}

          <div className="clear-div-xl" />
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  error: state.error
});

TechnicalIssue.propTypes = {
  dispatch: PropTypes.func.isRequired,
  history: PropTypes.object.isRequired,
  error: PropTypes.object,
  enrolment: PropTypes.object
};

TechnicalIssue.defaultProps = {
  error: {},
  enrolment: {}
};

export default withRouter(connect(mapStateToProps)(TechnicalIssue));
