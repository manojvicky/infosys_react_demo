import React, {Component} from 'react';
import BenefitsHeader from 'assets/images/BenefitsHeader@2x.jpg';
import IconChevron from 'icons/IconChevron';
import VerticalTabs from 'components/VerticalTabs';
import { Link } from 'react-router-dom';
import './ViewsInfo.scss';

export default class InfoSupportView extends Component {

    render(){
        return (<div className="info-section">
             <div
                style={{
                    backgroundImage: `url(${BenefitsHeader})`
                }}
                className="hero-banner"
                >IMAGE</div>

            <div className="body-copy container">
                <div className="breadcrumbs">
                    <span className="chevron left">
                    <IconChevron />
                    </span>
                    <Link to="/benefits">Back</Link>
                </div>
            
                <h2>
                One-off basic tech support
                </h2>
                <p>Get one-off basic tech support worth $30 online or over the phone tech support by Telstra Platinum.</p>
                <p className="subtitle">How it works?</p>
                <p>Get expert help with devices, home tech and software including setting up email, connecting your 
                    printer and social media tutorials.</p>
                <p>Your one-off tech support by Telstra Platinum benefit can be used once per membership year.</p>

TODO - update the tab contents
                <VerticalTabs
                
                tabs={[{
                    title: 'Entertainment extras',
                    description: `<p><strong>Telstra TV Box Office credit </strong><br><br>
                            Requires an active Telstra Box Office account. Telstra TV Box Office credit must be activated by 31 July 2019. Credit expires 12 months from date of activation. For use in Australia. 
                    <br><br>Telstra TV Box Office is available on Telstra TV, as well as on iOS and Android mobile devices, PC and Mac (via your web browser), and supported Smart TVs. Video content for most Telstra home broadband and Telstra Internet Access plans is unmetered except for hourly plans, including dial up and satellite plans, international roaming and use of a Telstra Air Wi-Fi hotspot outside your home 
                            </p>`
                }]}
                />
            </div>


          
          <div className="clear-div-xl" />
        

        </div>);
    };


}