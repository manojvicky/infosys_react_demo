import LimitedPermissions from './LimitedPermissions';

export default LimitedPermissions;
