import React, { Fragment } from 'react';

import IconArrow from 'icons/IconArrow';

import './LimitedPermissions.scss';

const LimitedPermissions = () => (
  <Fragment>
    <div className="limited-permissions">
      <h1 className="page-heading">
        Please ask your account holder to join Telstra Plus
      </h1>
      <div className="clear-div-l" />
      <p>
        Ask your account holder to join, then you can come back and set up your
        Telstra Plus membership.
      </p>
      <div className="clear-div-s" />
      <a
        role="button"
        aria-pressed="false"
        className="primary-cta-18"
        href="https://www.telstra.com.au/plus#who-can-join"
      >
        More about permissions <IconArrow />
      </a>
      <div className="clear-div-xl" />
    </div>
  </Fragment>
);

export default LimitedPermissions;
