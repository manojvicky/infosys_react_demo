import NotForBusinessCustomers from './NotForBusinessCustomers';

export default NotForBusinessCustomers;
