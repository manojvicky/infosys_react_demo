import React, { Fragment } from 'react';
import './NotForBusinessCustomers.scss';

const { REACT_APP_PLUS_HOME_URL } = process.env;

const NotForBusinessCustomers = () => (
  <Fragment>
    <div className="page container">
      <div className="not-for-business">
        <h1 className="page-heading">
          Telstra Plus is not available for business customers
        </h1>
        <div className="clear-div-s" />
        <p>
          You can join&nbsp;
          <a href={REACT_APP_PLUS_HOME_URL}>Telstra Plus</a>
          &nbsp;with a personal account. Simply sign out and join with your
          personal Telstra ID.
        </p>
        <div className="clear-div-xxs" />
        <p>
          You can continue to enjoy&nbsp;
          <a href="https://www.telstra.com.au/thanks?ti=14052019:tplusspa:thanks:banner">
            Telstra Thanks®
          </a>
          &nbsp;for a while longer.
        </p>
        <div className="clear-div-xl" />
      </div>
    </div>
  </Fragment>
);

export default NotForBusinessCustomers;
