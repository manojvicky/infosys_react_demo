import React, { Fragment } from 'react';

import './NoActiveServices.scss';

import VerticalTabs from 'components/VerticalTabs';

const NoActiveServices = () => (
  <Fragment>
    <div className="no-active-services">
      <h1 className="page-heading">
        {`We're unable to find any active services`}
      </h1>
      <div className="clear-div-l" />
      <p>To join Telstra Plus, you need an eligible Telstra service.</p>
      <div className="clear-div-m" />
      <VerticalTabs
        tabs={[
          {
            title: 'Have you recently ordered a new service?',
            description: `If you have recently ordered a new service, please allow up to 24 hours for your new service to become active and try again.`
          },
          {
            title: 'Have you recently cancelled your service?',
            description:
              'You need an active, eligible Telstra service and a Telstra ID to join Telstra Plus.'
          }
        ]}
      />
      <div className="clear-div-xxxl" />
    </div>
  </Fragment>
);

export default NoActiveServices;
