import PointsView from './PointsView';

export default PointsView;
