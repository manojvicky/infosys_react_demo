import NoPointsView from './NoPointsView';

export default NoPointsView;
