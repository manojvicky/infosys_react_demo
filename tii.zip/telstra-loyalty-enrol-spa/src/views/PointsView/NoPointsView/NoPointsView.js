import React from 'react';

import * as ERRMSGS from 'constants/errorMessages.js';

import NoPointsImage from 'assets/images/NoPointsImg.png';

import './NoPointsView.scss';

const NoPointsView = () => (
  <div className="no-points">
    <div className="clear-div-m" />
    <h2 className="sub-heading">{ERRMSGS.POINTLESSHEADING}</h2>
    <p>{ERRMSGS.POINTLESSCOPY}</p>
    <img src={NoPointsImage} alt="Cactus and tumbleweed illustration" />
    <div className="clear-div-xl" />
  </div>
);

export default NoPointsView;
