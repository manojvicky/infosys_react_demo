import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter, Link } from 'react-router-dom';

import AppLog from 'utils/AppLog';
import * as Analytics from 'utils/analytics';

import IconChevron from 'icons/IconChevron';
import PointsTable from '../PointsTable';

import './PointsHistoryView.scss';

class PointsHistoryView extends Component {
  constructor() {
    super();
    this.log = new AppLog('PointsHistoryView');
  }

  componentDidMount() {
    this.log.debug('Points view mounted');
    Analytics.setPageName('View Points History');
  }

  render() {
    const {
      pointsHistory: { transactions },
      activeAccount
    } = this.props;

    const pointsCommad = parseInt(activeAccount.pointsValue, 10).toLocaleString(
      navigator.language,
      {
        minimumFractionDigits: 0
      }
    );

    let parsedPoints = '--';
    if (!isNaN(parseInt(activeAccount.pointsValue, 10)))
      parsedPoints = pointsCommad;

    const transactionCount = transactions.length;

    return (
      <div>
        <div className="points-history-page container">
          <div className="points-breadcrumbs">
            <span className="chevron left">
              <IconChevron />
            </span>
            <Link to="/points">Back to Points</Link>
          </div>
          <div className="points-container">
            <p className="title">Points</p>
            <p className="points-value">{parsedPoints}</p>
            <p className="callout">
              Your points may take approx. 7 business days to appear in your
              account
            </p>
          </div>
          <div className="activity-container">
            <h3>Your activity</h3>
            <p>Showing {transactionCount} most recent transactions</p>
            <PointsTable transactions={transactions} />
          </div>
          <div className="clear-div-xl" />
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  activeAccount: state.activeAccount,
  totalPoints: state.points.totalPoints,
  pointsHistory: state.pointsHistory
});

export default withRouter(connect(mapStateToProps)(PointsHistoryView));

PointsHistoryView.propTypes = {
  pointsHistory: PropTypes.shape({
    transactions: PropTypes.object
  }),
  activeAccount: PropTypes.shape({})
};

PointsHistoryView.defaultProps = {
  activeAccount: {
    pointsValue: '--'
  },
  pointsHistory: {
    transactions: {}
  }
};
