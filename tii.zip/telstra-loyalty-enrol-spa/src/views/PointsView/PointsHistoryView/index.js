import PointsHistoryView from './PointsHistoryView';

export default PointsHistoryView;
