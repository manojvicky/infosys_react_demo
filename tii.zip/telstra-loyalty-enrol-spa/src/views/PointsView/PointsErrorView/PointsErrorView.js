import React, { Fragment, Component } from 'react';
import AlertPNG from 'assets/images/Alert.png';

import * as ERRMSGS from 'constants/errorMessages.js';

import './PointsErrorView.scss';

class PointsErrorView extends Component {
  handleRetryGetPoints = () => {
    // We'll put a call to getPoints here when we can
  };

  render() {
    return (
      <div className="points-error">
        <div className="icon-contain">
          <img src={AlertPNG} alt="An error icon" />
        </div>
        <div className="clear-div-m" />
        <h1 className="sub-heading">{ERRMSGS.POINTSERRORHEADING}</h1>
        <div className="clear-div-m" />
        <p>{ERRMSGS.POINTSERRORCOPY}</p>
        <div className="clear-div-s" />
        <Fragment>
          <div className="clear-div-s" />
          <button
            onClick={this.handleRetryGetPoints}
            className="enrol-submit-btn"
            type="button"
          >
            Try again
          </button>
          <div className="clear-div-m" />
        </Fragment>
        <div className="clear-div-xl" />
      </div>
    );
  }
}

export default PointsErrorView;
