import PointsErrorView from './PointsErrorView';

export default PointsErrorView;
