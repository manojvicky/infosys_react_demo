import PointsTable from './PointsTable';

export default PointsTable;
