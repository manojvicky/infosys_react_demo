import React from 'react';
import PropTypes from 'prop-types';
import uuid from 'uuid/v4';

import './PointsTable.scss';

const months = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec'
];

class PointsTable extends React.Component {
  formatDate = date => {
    const d = date.split(' ')[0].split('-');
    return `${parseInt(d[2], 10)} ${months[parseInt(d[1] - 1, 10)]} ${d[0]}`;
  };

  renderRowItems = () => {
    const { transactions } = this.props;

    return transactions.map(item => (
      <tr key={uuid()}>
        <td>
          <div className="info">
            <span className="item-date">
              {this.formatDate(item.transactionDate)}
            </span>
            <span className="item-label">{item.transactionDescription}</span>
            {item.transactionAmount !== 0 &&
              `- $${Math.abs(item.transactionAmount)}`}
          </div>
        </td>
        <td>
          {parseInt(item.pointsEarned, 10).toLocaleString(navigator.language, {
            minimumFractionDigits: 0
          })}
        </td>
      </tr>
    ));
  };

  render() {
    return (
      <table className="points-history-table">
        <thead>
          <tr>
            <th>Description</th>
            <th>Points</th>
          </tr>
        </thead>
        <tbody>{this.renderRowItems()}</tbody>
      </table>
    );
  }
}

export default PointsTable;

PointsTable.propTypes = {
  transactions: PropTypes.array
};

PointsTable.defaultProps = {
  transactions: []
};
