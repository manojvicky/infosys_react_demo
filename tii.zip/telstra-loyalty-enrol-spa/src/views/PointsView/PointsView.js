import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter, Link } from 'react-router-dom';
import _ from 'lodash';

import AppLog from 'utils/AppLog';
import * as Analytics from 'utils/analytics';

import VerticalTabs from 'components/VerticalTabs';
import IconArrow from 'icons/IconArrow';
import PromoGroup from 'components/PromoGroup';
import BigPromoTile from 'components/BigPromoTile';
import MiniPromoTile from 'components/MiniPromoTile';

// import RewardsStoreImg from 'assets/images/Google_Mini_4x3-Store-Desktop@2x.jpg';
import BonusPointsImage from 'assets/images/Samsung-S10-5G@2x.jpg';
import PointsErrorView from 'views/PointsView/PointsErrorView';
import NoPointsView from 'views/PointsView/NoPointsView';
import SpinnerGif from 'assets/images/Spinner.gif';
import PointsTable from './PointsTable';

import { POINTSFAQS, POINTSTYNTK, rewardsStorePromos } from './PointsContent';

import './PointsView.scss';

const { REACT_APP_PLUS_HOME_URL } = process.env;

class PointsView extends Component {
  constructor() {
    super();
    this.log = new AppLog('PointsView');
  }

  componentDidMount() {
    this.log.debug('Points view mounted');
    Analytics.setPageName('View Points');
  }

  renderRewardsTiles = () => {
    const miniPromos = rewardsStorePromos.map(promo => (
      // id can be created from another field if unique id doesnt exist
      <MiniPromoTile
        key={promo.id}
        imagePath={promo.imagePath}
        imageAltText={promo.imageAltText}
        promoSmallTitle={promo.promoSmallTitle}
        promoTitle={promo.promoTitle}
        promoCopy={promo.promoCopy}
      />
    ));
    return miniPromos;
  };

  renderPointsView = () => {
    const {
      points: { failure },
      totalPoints,
      pointsHistory: { transactions, pending },
      activeAccount
    } = this.props;

    const pointsTableItems = transactions.slice(0, 5);
    const historyCount = pointsTableItems.length;

    const pointsCommad = parseInt(
      activeAccount.pointsValue || totalPoints,
      10
    ).toLocaleString(navigator.language, {
      minimumFractionDigits: 0
    });

    let parsedPoints = '--';
    if (!isNaN(parseInt(activeAccount.pointsValue || totalPoints, 10)))
      parsedPoints = pointsCommad;

    if (failure) {
      return <PointsErrorView />;
    }

    this.log.debug('Points amount: ', activeAccount.pointsValue);

    if (
      (activeAccount.pointsValue === '--' || activeAccount.pointsValue === 0) &&
      !_.has(transactions, 'pointsHistory')
    ) {
      return <NoPointsView />;
    }
    const hasTransactions = !_.has(transactions, 'pointsHistory');
    const pointsActivityFragment =
      (activeAccount.pointsValue === '--' || activeAccount.pointsValue === 0) &&
      hasTransactions ? (
        <Fragment>
          <p>
            You have no points at the moment. You will earn 10 points per dollar
            on your next eligible bill payment or recharge. Points can take up
            to 4 business days to appear.
          </p>
          <span className="primary-cta-18 disabled">
            View your point activity <IconArrow />
          </span>
        </Fragment>
      ) : (
        <Fragment>
          <p>Showing {historyCount} most recent transactions</p>
          {pending ? (
            <p>Loading...</p>
          ) : (
            <PointsTable transactions={pointsTableItems} />
          )}
          <div className="view-history-container">
            <div className="clear-div-m" />
            <Link
              role="button"
              aria-pressed="false"
              className="primary-cta-18 go-to-thanks"
              to="/points/history"
            >
              View your point activity <IconArrow />
            </Link>
          </div>
        </Fragment>
      );

    return (
      <div className="points-container">
        <p className="title">Points</p>
        <p className="points-value">{parsedPoints}</p>
        <p className="callout">
          Your points may take approx. 7 business days to appear in your account
        </p>
        <h3 className="title">Your activity</h3>

        {pointsActivityFragment}
      </div>
    );
  };

  render() {
    const {
      mobileHeading,
      points: { pending }
    } = this.props;
    return (
      <div>
        <div className="points-page container">
          <div className="points-page-wrapper">
            <h2 className="mobile-heading">{mobileHeading}</h2>
            {pending ? (
              <div className="loading-points-container">
                <img src={SpinnerGif} alt="Loading" />
                <p>Loading points activity</p>
              </div>
            ) : (
              <div className="activity-container">
                {this.renderPointsView()}
              </div>
            )}
            <h2>Boost your points balance</h2>
            <div className="bonus-points-promo">
              <BigPromoTile
                leftImage
                icon="Extras"
                iconTitle="Bonus 100,000 Telstra Plus points"
                imagePath={BonusPointsImage}
                imageAltText="5G Samsung Phone"
                promoTitle="Experience Australia’s first 5G phone"
                promoCopy="The new Samsung Galaxy S10 5G lets you stream your favourite entertainment fast with Telstra 5G now available in selected areas. Get 100,000 bonus points when you buy on a Telstra plan by 24 June."
                promoSubCopy="Excludes upgrades from S10+ 4G and outright purchases."
                buttonText="Learn more"
                url="https://www.telstra.com.au/mobile-phones/mobiles-on-a-plan/samsung/samsung-galaxy-s10-5g"
              />
            </div>
            {/* <BigPromoTile
              icon={null}
              iconTitle={null}
              imagePath={RewardsStoreImg}
              imageAltText="New reward store coming soon"
              promoTitle="Rewards Store coming soon"
              promoCopy="We’re currently preparing our Rewards Store where you’ll be able to use your points to put towards devices, accessories and limited time offers. The more points you earn, the more you’ll be able to redeem. We’ll share more details about the Rewards Store, Points + Pay and how it all works soon. Check out some examples of what’s coming."
            /> */}
            <div className="rewards-store-tiles">
              <PromoGroup
                heading="Get ready for the Rewards Store coming soon"
                copy="We’re currently preparing our Rewards Store where you’ll be able to use your points to put towards devices, accessories and limited time offers. The more points you earn, the more you’ll be able to redeem. We’ll share more details about the Rewards Store, Points + Pay and how it all works soon. Here’s an example of what’s coming."
              >
                {this.renderRewardsTiles()}
              </PromoGroup>
            </div>
            <div className="clear-div-xxxl hidden-xs" />
            <div className="faq-container">
              <VerticalTabs title="FAQs" tabs={POINTSFAQS} />
              <div className="clear-div-l" />
              <a
                target="_blank"
                rel="noopener noreferrer"
                role="button"
                aria-pressed="false"
                className="primary-cta-18 see-all-btn"
                href={`${REACT_APP_PLUS_HOME_URL}/frequently-asked-questions`}
              >
                See all Telstra Plus FAQs <IconArrow />
              </a>
              <div className="clear-div-l" />
              <VerticalTabs
                title="Things you need to know"
                tabs={POINTSTYNTK}
              />

              <div className="clear-div-xxxl " />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  activeAccount: state.activeAccount,
  points: state.points,
  enrolment: state.enrolment,
  eligibility: state.eligibility,
  totalPoints: state.points.totalPoints,
  pointsHistory: state.pointsHistory
});

export default withRouter(connect(mapStateToProps)(PointsView));

PointsView.propTypes = {
  mobileHeading: PropTypes.string,
  totalPoints: PropTypes.string,
  pointsHistory: PropTypes.shape({
    transactions: PropTypes.array
  }),
  points: PropTypes.shape({
    failure: PropTypes.bool
  }),
  activeAccount: PropTypes.shape({})
};

PointsView.defaultProps = {
  activeAccount: {
    pointsValue: '--'
  },
  mobileHeading: '',
  totalPoints: '--',
  pointsHistory: {
    transactions: {}
  },
  points: {
    failure: false
  }
};
