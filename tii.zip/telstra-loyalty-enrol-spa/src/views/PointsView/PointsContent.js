import PromoTile1 from 'assets/images/Image_Device_Telstra_TV@2x.jpg';
import PromoTile2 from 'assets/images/NETGEAR_Nighthawk_2_4x3@2x.jpg';
import PromoTile3 from 'assets/images/Google_Mini_4x3.jpg';

export const rewardsStorePromos = [
  {
    id: 1,
    imagePath: PromoTile1,
    imageAltText: 'PromoImageTest',
    promoSmallTitle: 'Telstra',
    promoTitle: 'Telstra TV3',
    promoCopy: '40,000 Points + $115'
  },
  {
    id: 2,
    imagePath: PromoTile2,
    imageAltText: 'PromoImageTest',
    promoSmallTitle: 'Telstra',
    promoTitle: 'Netgear Nighthawk® M2',
    promoCopy: `15,000 Points + $215 Hot Offer – Limited Time`
  },
  {
    id: 3,
    imagePath: PromoTile3,
    imageAltText: 'PromoImageTest',
    promoSmallTitle: 'Google',
    promoTitle: 'Home Mini',
    promoCopy: '14,000 Points'
  }
];

export const POINTSFAQS = [
  {
    title: `How do I earn points?`,
    description: `<p>You will be rewarded with points based on your account spend every month. You will get 10 points for every $1 of eligible spend.  
    <br><br>
    From time to time we’ll let you know about other ways that you can earn points. 
    <br><br>
     
    <i>Note: some exclusions apply on your account spend such as outright purchases, credits, refunds and late payment fees. </i><br><br>      
    <a
    role="button"
    aria-pressed="false"
    className="primary-cta-18"
    target="_blank"
   rel="noopener noreferrer"
    href="http://www.telstra.com.au/plus/terms-and-conditions"
  >
    See Telstra Plus Terms and Conditions 
  </a></p>`
  },
  {
    title: `What is eligible spend?`,
    description: `<p>Eligible spend is defined as money spent on the following products and services:</p> 
    <ol>  
    <li>Paying your monthly bill for your Telstra services (after any discounts or refunds are applied)</li> 
      <li>Recharging your Telstra prepaid service </li>
      <li>Buying a mobile handset or hardware from Telstra through monthly instalment payments</li>    
      </ol>         
      <br>
      <p>
      Note: some exclusions apply on your account spend such as outright purchases, credits, refunds and late payment fees.  
      <br><br>
      <a
   role="button"
   aria-pressed="false"
   className="primary-cta-18"
   href="http://www.telstra.com.au/plus/terms-and-conditions"
   target="_blank"
   rel="noopener noreferrer"
 >
 See Telstra Plus Terms and Conditions 
 </a></p>`
  },
  {
    title: `What rewards are available to redeem? `,
    description: `<p>We’re currently preparing the Rewards Store, so stay tuned!</p> `
  }
];

export const POINTSTYNTK = [
  {
    title: `Telstra Plus Samsung Bonus Points Promotion`,
    description: `Open to Telstra Plus customers who purchase a Samsung S10 5G device on a compatible 24 month Telstra mobile plan by 24/6/19. Excludes upgrades from the S10+ 4G and outright purchases. Offer starts 9am AEST 28/5/19. 
    <br><br>
    <a
    role="button"
    aria-pressed="false"
    className="primary-cta-18"
    target="_blank"
   rel="noopener noreferrer"
    href="https://www.telstra.com.au/plus/terms-and-conditions-samsung-bonus-points-offer"
  >
    Read the full terms and conditions
  </a>`
  },
  {
    title: 'Telstra 5G coverage',
    description:
      'Telstra currently offers 5G in selected areas and is progressively rolling it out to other areas in non-5G coverage areas, you will automatically switch to our 4GX/4G or 3G check coverage at <a target="_blank" rel="noopener noreferrer" href="https://www.telstra.com/coverage">Telstra.com/coverage</a>'
  }
];
