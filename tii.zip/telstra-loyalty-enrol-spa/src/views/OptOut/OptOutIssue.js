import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';

import './OptOutIssue.scss';

import IconAlertError from 'icons/IconAlertError';
/* eslint-disable */

class OptOutIssue extends Component {
  render() {
    const { handleOptOut } = this.props;

    return (
      <Fragment>
        <div className="technical-issue">
          <div className="clear-div-m" />
          <span className="icon-contain">
            <IconAlertError />
          </span>
          <div className="clear-div-m" />
          <h2 className="sub-heading">Sorry, something went wrong</h2>
          <div className="clear-div-m" />

          <p>
            We weren't able to cancel your Telstra Plus membership at this time,
            please try again.
          </p>
          <div className="clear-div-s" />
          <button
            onClick={handleOptOut}
            className="enrol-submit-btn"
            type="button"
          >
            Try again
          </button>
          <div className="clear-div-xxs" />
          <Link
            role="button"
            aria-pressed="false"
            className="primary-cta-18 keep-btn"
            to="/home"
          >
            Keep membership
          </Link>
          <div className="clear-div-xl" />
        </div>
      </Fragment>
    );
  }
}

export default OptOutIssue;