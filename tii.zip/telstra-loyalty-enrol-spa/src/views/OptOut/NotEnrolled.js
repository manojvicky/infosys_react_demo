import React, { Fragment } from 'react';
import './NotEnrolled.scss';
/* eslint-disable */
const NotEnrolled = () => (
  <Fragment>
    <div className="not-enrolled ">
      <h2 className="sub-heading">You don't have a Telstra Plus membership</h2>
      <p>You can't opt-out of Telstra Plus because you don't have a membership.</p>
      <div className="clear-div-xs" />
      <p>
        Get started with Telstra Plus and from 14 May you can start earning
        points, enjoy amazing benefits and a lot more coming soon.
      </p>
      <div className="clear-div-xs" />
      <a className="enrol-submit-btn" type="submit" href="/join">
        Join Telstra Plus
      </a>
      <div className="clear-div-xs" />
      <p>Eligibility criteria apply.</p>
      <div className="clear-div-xl" />
    </div>
  </Fragment>
);
export default NotEnrolled;