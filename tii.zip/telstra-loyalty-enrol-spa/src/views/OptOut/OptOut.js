import React, { Component, Fragment } from 'react';

import IconChevron from 'icons/IconChevron';
import IconArrow from 'icons/IconArrow';

import './OptOut.scss';

/* eslint-disable */

class OptOut extends Component {
  render() {
    const { handleOptOut } = this.props;

    return (
      <Fragment>
        <div className="opt-out">
          <h2 className="sub-heading">Are you sure you want to leave?</h2>
          <div className="clear-div-m" />

          <div className="blue-callout">
            <p>
              If you just want to stop hearing from us, you can turn off email
              and SMS marketing communications in My Account.
            </p>
            <a
              role="button"
              aria-pressed="false"
              className="primary-cta-18 callout-btn"
              href="https://telstra.com.au"
            >
              Go to My Account
              <span>
                <IconArrow />
              </span>
            </a>
          </div>
          <div className="clear-div-m" />
          <p>If you leave Telstra Plus:</p>

          <div className="clear-div-s" />

          <ul>
            <li>
              <IconChevron />
              You’ll miss out on earning points
            </li>
            <li>
              <IconChevron />
              You won't have access to membership benefits
            </li>
            <li>
              <IconChevron />
              If you change your mind you can reactivate your account at any
              time, your points will be retained for 12 months.
            </li>
            <li>
              <IconChevron />
              Limited authority representatives may lose their Telstra Plus membership.
            </li>
          </ul>
          <div className="clear-div-xs" />

          <button
            onClick={handleOptOut}
            className="enrol-submit-btn alert"
            type="button"
          >
            Leave Telstra Plus
          </button>
          <div className="clear-div-xxs" />
          <a
            role="button"
            aria-pressed="false"
            className="primary-cta-18 keep-btn"
            href="https://telstra.com.au"
          >
            Cancel and remain a member
          </a>
          <div className="clear-div-xl" />
        </div>
      </Fragment>
    );
  }
}

export default OptOut;