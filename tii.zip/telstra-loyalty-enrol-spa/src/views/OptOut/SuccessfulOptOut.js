import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';

import IconArrow from 'icons/IconArrow';

import './SuccessfulOptOut.scss';

/* eslint-disable */

class SuccessfulOptOut extends Component {
  render() {
    return (
      <Fragment>
        <div className="succesful-opt-out ">
          <h2 className="sub-heading">Sorry to see you go</h2>
          <p>Your Telstra Plus membership has been cancelled.</p>
          <div className="clear-div-s" />
          <p>If you wish to reactivate your account, you can do so anytime.</p>
          <div className="clear-div-xs" />
          <Link
            role="button"
            aria-pressed="false"
            className="primary-cta-18 enrol-learn-more-btn"
            to="/home"
          >
            Home <IconArrow />
          </Link>
          <div className="clear-div-xl" />
        </div>
      </Fragment>
    );
  }
}

export default SuccessfulOptOut;