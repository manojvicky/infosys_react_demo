import SuccessfultOptOut from './SuccessfulOptOut';

export default SuccessfultOptOut;