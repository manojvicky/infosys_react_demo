import BenefitsTiles from './BenefitsTiles';

export default BenefitsTiles;
