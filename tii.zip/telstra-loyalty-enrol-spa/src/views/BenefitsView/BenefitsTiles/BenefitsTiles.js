import React, { Fragment } from 'react';
import Slider from 'react-slick';
import renderHTML from 'react-render-html';
// import VerticalTabs from 'components/VerticalTabs';
import IconEarnPoints from 'icons/SVGEarnPoints.svg';
import IconTickets from 'icons/IconTickets';
import IconVIPServices from 'icons/IconVIPServices';
import IconExtras from 'icons/IconExtras';

import silvertick from 'assets/images/silverTick.svg';
import membertick from 'assets/images/memberTick.svg';
import goldtick from 'assets/images/goldTick.svg';

import {
  EARNPOINTS,
  TICKETS,
  SILVEREXTRAS,
  SILVERVIPSERVICES,
  GOLDEXTRAS,
  GOLDVIPSERVICES
} from 'constants/benefitTiles.js';

import './BenefitsTiles.scss';

const settings = {
  dots: true,
  infinite: false,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  className: 'focused-slide',
  centerMode: true,
  centerPadding: '20px'
};

const BenefitsTiles = () => (
  <Fragment>
    <div id="benefits-tiles" className="benefits-tiles">
      <h2 className="tiles-header">
        Enjoy unique benefits tailored to your tier
      </h2>
      <div className="tile-container hidden-xs">
        <div className="benefit-tile member">
          <span className="member-callout">
            New customers start on this tier
          </span>
          <div className="text-container">
            <h3 className="tile-title">Member</h3>
            <p className="tile-avg-spend">
              $0 - $1,499
              <br /> Annual spend
            </p>
            <p className="tile-copy">
              For example, this equates to an average monthly spend of $0-$125
            </p>
          </div>
          <ul className="benefits-list member">
            <li className="title-icon">
              <span className="title-span">
                <img src={IconEarnPoints} alt="Earn points icon" />
                Earn Points
              </span>
            </li>
            {EARNPOINTS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={membertick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list member">
            <li className="title-icon">
              <IconTickets />
              <span className="title-span">Tickets</span>
            </li>
            {TICKETS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={membertick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="benefit-tile silver">
          <div className="text-container">
            <h3 className="tile-title">Silver</h3>
            <p className="tile-avg-spend">
              $1,500 - $2,999
              <br /> Annual spend
            </p>
            <p className="tile-copy">
              For example, this equates to an average monthly spend of $125 -
              $250
            </p>
          </div>
          <ul className="benefits-list silver">
            <li className="title-icon">
              <span className="title-span">
                <img src={IconEarnPoints} alt="Earn points icon" />
                Earn Points
              </span>
            </li>
            {EARNPOINTS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={silvertick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list silver">
            <li className="title-icon">
              <IconTickets />
              <span className="title-span">Tickets</span>
            </li>
            {TICKETS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={silvertick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list silver">
            <li className="title-icon">
              <IconExtras />
              <span className="title-span">Extras</span>
            </li>
            {SILVEREXTRAS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={silvertick} alt="tick icon" />
                  <span>{renderHTML(item)}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list silver">
            <li className="title-icon">
              <IconVIPServices />
              <span className="title-span">VIP Services</span>
            </li>
            {SILVERVIPSERVICES.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={silvertick} alt="tick icon" />
                  <span>{renderHTML(item)}</span>
                </li>
              );
            })}
          </ul>
        </div>
        <div className="benefit-tile gold">
          <div className="text-container">
            <h3 className="tile-title">Gold</h3>
            <p className="tile-avg-spend">
              $3000+
              <br /> Annual spend
            </p>
            <p className="tile-copy">
              For example, this equates to an average monthly spend of $250 plus
            </p>
          </div>
          <ul className="benefits-list gold">
            <li className="title-icon">
              <span className="title-span">
                <img src={IconEarnPoints} alt="Earn points icon" />
                Earn Points
              </span>
            </li>
            {EARNPOINTS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={goldtick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list gold">
            <li className="title-icon">
              <IconTickets />
              <span className="title-span">Tickets</span>
            </li>
            {TICKETS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={goldtick} alt="tick icon" />
                  <span>{item}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list gold">
            <li className="title-icon">
              <IconExtras />
              <span className="title-span">Extras</span>
            </li>
            {GOLDEXTRAS.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={goldtick} alt="tick icon" />
                  <span>{renderHTML(item)}</span>
                </li>
              );
            })}
          </ul>
          <ul className="benefits-list gold">
            <li className="title-icon">
              <IconVIPServices />
              <span className="title-span">VIP Services</span>
            </li>
            {GOLDVIPSERVICES.map((item, index) => {
              return (
                <li className="tick-icon" key={index}>
                  <img src={goldtick} alt="tick icon" />
                  <span>{renderHTML(item)}</span>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
      <div className="tile-container visible-xs">
        <Slider {...settings}>
          <div className="benefit-tile member">
            <span className="member-callout">
              New customers start on this tier
            </span>
            <div className="text-container">
              <h3 className="tile-title">Member</h3>
              <p className="tile-avg-spend">
                $0 - $1,499
                <br /> Annual spend
              </p>
              <p className="tile-copy">
                For example, this equates to an average monthly spend of $0-$125
              </p>
            </div>
            <ul className="benefits-list member">
              <li className="title-icon">
                <span className="title-span">
                  <img src={IconEarnPoints} alt="Earn points icon" />
                  Earn Points
                </span>
              </li>
              {EARNPOINTS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={membertick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list member">
              <li className="title-icon">
                <IconTickets />
                <span className="title-span">Tickets</span>
              </li>
              {TICKETS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={membertick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="benefit-tile silver">
            <div className="text-container">
              <h3 className="tile-title">Silver</h3>
              <p className="tile-avg-spend">
                $1,500 - $2,999
                <br /> Annual spend
              </p>
              <p className="tile-copy">
                For example, this equates to an average monthly spend of $125 -
                $250
              </p>
            </div>
            <ul className="benefits-list silver">
              <li className="title-icon">
                <span className="title-span">
                  <img src={IconEarnPoints} alt="Earn points icon" />
                  Earn Points
                </span>
              </li>
              {EARNPOINTS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={silvertick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list silver">
              <li className="title-icon">
                <IconTickets />
                <span className="title-span">Tickets</span>
              </li>
              {TICKETS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={silvertick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list silver">
              <li className="title-icon">
                <IconExtras />
                <span className="title-span">Extras</span>
              </li>
              {SILVEREXTRAS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={silvertick} alt="tick icon" />
                    <span>{renderHTML(item)}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list silver">
              <li className="title-icon">
                <IconVIPServices />
                <span className="title-span">VIP Services</span>
              </li>
              {SILVERVIPSERVICES.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={silvertick} alt="tick icon" />
                    <span>{renderHTML(item)}</span>
                  </li>
                );
              })}
            </ul>
          </div>
          <div className="benefit-tile gold">
            <div className="text-container">
              <h3 className="tile-title">Gold</h3>
              <p className="tile-avg-spend">
                $3000+
                <br /> Annual spend
              </p>
              <p className="tile-copy">
                For example, this equates to an average monthly spend of $250
                plus
              </p>
            </div>
            <ul className="benefits-list gold">
              <li className="title-icon">
                <span className="title-span">
                  <img src={IconEarnPoints} alt="Earn points icon" />
                  Earn Points
                </span>
              </li>
              {EARNPOINTS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={goldtick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list gold">
              <li className="title-icon">
                <IconTickets />
                <span className="title-span">Tickets</span>
              </li>
              {TICKETS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={goldtick} alt="tick icon" />
                    <span>{item}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list gold">
              <li className="title-icon">
                <IconExtras />
                <span className="title-span">Extras</span>
              </li>
              {GOLDEXTRAS.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={goldtick} alt="tick icon" />
                    <span>{renderHTML(item)}</span>
                  </li>
                );
              })}
            </ul>
            <ul className="benefits-list gold">
              <li className="title-icon">
                <IconVIPServices />
                <span className="title-span">VIP Services</span>
              </li>
              {GOLDVIPSERVICES.map((item, index) => {
                return (
                  <li className="tick-icon" key={index}>
                    <img src={goldtick} alt="tick icon" />
                    <span>{renderHTML(item)}</span>
                  </li>
                );
              })}
            </ul>
          </div>
        </Slider>
      </div>
    </div>
    <div className="faq-container">
      {/* <VerticalTabs
        title=""
        tabs={[
          {
            title: `How do I qualify for a tier?`,
            description: `<p>You will not be able to see any points in <a href="https://www.telstra.com.au/my-account/telstra-24x7-app">My Account/24x7® app</a> until after 14 May 2019. Your points balance will depend on your eligible spend from 14 May 2019.</p>`
          }
        ]}
      /> */}
    </div>
  </Fragment>
);

export default BenefitsTiles;
