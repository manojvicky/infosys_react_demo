import React from 'react';
import {shallow, mount} from 'enzyme';
import {BenefitsView} from './BenefitsView';

import {TIER_GOLD, TIER_SILVER, SECTION_EXTRA, SECTION_VIP, TierInfo} from 'constants/benefitTiles';

const EXTRA_SECTION_TITLE = "Your movie night at home is on us"
const VIP_SECTION_TITLE = "Tech support when you need it";

xdescribe('BenefitsView', () =>{
    let wrapper;


    describe('Extras Section', ()=>{
        it('hides extras section if Tier is not Gold or Silver', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: "Member"}}}/>);
            expect(wrapper.text()).not.toContain(EXTRA_SECTION_TITLE);
        });
        it('shows extras section if Tier is  Gold or Silver', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: TIER_SILVER}}}/>);
            expect(wrapper.text()).toContain(EXTRA_SECTION_TITLE);
        });

        it('shows the correct promo content text for Gold Tier', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: TIER_GOLD}}}/>);
            expect(wrapper.text())
                .toContain(TierInfo[SECTION_EXTRA][TIER_GOLD].promoCopy);
        });
    })

    describe('Extras Section - showExtraSection()', ()=>{
        beforeAll(()=>{
            wrapper = shallow(<BenefitsView />);
        })

        it('hides extras section if Tier is not Gold or Silver', ()=>{
            expect(wrapper.instance().showExtraSection(null)).toEqual(null);
            expect(wrapper.instance().showExtraSection('invalid tier')).toEqual(null);
        });

        it('shows extras section if Tier is Gold or Silver', ()=>{
            expect(wrapper.instance().showExtraSection(TIER_GOLD).props.children.props['promoTitle'])
                .toContain(EXTRA_SECTION_TITLE);
            expect(wrapper.instance().showExtraSection(TIER_SILVER).props.children.props['promoTitle'])
                .toContain(EXTRA_SECTION_TITLE);
        });

        it('shows the correct promo content text for Gold Tier', ()=>{
            expect(wrapper.instance().showExtraSection(TIER_GOLD).props.children.props['promoCopy'])
                .toContain(TierInfo[SECTION_EXTRA][TIER_GOLD].promoCopy);
        });

        it('shows the correct promo content text for Silver Tier', ()=>{
            expect(wrapper.instance().showExtraSection(TIER_SILVER).props.children.props['promoCopy'])
                .toContain(TierInfo[SECTION_EXTRA][TIER_SILVER].promoCopy);
        });

    });

    describe('VIP Section', ()=>{
        it('hides VIP section if Tier is not Gold or Silver', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: "Member"}}}/>);
            expect(wrapper.text()).not.toContain(VIP_SECTION_TITLE);
        });
        it('shows VIP section if Tier is  Gold or Silver', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: TIER_GOLD}}}/>);
            expect(wrapper.text()).toContain(VIP_SECTION_TITLE);
        });

        it('shows the correct promo content text for Silver Tier', ()=>{
            wrapper = mount(<BenefitsView enrolment={{membership: {tier: TIER_SILVER}}}/>);
            expect(wrapper.text())
                .toContain(TierInfo[SECTION_VIP][TIER_SILVER].promoCopy);
        });
    })


})