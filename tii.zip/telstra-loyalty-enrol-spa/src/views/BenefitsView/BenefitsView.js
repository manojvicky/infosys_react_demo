import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import techSupportImage from 'assets/images/Rewards_VIP_TechSupport_4x3-2@2x.jpg';
import moviesPromoImage from 'assets/images/horizon2_telstra-image_4x3_Movies-2.png';
import moviesPromoImageMobile from 'assets/images/horizon2_telstra-image_4x3_Movies-2.jpg';
import extrasTileImage from 'assets/images/Rewards_Extras_4x3@2x.jpg';
import KayoTileImage from 'assets/images/Kayo-4x3@2x.jpg';
import * as Analytics from 'utils/analytics';
import BigPromoTile from 'components/BigPromoTile';
import VerticalPromoTile from 'components/VerticalPromoTile';
import PromoGroup from 'components/PromoGroup/PromoGroup';
import MiniPromoTile from 'components/MiniPromoTile';
import VerticalTabs from 'components/VerticalTabs';
import AlertBox from 'components/AlertBox';
import AFLPromo from 'assets/images/AFL-4x3@2x.jpg';
import LifeOfPetsPromo from 'assets/images/Pets-4x3@2x.jpg';

import IconArrow from 'icons/IconArrow';
import AppLog from 'utils/AppLog';
import {
  TIER_GOLD,
  TIER_SILVER,
  SECTION_EXTRA,
  SECTION_VIP,
  TierInfo
} from 'constants/benefitTiles';
import ticketsPromos from 'constants/ticketsPromos';
import BenefitsTiles from './BenefitsTiles';

import {
  MEMBERBENEFITSFAQS,
  SILVERBENEFITSFAQS,
  GOLDBENEFITSFAQS,
  THINGSYOUNEEDTOKNOW,
  ENTERTAINMENTEXTRAS,
  GOLDTIERVIP,
  SILVERTIERVIP
} from './BenefitsContent.js';

import './BenefitsView.scss';

const { REACT_APP_ENV, REACT_APP_PLUS_HOME_URL } = process.env;
const IN_NON_PROD = REACT_APP_ENV === 'nonprod';

export class BenefitsView extends Component {
  constructor(props) {
    super(props);
    this.log = new AppLog('Benefits View');
  }

  componentDidMount() {
    this.log.debug('Benefits view mounted');
    Analytics.setPageName('View Benefits');
  }

  showHeroPromo = tier => {
    // Add some conditionals here when we business decides what it wants
    return (
      <BigPromoTile
        icon="Tickets"
        iconTitle="Tickets"
        imagePath={LifeOfPetsPromo}
        imageAltText="The Secret Life of Pets 2"
        promoTitle="The Secret Life of Pets 2"
        promoCopy="The Secret Life of Pets 2 is the highly anticipated sequel to the 2016 comedic blockbuster. Get your tickets for $12.50."
        promoSubCopy={null}
        buttonText="Get tickets"
        url="https://www.telstra.com.au/plus/tickets/movies?ti=TR:TR:may2019:tplus-tickets-home-page:movies:link"
        tier={tier}
        leftImage
      />
    );
  };

  showKayoTile = tier => {
    if (tier && (tier === TIER_GOLD || tier === TIER_SILVER)) {
      let url;

      if (tier === 'GOLD') {
        url =
          'https://uat2.hub.telstra.com.au/kayo.html?device=desktop&offerId=d261f621-e889-4949-a751-a27c1ddf1c20#/product';
      } else {
        url =
          'https://uat2.hub.telstra.com.au/kayo.html?device=desktop&offerId=f8644500-26e1-4c65-ae38-d774516ede23#/product';
      }

      return (
        <div className="offset-container">
          <BigPromoTile
            icon="Extras"
            iconTitle="Entertainment extras"
            hasLozenge
            dateAvailable="Coming late-June"
            imagePath={KayoTileImage}
            promoTitle="Watch sports on your terms"
            promoCopy={`Stream over 50 sports, live and anytime for ${
              tier === 'GOLD' ? 'three months' : 'one month'
            }  with Kayo Basic, on us.<br><br>
            No watching from the sidelines. With game-changing features, Kayo is the ultimate way to get closer to the sports you love.`}
            tier={tier}
            leftImage={tier === 'GOLD'}
            url={IN_NON_PROD ? url : null}
            buttonText={IN_NON_PROD ? 'Activate your credit' : null}
          />
        </div>
      );
    }
    return null;
  };

  showExtraSection = (tier, imgPosLeft = true) => {
    if (tier && (tier === TIER_GOLD || tier === TIER_SILVER)) {
      return (
        <div id="TTVBO" className="offset-container">
          <BigPromoTile
            icon="Extras"
            iconTitle="Entertainment extras"
            imagePath={extrasTileImage}
            promoTitle="Your movie night at home is on us"
            leftImage={imgPosLeft}
            tier={tier}
            hasLozenge
            footnote="Activate your credit by 31st July 2019"
            {...TierInfo[SECTION_EXTRA][tier]}
          />
        </div>
      );
    }
    return null;
  };

  showVIPSection = tier => {
    if (tier && (tier === TIER_GOLD || tier === TIER_SILVER)) {
      return (
        <div className="offset-container">
          <BigPromoTile
            icon="VIPServices"
            iconTitle="VIP Services"
            imagePath={techSupportImage}
            tier={tier}
            leftImage={tier === 'SILVER'}
            hasLozenge
            techSupport
            techSupportNumber="13 22 00"
            {...TierInfo[SECTION_VIP][tier]}
          />
        </div>
      );
    }
    return null;
  };

  showMiniPromos = () => {
    const miniPromos = ticketsPromos.map(promo => (
      // id can be created from another field if unique id doesnt exist
      <MiniPromoTile
        key={promo.id}
        imagePath={promo.imagePath}
        imageAltText={promo.imageAltText}
        promoTitle={promo.promoTitle}
        buttonText={promo.buttonText}
        url={promo.url}
      />
    ));
    return miniPromos;
  };

  showVerticalPromos = tier => {
    // Add some conditionals here when  business decides what it wants
    return (
      <div className="vertical-promo-tiles">
        <VerticalPromoTile
          icon="Tickets"
          iconTitle="Discounted movie tickets"
          imagePath={moviesPromoImage}
          mobileImagePath={moviesPromoImageMobile}
          imageAltText="Discounted movie tickets promo"
          promoTitle="Get discounted movie tickets"
          promoCopy="Get $12.50 movie tickets plus a free popcorn and drink combo upgrade."
          buttonText="Get movie tickets"
          tier={tier}
          url="https://www.telstra.com.au/plus/tickets/movies?ti=14052019:tplusspa:thanks:banner"
        />
        <VerticalPromoTile
          icon="Tickets"
          iconTitle="AFL tickets"
          imagePath={AFLPromo}
          mobileImagePath={AFLPromo}
          imageAltText="Grinspoon Chemical Hearts National Tour"
          promoTitle="Get $20 tickets"
          promoCopy="Get closer to the AFL action with $20 tickets to selected matches, and junior priced tickets."
          url="https://www.telstra.com.au/plus/tickets/sports/afl?ti=14052019:tplusspa:thanks:banner"
          buttonText="Get tickets"
        />
      </div>
    );
  };

  renderThingsYouNeedToKnow = tier => {
    if (tier === 'GOLD') {
      return THINGSYOUNEEDTOKNOW.concat(ENTERTAINMENTEXTRAS, GOLDTIERVIP);
    }
    if (tier === 'SILVER') {
      return THINGSYOUNEEDTOKNOW.concat(ENTERTAINMENTEXTRAS, SILVERTIERVIP);
    }
    return THINGSYOUNEEDTOKNOW;
  };

  renderBenefitsFAQs = tier => {
    if (tier === 'GOLD') {
      return GOLDBENEFITSFAQS;
    }
    if (tier === 'SILVER') {
      return SILVERBENEFITSFAQS;
    }
    return MEMBERBENEFITSFAQS;
  };

  render() {
    const { enrolment, activeAccount } = this.props;
    this.log.debug(`Current user enrolment`, enrolment);
    const tier = activeAccount.loyaltyTier;
    return (
      <Fragment>
        <div className="benefits-page container">
          <div className="benefits-page-wrapper">
            {this.showHeroPromo(tier)}
            <div className="clear-div-xl hidden-xs" />
            {this.showVerticalPromos(tier)}
            <div className="clear-div-xl hidden-xs" />
            {activeAccount.role !== 'LIMITED AUTHORITY' &&
              this.showExtraSection(tier)}
            <div className="small-promo-tiles">
              <PromoGroup
                tileAmount={4}
                heading="Get discounted movie tickets and more"
              >
                {this.showMiniPromos()}
              </PromoGroup>
            </div>
            <div className="clear-div-xl hidden-xs" />
            {activeAccount.role !== 'LIMITED AUTHORITY' &&
              this.showVIPSection(tier)}
            {activeAccount.role !== 'LIMITED AUTHORITY' &&
              this.showKayoTile(tier)}
            <BenefitsTiles />
            {activeAccount.role === 'LIMITED AUTHORITY' && <AlertBox />}
            <div>
              <div className="faq-container">
                <VerticalTabs
                  title="FAQs"
                  tabs={this.renderBenefitsFAQs(tier)}
                />
                <div className="clear-div-xl" />
                <a
                  role="button"
                  aria-pressed="false"
                  className="primary-cta-18 see-all-btn"
                  target="_blank"
                  rel="noopener noreferrer"
                  href={`${REACT_APP_PLUS_HOME_URL}/frequently-asked-questions`}
                >
                  View all FAQs <IconArrow />
                </a>
              </div>
            </div>

            <div className="clear-div-large" />
            <div className="faq-container">
              <VerticalTabs
                title="Things you need to know"
                tabs={this.renderThingsYouNeedToKnow(tier)}
              />
            </div>
            <div className="clear-div-xxxl" />
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  activeAccount: state.activeAccount,
  enrolment: state.enrolment,
  eligibility: state.eligibility
});

BenefitsView.propTypes = {
  activeAccount: PropTypes.shape({}),
  enrolment: PropTypes.shape({
    enrolled: PropTypes.bool,
    membership: PropTypes.shape({
      tier: PropTypes.string
    })
  }),
  eligibility: PropTypes.object
};

BenefitsView.defaultProps = {
  activeAccount: {},
  eligibility: {},
  enrolment: {
    enrolled: false,
    membership: {
      tier: 'Member'
    }
  }
};

export default connect(mapStateToProps)(BenefitsView);
