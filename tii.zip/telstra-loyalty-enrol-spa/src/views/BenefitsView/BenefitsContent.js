export const MEMBERBENEFITSFAQS = [
  {
    title: `What are Telstra Plus Benefits?`,
    description: `<p>Customers who join Telstra Plus will have access to exciting membership benefits such as discounted tickets, entertainment extras on us and VIP services. The benefits you will have access to are based on your membership tier.<br><br>
    </p>`
  },
  {
    title: 'How do I move up a tier?',
    description: `If you are a new Telstra customer and join Telstra Plus, you will be on Member tier. Your tier will change once you meet the eligible spend within your membership year.
    <br><br>
    Your membership year is 12 months starting from the date you join Telstra Plus.
    <br><br>
    When your eligible spend within your membership year is more than $1,500 ($125 per month on average), you will move to Silver tier.
    <br><br>
    When your eligible spend within your membership year is more than $3,000 ($250 per month on average), you will move to Gold tier.
    <br><br>
    You can move to a higher tier at any point within your membership year, as long as you meet the eligible spend criteria. When you do move to a higher tier, you will remain on that tier for the remainder of your membership year, and the following membership year.
    <br><br>
    If you are an existing Telstra customer and join Telstra Plus, the membership tier you start on is based on your eligible spend in the last 12 months. `
  },
  {
    title: `How do I access Telstra Plus tickets?`,
    description: `<p>You can access Telstra Plus tickets either through the Offers tab in the Telstra 24x7® app, or directly through <a href="https://www.telstra.com/plus/tickets?ti=14052019:tplusspa:thanks:banner">Telstra.com/plus/tickets</a></p>`
  }
];

export const SILVERBENEFITSFAQS = [
  {
    title: `What are Telstra Plus Benefits?`,
    description: `<p>Customers who join Telstra Plus will have access to exciting membership benefits such as discounted tickets, entertainment extras on us and VIP services. The benefits you will have access to are based on your membership tier.<br><br>
    </p>`
  },
  {
    title: 'How do I move up a tier?',
    description: `If you are a new Telstra customer and join Telstra Plus, you will be on Member tier. Your tier will change once you meet the eligible spend within your membership year.
    <br><br>
    Your membership year is 12 months starting from the date you join Telstra Plus.
    <br><br>
    When your eligible spend within your membership year is more than $1,500 ($125 per month on average), you will move to Silver tier.
    <br><br>
    When your eligible spend within your membership year is more than $3,000 ($250 per month on average), you will move to Gold tier.
    <br><br>
    You can move to a higher tier at any point within your membership year, as long as you meet the eligible spend criteria. When you do move to a higher tier, you will remain on that tier for the remainder of your membership year, and the following membership year.
    <br><br>
    If you are an existing Telstra customer and join Telstra Plus, the membership tier you start on is based on your eligible spend in the last 12 months. `
  },
  {
    title: `How do I access my Telstra TV Box Office® credit?`,
    description: `<p>You can access your Telstra TV Box Office credit benefit by scrolling to the offer on the <a href="#TTVBO">Telstra Plus Benefits</a> page and clicking “Activate your credit”.
    <br><br>
    You can then choose which service you would like to apply your credit to on the following page. Click the “redeem” button next to your selected service and follow the prompts to activate your credit. 
    If you have a Telstra TV, you can access the benefit directly through the app on the home screen, after you sign in with the Telstra ID you used to join Telstra Plus.</p>`
  },
  {
    title: 'How do I access 24/7 tech support by Telstra Platinum®?',
    description: `If you are not already a Telstra Platinum® customer, you can access your tech support benefit by calling 13 22 00 and asking for "Tech Support".
    <br><br>
    Customers with an existing Telstra Platinum Service Subscription can contact Telstra Platinum via your usual preferred method.`
  }
];

export const GOLDBENEFITSFAQS = [
  {
    title: `What are Telstra Plus Benefits?`,
    description: `<p>Customers who join Telstra Plus will have access to exciting membership benefits such as discounted tickets, entertainment extras on us and VIP services. The benefits you will have access to are based on your membership tier.<br><br>
    </p>`
  },
  {
    title: `How do I access my Telstra TV Box Office® credit?`,
    description: `<p>You can access your Telstra TV Box Office credit benefit by scrolling to the offer on the <a href="#TTVBO">Telstra Plus Benefits</a> page and clicking “Activate your credit”.
    <br><br>
    You can then choose which service you would like to apply your credit to on the following page. Click the “redeem” button next to your selected service and follow the prompts to activate your credit. 
    If you have a Telstra TV, you can access the benefit directly through the app on the home screen, after you sign in with the Telstra ID you used to join Telstra Plus.</p>`
  },
  {
    title: 'How do I access 24/7 tech support by Telstra Platinum®?',
    description: `If you are not already a Telstra Platinum® customer, you can access your tech support benefit by calling 13 22 00 and asking for "Tech Support".
    <br><br>
    Customers with an existing Telstra Platinum Service Subscription can contact Telstra Platinum via your usual preferred method.`
  }
];

export const THINGSYOUNEEDTOKNOW = [
  {
    title: `Tickets`,
    description: `
    <strong>Telstra Plus</strong><br><br>
     Must be 18+ with an active service. Excludes business customers. Points are earned on payment of Telstra bill or pre-paid recharge (excl. refunds, credits & late payment fees). Points expire 3 years from earning. Marketing opt-in required (preferences can be changed).
    <br><br>
     <strong>Movie tickets</strong><br><br>
     Only available to Telstra customers. $12.50 standard, $15.50 3D and $16.50 Vmax tickets only available online for Event Cinemas, Greater Union, Birch Carroll & Coyle, Village Cinemas and Moonlight Cinemas in Australia. $15.50 Vpremium tickets at selected Village Cinemas. Ticket price includes booking fee and GST. Not available after 5pm on Saturdays or on public holidays. Not valid for Gold Class, movie marathons, special events and alternate content. 
     
     <br><br>$14.50 Telstra Large Combo Upgrade. Maximum of 10 Telstra Large Combos per transaction. 
     <br><br>Not valid in conjunction with any other promotion or discount. Purchase is strictly upon availability and a maximum of 10 tickets. Products or services obtained from this site may not be re-sold
     
     <br><br>
     <strong>Concert tickets</strong><br><br>
     Purchase of Telstra tickets are strictly subject to availability during sale window. Ticket prices and the ticket purchase terms are available on the ticket partners’ websites. Offer only available for Telstra Plus members. Limit of 10 tickets per transaction.
     <br><br>
     Check the Telstra Plus Tickets pre-sale <a href="https://www.telstra.com.au/thanks/music/music-terms-and-conditions?ti=14052019:tplusspa:thanks:banner" target="_blank"
     rel="noopener noreferrer">Terms and Conditions</a> for full details.
      
      <br><br>
      <strong>2019 Sports tickets</strong><br><br>
      Specially priced tickets available to customers with a Telstra Plus membership for Australian games. Excludes any Ticket Vendor delivery and handling fees. Subject to availability. Excludes home games for Adelaide Crows, Fremantle Dockers, West Coast Eagles and NZ Warriors. Excludes ANZAC Day clash (AFL), State of Origin, Finals Series and Grand Final. 

  

15% off Suncorp Super Netball tickets currently excludes Finals games. Terms and conditions apply. 
<br><br> See<br>
<a target="_blank"
rel="noopener noreferrer" href="https://www.telstra.com.au/plus/tickets/sports/afl?ti=14052019:tplusspa:thanks:banner">https://www.telstra.com.au/plus/tickets/sports/afl</a><br>
<a target="_blank"
rel="noopener noreferrer" href="https://www.telstra.com.au/plus/tickets/sports/nrl?ti=14052019:tplusspa:thanks:banner">https://www.telstra.com.au/plus/tickets/sports/nrl</a><br>
<a  target="_blank"
rel="noopener noreferrer" href="https://www.telstra.com.au/plus/tickets/sports/netball?ti=14052019:tplusspa:thanks:banner">https://www.telstra.com.au/plus/tickets/sports/netball</a><br>
<a target="_blank"
rel="noopener noreferrer" href="https://www.telstra.com.au/plus/tickets/sports/aleague?ti=14052019:tplusspa:thanks:banner">https://www.telstra.com.au/plus/tickets/sports/aleague</a>.<br><br><br>  
<strong>Arts tickets</strong><br><br>
Purchase of Telstra tickets are strictly subject to availability during sale window. Ticket prices and the ticket purchase terms are available on the ticket partners’ websites. Offer only available to customers with a Telstra Plus membership.<br>
<br> Limit of 10 tickets per transaction.  


<br><br>
Check the Telstra Plus tickets Concerts and Arts <a target="_blank"
rel="noopener noreferrer" href="https://www.telstra.com.au/thanks/music/music-terms-and-conditions?ti=14052019:tplusspa:thanks:banner">Terms and Conditions</a> for full details. 
<br><br>
<strong>Assistance with accessible seating</strong><br><br>An allocation of Accessible Seating is available during this pre-sale, on the phone numbers and during the hours of operation, as listed on each venue’s page. Accessible Seating cannot be purchased on-line. 
<br><br>
Accessible Seating cannot be purchased on-line. Please use the Code: <strong>TELSTRA</strong> when making your Accessible Seat phone booking. 

</p>`
  }
];

export const ENTERTAINMENTEXTRAS = [
  {
    title: 'Entertainment extras',
    description: `<p><strong>Telstra TV Box Office credit</strong> 
    <br><br>
    Telstra TV Box Office credit must be activated by 31 July 2019. Credit expires 12 months from date of activation. For use in Australia.
    <br><br>
    Telstra TV Box Office is available on Telstra TV, as well as on iOS and Android mobile devices, PC and Mac (via your web browser), and supported Smart TVs. Purchasing is not available on iOS. Watching Telstra TV Box Office won't count towards your data allowance on most Telstra Home Broadband connections. Excludes Telstra Air™</p>`
  }
];

export const GOLDTIERVIP = [
  {
    title: 'VIP services',
    description: `
    <p><strong>Gold Tier Tech Support by Telstra Platinum </strong><br><br>
    Telstra Platinum® is available for Telstra Plus Gold customers. Gold tier members who do not have an existing Telstra Platinum subscription will receive free, ongoing access to our Telstra Platinum tech experts, over the phone and/or via online chat. Access remains so long as the customer is a Gold tier member. Services are not available for some devices and software and excludes in store support at a Telstra Tech Bar. The cost of any software/hardware is not included in the price of the service and you are responsible for any data charges. <a target="_blank" rel="noopener noreferrer" href="https://www.telstra.com.au/content/dam/tcom/personal/consumer-advice/pdf/consumer/mobilegeneral.pdf">Fair Use Policy</a> applies. 
    
    <br><br>Support for faults is part of an included service in your Broadband, Home or Mobile service when purchased from Telstra. Telstra Platinum supports all tech in the home whether from Telstra or not.
    <br><br>Gold tier members with an existing Telstra Platinum subscription will receive a monthly credit towards their existing Telstra Platinum subscription for each month they remain a Gold tier member. If/when the customer moves from the Gold tier, charging for their Telstra
    <br><br>It may take up to two business days after you join Telstra Plus for the Telstra Platinum® tier benefit to become available.
    
    <br><br>
    Platinum subscription will resume during which customers may cancel their subscription at any time, early termination charges may be applicable. Please refer to <a target="_blank" rel="noopener referrer" href="https://www.telstra.com.au/customer-terms/home-family">Our Customer Terms</a> for more information.</p>`
  }
];

export const SILVERTIERVIP = [
  {
    title: 'VIP services',
    description: `<p><strong>Silver Tier Tech Support by Telstra Platinum </strong><br><br>
    Telstra Platinum® is available for Telstra Plus Silver customers. Silver tier members receive one free Platinum ‘once off’ tech support service per membership year when they call Telstra with a tech issue. Services are not available for some devices and software and excludes in store support at a Telstra Tech Bar. The cost of any software/hardware is not included in the price of the service and you are responsible for any data charges. <a target="_blank" rel="noopener noreferrer" href="https://www.telstra.com.au/content/dam/tcom/personal/consumer-advice/pdf/consumer/mobilegeneral.pdf">Fair Use Policy</a> applies.
    <br><br>Support for faults is part of an included service in your Broadband, Home or Mobile service when purchased from Telstra. Telstra Platinum supports all tech in the home whether from Telstra or not.
    <br><br>It may take up to two business days after you join Telstra Plus for the Telstra Platinum® tier benefit to become available.</p>`
  }
];
