import BenefitsView from './BenefitsView';

export default BenefitsView;
