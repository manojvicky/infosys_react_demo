import AppLog from './AppLog';

describe('AppLog Tests', () => {
  let storeLog;
  let log;
  let outputData;

  beforeAll(() => {
    storeLog = inputs => (outputData += inputs);
    console.log = jest.fn(storeLog);
  });

  beforeEach(() => {
    outputData = '';
  });

  describe('Normal Environment', () => {
    beforeAll(() => {
      log = new AppLog('AppLog Test');
    });

    it('Config - make sure correct default config', () => {
      const config = log.getConfig();
      expect(config.logLevels).toEqual(['warn', 'info', 'error']);
    });

    it('Debug - user should NOT see console log if NOT IN Dev Environment', () => {
      log.debug('hello world');
      expect(outputData).toEqual('');
    });
    // see debug show test in Develop Environment Section

    it('Info - user should see console log', () => {
      log.info('hello world info');
      expect(outputData).toContain('hello world info');
    });

    // @todo: more tests to be written to test the other methods
  });

  describe('Development Environment', () => {
    beforeAll(() => {
      process.env.REACT_APP_ENV = 'dev';
      log = new AppLog('AppLog Test Dev');
    });

    it('Config - make sure correct default config', () => {
      const config = log.getConfig();
      expect(config.logLevels).toEqual(['debug', 'warn', 'info', 'error']);
      expect(config.LogTrace).toEqual(true);
    });

    it('Debug - user should see console log if IN Dev Environment', () => {
      log.debug('hello world');
      expect(outputData).toContain('hello world');
    });

    // @todo: more tests to be written to test the traceLog and the second method argument
  });
});
