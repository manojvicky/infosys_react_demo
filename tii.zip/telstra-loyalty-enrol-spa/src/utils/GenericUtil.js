import _ from 'lodash';


export default class GenericUtil {
  static nvl(obj, key, defaultValue = null) {
    const result = key.split('.').reduce(function(o, x) {
      return typeof o === 'undefined' || o === null ? o : o[x];
    }, obj);
    if(typeof result === 'undefined' || result === null ) return defaultValue;
    return result;
  }

  static parseIntNvl(val, defaultValue = null) {
    const intVal = parseInt(val, 10);
    if (!isNaN(intVal)) {
      return intVal;
    }
    if (typeof defaultValue === 'function') {
      return defaultValue();
    }
    return defaultValue;
  }

  static parseStringNvl(strVal, defaultValue = '') {
    return _.defaultTo(strVal, defaultValue.toString());
  }

  static isValidPositiveInt(num){
      return num >= 0 && Number.isInteger(num);
  }

  static getUpdatedCyclicIndex(index, listLength){
    if(GenericUtil.isValidPositiveInt(index) && GenericUtil.isValidPositiveInt(listLength)){
        return (index+1) % listLength;
    }
    return 0;
  }
  static getUpdateSingleCycleIndex(index, listLength){
      if(GenericUtil.isValidPositiveInt(index) && GenericUtil.isValidPositiveInt(listLength)){
          return ((index+1) < listLength)? (index+1): (listLength-1);
      }
      return 0;
  }

}
