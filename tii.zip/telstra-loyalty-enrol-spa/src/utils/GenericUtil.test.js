import React from "react";
import GenericUtil from './GenericUtil'

describe("Generic Util Tests", () =>{

    describe("NVL util tests", () =>{

        it("check if it works for boolean false", ()=>{
            let json = {data: {individual: {id: "324234", loyaltyOptIn: false}}};
            expect(GenericUtil.nvl(json, 'data.individual.loyaltyOptIn')).toEqual(false);
        });

        it("get object value", ()=>{
            let a = {b: "c"};
            expect(GenericUtil.nvl(a, "b", "")).toEqual("c");
        });
        it("get object value, multiple levels", ()=>{
            let a = {b: {c: {d: "e"}}};
            expect(GenericUtil.nvl(a, "b.c.d", "")).toEqual("e");
        });
        it("handle null value", ()=>{
            let a = {};
            expect(GenericUtil.nvl(a, "b","")).toEqual("");
        });
        it("handle null value, multiple levels", ()=>{
            let a = {b: {c: ""}};
            expect(GenericUtil.nvl(a, "b.c", "")).toEqual("");
        });

        it("handle null object", ()=>{
            expect(GenericUtil.nvl(null, "b","")).toEqual("");
        });
        it("provide default value on null", ()=>{
            expect(GenericUtil.nvl(null, "b","default")).toEqual("default");
        });
        it("get object value and ignore default", ()=>{
            let a = {b: "c"};
            expect(GenericUtil.nvl(a, "b",null)).toEqual("c");
        });
        it("get object value and ignore default", ()=>{
            let a = {b: "c"};
            expect(GenericUtil.nvl(a, "b")).toEqual("c");
        });
    });

    describe("parseIntNvl util test", () => {
        it("handles normal int string", ()=>{
            expect(GenericUtil.parseIntNvl("20")).toEqual(20);
            expect(GenericUtil.parseIntNvl("-45")).toEqual(-45);
            expect(GenericUtil.parseIntNvl("235426")).toEqual(235426);
        });
        it("handles decimals string as ints", ()=>{
            expect(GenericUtil.parseIntNvl("78.65")).toEqual(78);
            expect(GenericUtil.parseIntNvl("-92.934232")).toEqual(-92);
        });
        it("handles null as input, returns null", ()=>{
            expect(GenericUtil.parseIntNvl(null)).toEqual(null);
            expect(GenericUtil.parseIntNvl(NaN)).toEqual(null);
            expect(GenericUtil.parseIntNvl(undefined)).toEqual(null);
        });
        it("handles letters as input, returns null", ()=>{
            expect(GenericUtil.parseIntNvl("random letters")).toEqual(null);
            expect(GenericUtil.parseIntNvl("ran#$#@domle3453tters")).toEqual(null);
        });
        it("handles multiple word inputs, parse the first bit of word", ()=>{
            expect(GenericUtil.parseIntNvl("225 785")).toEqual(225);
            expect(GenericUtil.parseIntNvl("235 78&*^#@a5")).toEqual(235);
            expect(GenericUtil.parseIntNvl("78&*^#@a5 237")).toEqual(78);
        });

        it("default value, letters as input, returns default value", ()=>{
            expect(GenericUtil.parseIntNvl(null, 364)).toEqual(364);
            expect(GenericUtil.parseIntNvl("random letters", 234)).toEqual(234);
            expect(GenericUtil.parseIntNvl("ran#$#@domle3453tters",789)).toEqual(789);
        });

        it("default value, to check if default calls a function", ()=>{
            expect(GenericUtil.parseIntNvl("4545", GenericUtil.parseIntNvl(null, 364))).toEqual(4545);
        });

        it("default value, to check if default value is a function", ()=>{
            expect(GenericUtil.parseIntNvl("45455", GenericUtil.parseIntNvl(232, null))).toEqual(45455);
        });

        it("default value, to check if default value is a function 1", ()=>{
            expect(GenericUtil.parseIntNvl("abc", GenericUtil.parseIntNvl(232, null))).toEqual(232);
        });
    });

    describe("parseStringNvl util test", () => {
        it("should return the string untampered", ()=>{
            expect(GenericUtil.parseStringNvl("some-string")).toEqual("some-string");
        });
        it("should return the string untampered and ignore the default value", ()=>{
            expect(GenericUtil.parseStringNvl("some-string", "some-default-value")).toEqual("some-string");
        });
        it("should return the default value if the string is undefined", ()=>{
            expect(GenericUtil.parseStringNvl(undefined, "some-default-value")).toEqual("some-default-value");
        });
    });

    describe("isValidPositiveInt util test", ()=>{
        it("should give true for whole numbers", ()=>{
            expect(GenericUtil.isValidPositiveInt(5)).toEqual(true);
            expect(GenericUtil.isValidPositiveInt(23423)).toEqual(true);
            expect(GenericUtil.isValidPositiveInt(0)).toEqual(true);
            expect(GenericUtil.isValidPositiveInt(-0)).toEqual(true);
        });
        it("should give false for negative numbers", ()=>{
            expect(GenericUtil.isValidPositiveInt(-5)).toEqual(false);
            expect(GenericUtil.isValidPositiveInt(-2345)).toEqual(false);
            expect(GenericUtil.isValidPositiveInt(-4.5747)).toEqual(false);
        });
        it("should give false for decimals numbers", ()=>{
            expect(GenericUtil.isValidPositiveInt(23423.4557)).toEqual(false);
            expect(GenericUtil.isValidPositiveInt(0.4557)).toEqual(false);
            expect(GenericUtil.isValidPositiveInt(5.897547854)).toEqual(false);
        });
    })


    describe('getUpdateSingleCycleIndex', ()=>{
        it('normal tests', ()=>{
            expect(GenericUtil.getUpdateSingleCycleIndex(0, 3)).toEqual(1);
            expect(GenericUtil.getUpdateSingleCycleIndex(6846, 6)).toEqual(5);
            expect(GenericUtil.getUpdateSingleCycleIndex(2, 3)).toEqual(2);
            expect(GenericUtil.getUpdateSingleCycleIndex(10, 10)).toEqual(9);
            expect(GenericUtil.getUpdateSingleCycleIndex(2344, 3234)).toEqual(2345);
        });

        it('be able to handle edge cases', ()=>{
            expect(GenericUtil.getUpdateSingleCycleIndex(-2, 3)).toEqual(0);
            expect(GenericUtil.getUpdateSingleCycleIndex(-0.547, 3)).toEqual(0);
            expect(GenericUtil.getUpdateSingleCycleIndex(1.32, 3)).toEqual(0);
            expect(GenericUtil.getUpdateSingleCycleIndex(987, -233)).toEqual(0);
        });

        it('be able to handle null conditions', ()=>{
            expect(GenericUtil.getUpdateSingleCycleIndex(null, 3)).toEqual(0);
            expect(GenericUtil.getUpdateSingleCycleIndex(null, null)).toEqual(0);
            expect(GenericUtil.getUpdateSingleCycleIndex(3, null)).toEqual(0);
        });
    });

    
    describe('getUpdatedCyclicIndex', ()=>{
        it('normal tests', ()=>{
            expect(GenericUtil.getUpdatedCyclicIndex(0, 3)).toEqual(1);
            expect(GenericUtil.getUpdatedCyclicIndex(10, 6)).toEqual(5);
            expect(GenericUtil.getUpdatedCyclicIndex(2, 3)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(10, 10)).toEqual(1);
            expect(GenericUtil.getUpdatedCyclicIndex(2344, 3234)).toEqual(2345);
        });

        it('be able to handle edge cases', ()=>{
            expect(GenericUtil.getUpdatedCyclicIndex(-2, 3)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(-0.547, 3)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(1.32, 3)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(987, -233)).toEqual(0);
        });

        it('be able to handle null conditions', ()=>{
            expect(GenericUtil.getUpdatedCyclicIndex(null, 3)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(null, null)).toEqual(0);
            expect(GenericUtil.getUpdatedCyclicIndex(3, null)).toEqual(0);
        });
    });

});

