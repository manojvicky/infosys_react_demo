import axios from 'axios';
import constants from 'constants';

// Entities
const USER = 'user';
const ITEM = 'item';

// -----------------
// Generic APIs
// -----------------
const getThings = entityName => {
  return params => {
    return axios.get(`/${entityName}`, { params });
  };
};

const getThing = entityName => {
  return (entityId, params) => {
    return axios.get(`/${entityName}/${entityId}`, { params });
  };
};

const createThing = entityName => {
  return entity => {
    return axios.post(`/${entityName}`, entity);
  };
};

const updateThing = entityName => {
  return entity => {
    return axios.put(`/${entityName}/${entity.id}`, entity);
  };
};

const updateThingPartially = entityName => {
  return (entity, partOfEntity) => {
    return axios.patch(`/${entityName}/${entity.id}`, partOfEntity);
  };
};

const deleteThing = entityName => {
  return entityId => {
    return axios.delete(`/${entityName}/${entityId}`);
  };
};

// -----------------
// Uers APIs
// -----------------

export const fetchUsers = getThings(USER);

export const fetchUser = getThing(USER);

export const createUser = createThing(USER);

export const updateUser = updateThing(USER);

export const updateUserPartially = updateThingPartially(USER);

export const deleteUser = deleteThing(USER);

// -----------------
// Items APIs
// -----------------

export const fetchItems = getThings(ITEM);

export const fetchItem = getThing(ITEM);

export const createItem = createThing(ITEM);

export const updateItem = updateThing(ITEM);

export const updateItemPartially = updateThingPartially(ITEM);

export const deleteItem = deleteThing(ITEM);

// Generic Error handling
// -----------------
export const parseError = error => {
  if (error.response) {
    // The request was made and the server responded with a status code
    // that falls out of the range of 2xx
    const { data, status, headers } = error.response;
    switch (status) {
      case 400:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.BAD_REQUEST
        };
      case 401:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.UNAUTHORIZED
        };
      case 403:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.FORBIDDEN
        };
      case 404:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.NOT_FOUND
        };
      case 503:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.SERVICE_UNAVAILABLE
        };
      default:
        return {
          data,
          headers,
          status,
          error: constants.ERROR.INTERNAL_SERVER
        };
    }
  } else if (error.request) {
    // The request was made but no response was received
    // `error.request` is an instance of XMLHttpRequest in the browser and an instance of
    // http.ClientRequest in node.js
    return {
      error: constants.ERROR.OFFLINE
    };
  } else {
    // Something happened in setting up the request that triggered an Error
    return {
      error: constants.ERROR.UNKNOWN
    };
  }
};
