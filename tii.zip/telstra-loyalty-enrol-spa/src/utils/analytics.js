// Handler Library for the Omniture Analytics stuff
import _ from 'lodash';

import AppLog from 'utils/AppLog';

const logger = new AppLog('analytics');

export function initAnalytics() {
  logger.debug('Initialising Analytics Object');

  window.digitalData = {
    user: [],
    page: {
      pageInfo: {
        deployEnv: process.env.REACT_APP_ENV
      },
      category: {
        primaryCategory: 'Telstra Plus Portal'
      }
    },
    event: [],
    version: '1.0'
  };
}

export function setUser(user) {
  logger.debug('Adding Analytics User: ', user);

  const userObj = {
    profile: [
      {
        profileInfo: {
          loyaltyPoints: user.points,
          loyaltyTier: user.tier
        }
      }
    ]
  };
  // we are replacing only the first user for now
  // future may have multiple
  window.digitalData.user.splice(0, 1, userObj);
}

export function setPageName(pageName) {
  logger.debug('Updating Analytics PageName to: ', pageName);

  if (_.has(window.digitalData.page.pageInfo, 'pageName')) {
    window.digitalData.page.pageInfo.pageName = pageName;
  } else {
    const { pageInfo } = window.digitalData.page;

    pageInfo.pageName = pageName;
  }
}

export function addEvent(eventAction) {
  logger.debug('Adding Analytics Event: ', eventAction);
  const eventObj = { eventInfo: { eventAction } };

  window.digitalData.event.push(eventObj);
}
