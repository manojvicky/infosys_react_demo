import * as Analytics from './analytics';

const defaultDigitalData = {
  user: [],
  page: {
    pageInfo: {
      deployEnv: process.env.REACT_APP_ENV
    },
    category: {
      primaryCategory: 'Telstra Plus Portal'
    }
  },
  event: [],
  version: '1.0'
};

it('Sets default analytics object', () => {
  Analytics.initAnalytics();
  expect(window.digitalData).toEqual(defaultDigitalData);
});

it('Updates user array in digital data object', () => {
  const user1 = {
    name: 'user1',
    points: 200
  };

  Analytics.initAnalytics();
  Analytics.setUser(user1);

  expect(window.digitalData).toEqual({
    ...defaultDigitalData,
    user: [
      {
        profile: [
          {
            profileInfo: {
              loyaltyPoints: user1.points,
              loyaltyTier: user1.tier
            }
          }
        ]
      }
    ]
  });
});

it('Sets pageName in digital data object', () => {
  const pageName = 'test';
  Analytics.initAnalytics();
  Analytics.setPageName(pageName);

  expect(window.digitalData).toEqual({
    ...defaultDigitalData,
    page: {
      ...defaultDigitalData.page,
      pageInfo: {
        ...defaultDigitalData.page.pageInfo,
        pageName
      }
    }
  });
});

it('Updates event array in digital data object', () => {
  const eventName1 = 'test1';
  const eventName2 = 'test2';
  const eventName3 = 'test3';

  Analytics.initAnalytics();
  Analytics.addEvent(eventName1);

  expect(window.digitalData).toEqual({
    ...defaultDigitalData,
    event: [{ eventInfo: { eventAction: eventName1 } }]
  });

  Analytics.addEvent(eventName2);

  expect(window.digitalData).toEqual({
    ...defaultDigitalData,
    event: [
      { eventInfo: { eventAction: eventName1 } },
      { eventInfo: { eventAction: eventName2 } }
    ]
  });

  Analytics.addEvent(eventName3);

  expect(window.digitalData).toEqual({
    ...defaultDigitalData,
    event: [
      { eventInfo: { eventAction: eventName1 } },
      { eventInfo: { eventAction: eventName2 } },
      { eventInfo: { eventAction: eventName3 } }
    ]
  });
});
