// 503 ERROR STATUS CODES
export const ERR_ALREADY_ENROLLED = 1023;
export const ERR_LA_CAC = 1021;
export const ERR_ONLY_SMALL_BUSINESS_CACS = 1020;
export const ERR_NO_ACTIVE_CACSSOMESMBS = 1030; // For Some Small Business Accounts weird business rule
export const ERR_SOME_SMALL_BUSINESS_CACS = 1030;
export const ERR_NO_ACTIVE_CACS = 1040;

// Misc Error Codes
export const ERR_CONNABORTED = 'ECONNABORTED';
