import PromoTile1 from 'assets/images/horizon2_telstra-image_4x3_Movies-2.jpg';
import PromoTile2 from 'assets/images/horizon2_telstra-image_4x3_Sport@2x.jpg';
import PromoTile3 from 'assets/images/horizon2_telstra-image_4x3_Concert@2x.jpg';
import PromoTile4 from 'assets/images/horizon2_telstra-image_4x3_Art.@2x.jpg';

// const { REACT_APP_ENV } = process.env;
// const IN_DEVELOP = REACT_APP_ENV === 'dev';
// const { REACT_APP_ENV } = process.env;
// const IN_NON_PROD = REACT_APP_ENV === 'nonprod';

const ticketsPromos = [
  {
    id: 1,
    imagePath: PromoTile1,
    imageAltText: 'PromoImageTest',
    promoTitle:
      'Get $12.50 movie tickets plus a free popcorn and drink combo upgrade.',
    buttonText: 'Get movie tickets',
    url: 'https://www.telstra.com.au/plus/tickets/movies'
  },
  {
    id: 2,
    imagePath: PromoTile2,
    imageAltText: 'PromoImageTest',
    promoTitle: 'Get discounted and pre-sale tickets to sporting events.',
    buttonText: 'Get sports tickets',
    url: 'https://www.telstra.com.au/plus/tickets/sports'
  },
  {
    id: 3,
    imagePath: PromoTile3,
    imageAltText: 'PromoImageTest',
    promoTitle: 'Access exclusive pre-sales to the hottest concerts.',
    buttonText: 'Get concert tickets',
    url: 'https://www.telstra.com.au/plus/tickets/music'
  },
  {
    id: 4,
    imagePath: PromoTile4,
    imageAltText: 'PromoImageTest',
    promoTitle: 'Experience the arts with pre-sales and discounted tickets.',
    buttonText: 'Get arts tickets',
    url: 'https://www.telstra.com.au/plus/tickets/arts'
  }
];

export default ticketsPromos;
