export const MEMBERTILECOPY =
  'Brand new customers or existing customers with an annual eligible account spend of less than $1,500';
export const SILVERTILECOPY =
  'Existing customers with an annual eligible account spend of $1,500 - $2999';
export const GOLDTILECOPY =
  'Existing customers with an annual eligible account spend of $3,000+';

export const EARNPOINTS = [
  'Earn 10 points per eligible dollar on every bill or recharge'
];

export const TICKETS = [
  'Discounted movie tickets',
  'Pre-sale and discounted sports tickets',
  'Pre-sale concert tickets',
  'Pre-sale and discounted arts tickets',
  'Chances to win money-can’t-buy experiences'
];

export const SILVEREXTRAS = [
  '$75 Telstra TV Box Office™ credit, on us that you could use to rent up to 12 SD new releases. (Activate by 31 July 2019)',
  '<strong>Coming late-June</strong><br>1 month Kayo, on us'
];

export const SILVERVIPSERVICES = [
  'One-off tech support from Telstra Platinum®'
];

export const GOLDEXTRAS = [
  '$110 Telstra TV Box Office™ credit, on us that you could use to rent up to 18 SD new releases. (Activate by 31 July 2019)',
  '<strong>Coming late-June</strong><br>3 months Kayo, on us'
];

export const LEARNABOUTTIERS =
  'There are three Telstra plus membership tiers: Member, Silver and Gold. You will have access to different membership benefits depending on your tier';

export const GOLDVIPSERVICES = [`24/7 tech support from Telstra Platinum®`];

export const TIER_GOLD = 'GOLD';
export const TIER_SILVER = 'SILVER';

export const SECTION_EXTRA = 'ExtraSection';
export const SECTION_VIP = 'VIPSection';

export const TierInfo = {
  ExtraSection: {
    GOLD: {
      promoCopy: `As a Telstra Plus Gold tier customer, you can activate $110 Telstra TV Box Office credit that you could use to rent or buy new release movies fresh from the cinema.
      <br><br>
      Telstra TV Box Office™ gives you access to a huge range of blockbusters, new releases and classics across a wide range of genres, plus the flexibility and comfort to watch the way you want, without leaving home. `,
      promoSubCopy: `Activate by 31 July 2019.`,
      buttonText: 'Activate your credit',
      url:
        'https://hub.telstra.com.au/ttvbo.html?device=desktop&offerId=5ec184d5-a7ce-4d57-8d73-ede4dc712757#/product'
    },
    SILVER: {
      promoCopy: `As a Telstra Plus Silver tier customer, you can activate $75 Telstra TV Box Office credit that you could use to rent or buy new release movies fresh from the cinema.
      <br><br>
      Telstra TV Box Office™ gives you access to a huge range of blockbusters, new releases and classics across a wide range of genres, plus the flexibility and comfort to watch the way you want, without leaving home.`,
      promoSubCopy: `Activate by 31 July 2019.`,
      buttonText: 'Activate your credit',
      url:
        'https://hub.telstra.com.au/ttvbo.html?device=desktop&offerId=d7400474-43cd-11e9-b210-d663bd873d93#/product'
    }
  },
  VIPSection: {
    GOLD: {
      promoTitle: 'Get tech support when you need it',
      promoCopy: `Get expert help when you need it with devices, home tech and software including non-Telstra products, over the phone and online with Telstra Platinum® service on us.`,
      promoSubCopy: `Gold tier customers with an existing Telstra Platinum subscription will receive a monthly credit for 12 months towards their existing Telstra Platinum subscription.`,
      buttonText: 'Go to Telstra Platinum',
      url: 'https://www.telstra.com.au/platinum-technical-support#subscription'
    },
    SILVER: {
      promoTitle: 'Let us solve your tech problem ',
      promoCopy:
        'Get expert help setting up email, software or a tablet including non-Telstra products, connecting your printer or a social media tutorial with a free one-off tech support session, over the phone and online with Telstra Platinum®.',
      promoSubCopy: `Silver tier customers who are existing ‘Telstra Platinum Service Subscription’ customers and who contact Telstra Platinum with a Platinum related problem will receive 1 month credit towards the their existing Telstra Platinum subscription.`
    }
  }
};
