import each from 'lodash/each';
import keys from 'lodash/keys';
import intersection from 'lodash/intersection';
import extend from 'lodash/extend';

import * as actions from './actions';
import * as errorCodes from './errorCodes';

const files = {
  actions,
  errorCodes
};

// Loop through the imported constant files and check for duplicates
let constantsMutable = {};
each(keys(files), filename => {
  const file = files[filename];
  const duplicates = intersection(keys(constantsMutable), keys(file));
  each(duplicates, duplicate => {
    console.warn('Duplicate constant key found. Please fix this immediately.', {
      filename,
      duplicate
    }); // eslint-disable-line no-console
  });
  constantsMutable = extend(constantsMutable, file);
});

const constants = constantsMutable;

export default constants;
