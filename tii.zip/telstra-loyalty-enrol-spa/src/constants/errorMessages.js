export const DEFAULTMESSAGE = `We're working on the problem, please try again later.`;
export const ALREADYENROLLED = `You are already a Telstra Plus member.`;
export const REGISTRATIONERROR = `We weren't able to complete your registration. We're working on the problem, please try again later.`;

export const POINTLESSHEADING = 'You have no points at the moment';
export const POINTLESSCOPY =
  'You will earn 10 points per dollar on your next eligible bill payment or recharge. Points can take up to 4 business days to appear.';
export const POINTSERRORHEADING = 'Something went wrong';
export const POINTSERRORCOPY =
  "We aren't able to load your points history, please refresh or try again";
