import axios from './util/axiosHandle';
import { apiConfig as api } from '../oidc/oidc-configs';

const getDetailsApi = accessToken => {
  return axios({
    method: 'get',
    url: api.baseUrl + api.endpoints.getDetails,
    headers: { Authorization: `Bearer ${accessToken}` }
  })
    .then(response => {
      return response;
    })
    .catch(error => {
      throw error;
    });
};

export default getDetailsApi;
