import axios from 'axios';
import _ from 'lodash';

// set defaults params for AXIOS
const { REACT_APP_ENV } = process.env;
const IN_DEVELOP = REACT_APP_ENV === 'dev';
const IN_NON_PROD = REACT_APP_ENV === 'nonprod';

// sourceclear DDoS fix. Limiting to 20kb for an ajax request.
const maxContentLength = 20000;

if (IN_DEVELOP) {
  axios.defaults.timeout = 0;
} else if (IN_NON_PROD) {
  axios.defaults.timeout = 90000;
} else {
  axios.defaults.timeout = 45000;
}

// accessToken will come from Caiman handler library
// when auth token flow becomes avail
const axiosHandle = params => {
  return axios({
    ...params,
    maxContentLength
    // headers: { Authorization: `Bearer ${accessToken}` }
  })
    .then(response => {
      return response;
    })
    .catch(error => {
      if (_.has(error, 'request')) {
        if (_.has(error.request, 'res')) {
          error.request.res.destroy(); // sourceclear DDoS fix.
        }
      }
      throw error;
    });
};

export default axiosHandle;
