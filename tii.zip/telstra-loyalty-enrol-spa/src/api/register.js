import axios from './util/axiosHandle';
import { apiConfig as api } from '../oidc/oidc-configs';

const registerApi = accessToken => {
  return axios({
    method: 'post',
    url: api.baseUrl + api.endpoints.enrol,
    headers: { Authorization: `Bearer ${accessToken}` }
  })
    .then(response => {
      return response;
    })
    .catch(error => {
      throw error;
    });
};

export default registerApi;
