
import optOutApi from './optOutApi';
//import { apiConfig } from 'oidc/oidc-configs';
//jest.mock('oidc/oidc-configs');
import nock from 'nock';

//Working with Nock, couldn't get it to work fully.
// Also this API class doesn't have any logic to test, so postponing it to later 
xdescribe('optout Api', ()=>{
    let mockConfig;
    beforeEach(()=>{
        // jest.resetModules();
        // delete process.env.REACT_APP_CAIMAN_CONF;
        // process.env.REACT_APP_CAIMAN_CONF = 'dev-mocks'
        // mockConfig = require('../oidc/oidc-configs').apiConfig;

        // apiConfig = mockConfig;
        // console.log('mock config', mockConfig);
    })
    it('should return success on successful response', async()=>{
        nock('https://tapi.telstra.com')
            .post('/presentation/v1/loyalty/cip/unenrol')
            .reply(200, {data: {individual: {optIn: false }}},
                {
                    'Access-Control-Allow-Origin': '*',
                    'Content-type': 'application/json'
                  });
        const user = await optOutApi(123);
        expect(user).toEqual({data: {individual: {optIn: false }}});
    });


});

/*

//import optOutApi from './optOutApi';
//import { apiConfig } from 'oidc/oidc-configs';
//jest.mock('oidc/oidc-configs');
import nock from 'nock';

describe('optout Api', ()=>{
    let mockConfig, optOutApi;
    beforeEach(()=>{
        jest.resetModules();
        delete process.env.REACT_APP_CAIMAN_CONF;
        process.env.REACT_APP_CAIMAN_CONF = 'dev-mocks'
        // mockConfig = require('../oidc/oidc-configs').apiConfig;

        // apiConfig = mockConfig;
        // console.log('mock config', mockConfig);
        optOutApi = require('./optOutApi').default;
    })
    it('should return success on successful response', async()=>{
        let unenrolService = nock('https://localhost:8000')
            .post('/presentation/v1/loyalty/unenrol')
            .reply(200, {data: {individual: {optIn: false }}});
        
        const user = await optOutApi(123);
        expect(user).toEqual({data: {individual: {optIn: false }}});
    });


});

*/