import axios from './util/axiosHandle';
import { apiConfig as api } from 'oidc/oidc-configs';
import {LOGGER} from 'utils/AppLog';

const optOutApi = accessToken => {
  return axios({
    method: 'post',
    url: api.baseUrl + api.endpoints.optOut,
    headers: { Authorization: `Bearer ${accessToken}` }
  })
    .then(response => {
      return response;
    })
    .catch(error => {
      LOGGER.error("Unenrolling User", error)
      return error.response;
    });
};

export default optOutApi;
