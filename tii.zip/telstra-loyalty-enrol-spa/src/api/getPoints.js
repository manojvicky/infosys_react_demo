import axios from './util/axiosHandle';
import { apiConfig as api } from '../oidc/oidc-configs';

// inputs:
// ?cacList=<cac>,<cac>

const getPoints = (accessToken, cac) => {
  return axios({
    method: 'get',
    params: {
      cacList: cac
    },
    url: api.baseUrl + api.endpoints.getPoints,
    headers: { Authorization: `Bearer ${accessToken}` }
  })
    .then(response => {
      return response.data;
    })
    .catch(error => {
      throw error;
    });
};

export default getPoints;
