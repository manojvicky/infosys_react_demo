import axios from './util/axiosHandle';
import { apiConfig as api } from '../oidc/oidc-configs';

const unenrolApi = accessToken => {
  return axios({
    method: 'post',
    url: api.baseUrl + api.endpoints.optOut,
    headers: { Authorization: `Bearer ${accessToken}` },
    data: {
      loyaltyOptIn: false
    }
  })
    .then(response => {
      return response;
    })
    .catch(error => {
      throw error;
    });
};

export default unenrolApi;
