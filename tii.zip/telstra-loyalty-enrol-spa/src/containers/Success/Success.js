import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { withRouter, Link } from 'react-router-dom';

import * as Analytics from 'utils/analytics';
import AppLog from 'utils/AppLog';

import logoSVG from 'assets/images/TPlus Logo.svg';
import tile from 'assets/images/success-tile@2x.png';
import './Success.scss';
import IconArrow from 'icons/IconArrow';

class Success extends Component {
  constructor() {
    super();
    this.log = new AppLog('Enrol Success');
  }

  componentDidMount() {
    this.log.debug('Success Container mounted');
    Analytics.setPageName('Success Page');
  }

  render() {
    const styles = {
      backgroundImage: `url(${tile})`
    };
    return (
      <Fragment>
        <div className="success container">
          <p className="success-logo">
            <img src={logoSVG} alt="Telstra Logo" />
          </p>
          <h1>
            Welcome to Telstra Plus<sup>TM</sup>
          </h1>
          <h2>
            {`As a thank you for joining, we've added some bonus points to your
            account!`}
          </h2>
          <p className="success-copy">
            {`You're now set to earn points and enjoy exciting membership
            benefits.`}
          </p>
          <p className="link-container">
            <Link to="/benefits" className="primary-cta-22">
              View my Benefits <IconArrow />
            </Link>
          </p>
        </div>
        <div className="decoration" style={styles} />
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  enrolment: state.enrolment
});

export default withRouter(connect(mapStateToProps)(Success));
