import ErrorScreen from './ErrorScreen';

export default ErrorScreen;
