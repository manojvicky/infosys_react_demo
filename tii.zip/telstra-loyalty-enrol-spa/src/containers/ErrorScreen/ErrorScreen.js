import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import TechnicalIssue from 'views/ErrorViews/TechnicalIssue';
import * as Analytics from 'utils/analytics';

class ErrorScreen extends React.Component {
  componentDidMount() {
    Analytics.setPageName('Error Page');
  }

  render() {
    return <TechnicalIssue />;
  }
}

const mapStateToProps = state => ({
  app: state.app
});

export default withRouter(connect(mapStateToProps)(ErrorScreen));
