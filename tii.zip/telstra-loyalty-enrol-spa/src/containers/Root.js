import React from 'react';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';
import App from 'containers/App';
import configureStore, { history } from 'store';
import '@tcom/tcom-core/scss/tcom-core.scss';

import { Switch, Route } from 'react-router-dom';
import NotFound from 'containers/NotFound';
import ErrorScreen from 'containers/ErrorScreen';
import NotEligible from 'containers/NotEligible';
import Enrolment from 'containers/Enrolment';
import EligibilityCheck from 'components/EligibilityCheck';
import BenefitsContainer from 'containers/BenefitsContainer';
import PointsContainer from 'containers/PointsContainer';
import PointsHistoryView from 'views/PointsView/PointsHistoryView';
import InfoSupportView from 'views/Info/InfoSupportView';
import Success from 'containers/Success';
import OptOutContainer from 'containers/OptOutContainer';

import DebugPanel from 'DebugPanel';

const IN_DEVELOP =
  process.env.REACT_APP_ENV === 'dev' ||
  process.env.REACT_APP_ENV === 'dev-mocks' ||
  process.env.REACT_APP_ENV === 'ci';

// Create a history of your choosing (we're using a browser history in this case, imported from configureStore
const store = configureStore(history);

const renderRoutes = () => {
  return (
    <Switch>
      <Route exact path="/" component={EligibilityCheck} />
      <Route exact path="/join" component={Enrolment} />
      <Route exact path="/benefits" component={BenefitsContainer} />
      <Route exact path="/info/support" component={InfoSupportView} />
      <Route exact path="/points" component={PointsContainer} />
      <Route exact path="/points/history" component={PointsHistoryView} />
      <Route exact path="/not-eligible" component={NotEligible} />
      <Route exact path="/error" component={ErrorScreen} />
      <Route exact path="/success" component={Success} />
      <Route exact path="/opt-out" component={OptOutContainer} />
      <Route component={NotFound} />
    </Switch>
  );
};

const Root = () => (
  <Provider store={store}>
    <ConnectedRouter history={history}>
      <App>{renderRoutes()}</App>

      {IN_DEVELOP && <DebugPanel>{renderRoutes()}</DebugPanel>}
    </ConnectedRouter>
  </Provider>
);

export default Root;
