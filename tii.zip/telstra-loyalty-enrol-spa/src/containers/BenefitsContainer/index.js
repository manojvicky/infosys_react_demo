import BenefitsContainer from './BenefitsContainer';

export default BenefitsContainer;
