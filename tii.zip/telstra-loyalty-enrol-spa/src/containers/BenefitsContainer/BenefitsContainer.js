import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';

import PageTitle from 'components/PageTitle';

import BenefitsView from 'views/BenefitsView';

import BenefitsHeader from 'assets/images/BenefitsHeader@2x.jpg';
import BenefitsHeaderMobile from 'assets/images/BenefitsHeaderMobile.png';

import * as Analytics from 'utils/analytics';
import AppLog from 'utils/AppLog';

class BenefitsContainer extends Component {
  constructor() {
    super();
    this.log = new AppLog('BenefitsContainer');
  }

  componentDidMount() {
    this.log.debug('Benefits Container mounted');
    Analytics.setPageName('Benefits Page');
  }

  render() {
    return (
      <Fragment>
        <PageTitle
          miniHeader="Benefits"
          heroImage={BenefitsHeader}
          mobileImage={BenefitsHeaderMobile}
          calloutHeader="Explore your membership benefits"
        />
        <BenefitsView />
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  enrolment: state.enrolment
});

export default connect(mapStateToProps)(BenefitsContainer);
