import NotEligible from './NotEligible';

export default NotEligible;
