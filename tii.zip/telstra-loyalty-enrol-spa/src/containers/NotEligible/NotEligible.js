import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter, Redirect } from 'react-router-dom';

import AppLog from 'utils/AppLog';

import NotForBusinessCustomers from 'views/NotEligibleViews/NotForBusinessCustomers';
import LimitedPermissions from 'views/NotEligibleViews/LimitedPermissions';
import NoActiveServices from 'views/NotEligibleViews/NoActiveServices';

import * as Analytics from 'utils/analytics';
import * as ERRCODES from 'constants/errorCodes.js';

class NotEligible extends Component {
  constructor() {
    super();
    this.log = new AppLog('NotEligible');
  }

  renderIneligibilityReason = () => {
    const {
      error: { errorStatusCode }
    } = this.props;

    this.log.debug('Error status code: ', errorStatusCode);

    switch (errorStatusCode) {
      case ERRCODES.ERR_NO_ACTIVE_CACS:
        Analytics.setPageName('Not Eligible - No active services');
        return <NoActiveServices />;
      case ERRCODES.ERR_NO_ACTIVE_CACSSOMESMBS:
        Analytics.setPageName(
          'Not Eligible - No active services OR Some Small Business'
        );
        return <NoActiveServices />;
      case ERRCODES.ERR_ONLY_SMALL_BUSINESS_CACS:
        Analytics.setPageName('Not Eligible - Some Small Business');
        return <NotForBusinessCustomers />;
      case ERRCODES.ERR_LA_CAC:
        Analytics.setPageName('Not Eligible - Limited Authority');
        return <LimitedPermissions />;
      default:
        Analytics.setPageName('Not Eligible - Generic screen');
        return <Redirect to="/error" />;
    }
  };

  render() {
    return (
      <Fragment>
        <div className="page container">
          <div className="clear-div-m" />
          {this.renderIneligibilityReason()}
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  error: state.error
});

NotEligible.propTypes = {
  error: PropTypes.object
};

NotEligible.defaultProps = {
  error: {}
};

export default withRouter(connect(mapStateToProps)(NotEligible));
