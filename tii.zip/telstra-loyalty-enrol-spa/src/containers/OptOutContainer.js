import { connect } from 'react-redux';
import React, { Component } from 'react';

import OptOutView from 'views/OptOut/OptOut';
import OptOutNotEnrolledView from 'views/OptOut/NotEnrolled';
import OptOutIssueView from 'views/OptOut/OptOutIssue';
import OptOutSuccessView from 'views/OptOut/SuccessfulOptOut';
import Spinner from 'components/LoadingSpinner/Spinner';
import {unenrolPhrases} from 'constants/loadingSpinnerMessages';

import AppLog from 'utils/AppLog';
import * as Analytics from 'utils/analytics';
import * as actions from 'constants/actions';

import unenrolUser from 'actions/optOut';

class OptOutContainer extends Component {
  constructor(props) {
    super(props);
    this.log = new AppLog('OptOutContainer');
  }

  componentDidMount() {
    this.log.debug('OptOut Container mounted');
    Analytics.setPageName('OptOut Page');
  }

  handleOptOut = () => {
    const token = sessionStorage.getItem('accessToken');
    this.log.debug('handle Opt ', this.props);
    this.props.dispatch(this.props.actions.unenroleUser(token));
  };

  render() {
    const {
      optOut: { isLoading, optOutResult },
      enrolment: { enrolled }
    } = this.props;

    if(isLoading){
      return <Spinner displays={unenrolPhrases} />
    } else if (optOutResult === null) {
      // load initial views
      if (enrolled) {
        return <OptOutView handleOptOut={this.handleOptOut} />;
      }
      return <OptOutNotEnrolledView />;
    }
    if (optOutResult === actions.OPTOUT_RESULT_SUCCESS) {
      return <OptOutSuccessView />;
    }
    if (optOutResult === actions.OPTOUT_RESULT_NOT_ENROLLED) {
      return <OptOutNotEnrolledView />;
    }
    if (optOutResult === actions.OPTOUT_RESULT_FAIL) {
      return <OptOutIssueView handleOptOut={this.handleOptOut} />;
    }
    // todo - jack - return error page
  }
}

const mapStateToProps = state => ({
  enrolment: state.enrolment,
  optOut: state.optOut,
  actions: {
    unenroleUser: unenrolUser
  }
});

export default connect(mapStateToProps)(OptOutContainer);
