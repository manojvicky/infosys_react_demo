import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import PointsView from 'views/PointsView';
import PageTitle from 'components/PageTitle';

import AppLog from 'utils/AppLog';
import * as Analytics from 'utils/analytics';

import PointsHeader from 'assets/images/PointsHeader@2x.jpg';
import PointsHeaderMobile from 'assets/images/PointsHeaderMobile.png';

class PointsContainer extends Component {
  constructor() {
    super();
    this.log = new AppLog('PointsContainer');
  }

  componentDidMount() {
    this.log.debug('Points Container mounted');
    Analytics.setPageName('Points Page');
  }

  render() {
    const heading = 'View your point activity';

    return (
      <Fragment>
        <PageTitle
          miniHeader="Points"
          heroImage={PointsHeader}
          mobileImage={PointsHeaderMobile}
          calloutHeader={heading}
        />
        <PointsView />
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  points: state.points
});

export default withRouter(connect(mapStateToProps)(PointsContainer));

PointsContainer.propTypes = {
  points: PropTypes.shape({
    points: PropTypes.number
  })
};

PointsContainer.defaultProps = {
  points: 100
};
