import PointsContainer from './PointsContainer';

export default PointsContainer;
