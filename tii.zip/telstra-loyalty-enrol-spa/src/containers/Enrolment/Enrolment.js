import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ReactRouterPropTypes from 'react-router-prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import _ from 'lodash';

import * as Analytics from 'utils/analytics';
import AppLog from 'utils/AppLog';

import * as ERRCODES from 'constants/errorCodes.js';
import * as ERRMSGS from 'constants/errorMessages.js';

import {
  SET_ELIGIBLE,
  SET_ENROLLED,
  SET_ENROLLING,
  SET_ERROR,
  SET_ENROLFAILED,
  GET_POINTS_PENDING,
  GET_POINTS_SUCCESS,
  GET_POINTS_FAILURE,
  SET_INITIAL_POINTS
} from 'constants/actions';

import EnrolmentView from 'views/EnrolmentView';

import registerApi from 'api/register';
import getPoints from 'api/getPoints';

class Enrolment extends Component {
  constructor() {
    super();
    this.log = new AppLog('Enrolment');
  }

  componentDidMount() {
    Analytics.setPageName('Enrolment - Join Telstra Plus');
    Analytics.addEvent('loyaltyEnrolmentView');
  }

  handleEnrolment = () => {
    const { dispatch, history } = this.props;
    dispatch({ type: SET_ENROLLING, enrolling: true });
    const token = sessionStorage.getItem('accessToken');
    this.log.debug('accessToken for enrolment: ', token);

    registerApi(token)
      .then(response => {
        this.log.debug('Register Resp:', response);

        // Connection timed-out
        if (response.code === ERRCODES.ERR_CONNABORTED) {
          this.log.debug('Request cancelled');
          dispatch({
            type: SET_ERROR,
            hasErrored: true,
            errorMessage: ERRMSGS.REGISTRATIONERROR
          });
          history.push('/error');
          return;
        }

        // Server Returned a 200 Response
        if (_.has(response, 'data')) {
          this.log.debug('Successful Enrolment Response');
          dispatch({ type: SET_ENROLLED, enrolled: true });

          let cacList = '';
          response.data.data.accounts.forEach(cac => {
            cacList = `${cacList}${cac.accountId},`;
          });

          cacList = cacList.substring(0, cacList.length - 1);

          Analytics.setPageName('Member Landing Page');
          Analytics.addEvent('loyaltyEnrolComplete');
          // POINTS RETRIEVAL
          dispatch({ type: GET_POINTS_PENDING });

          getPoints(token, cacList)
            .then(pointResponse => {
              this.log.debug('GetPoints Response: ', pointResponse);
              dispatch({
                type: GET_POINTS_SUCCESS,
                pointResponse
              });
              const orderedAcc = _.orderBy(
                pointResponse.data.loyalty.accounts,
                ['accountId'],
                ['dsc']
              );

              dispatch({
                type: SET_INITIAL_POINTS,
                pointsValue: orderedAcc[0].points.loyaltyPoints
              });
              history.push('/success');
            })
            .catch(error => {
              this.log.error('Caught getPoints error: ', error);
              dispatch({ type: GET_POINTS_FAILURE });
            });
        }
      })
      .then(() => {
        this.log.debug('Final enrolment THEN');
        dispatch({ type: SET_ENROLLING, enrolling: false });
      })
      .catch(error => {
        this.log.debug('Caught error is: ', error);

        if (typeof error.response !== 'undefined') {
          this.log.debug('enrolment response', error);

          const { code } = error.response.data;

          this.log.debug('Server error', code);

          if (code === ERRCODES.ERR_LA_CAC) {
            // Limited Authority && No Active Service Accounts
            Analytics.setPageName('Not Eligible - Limited Authority');
            dispatch({
              type: SET_ELIGIBLE,
              eligible: false,
              getDetails: error.response.data
            });
            dispatch({ type: SET_ENROLLED, enrolled: false });
            dispatch({ type: SET_ERROR, errorStatusCode: code });

            history.push('/not-eligible');
          } else if (code === ERRCODES.ERR_ALREADY_ENROLLED) {
            // Already Enrolled
            // Setting Enrolled here will push the error screen with an already enrolled messaged
            // from the API and a Link to go to the Plus Homepage

            dispatch({ type: SET_ENROLLED, enrolled: true });
            dispatch({
              type: SET_ERROR,
              hasErrored: true,
              errorMessage: ERRMSGS.ALREADYENROLLED,
              errorStatusCode: code
            });
            // Analytics.setPageName('Already Enrolled Error');
            // history.push('/error');
          } else {
            // Setting enrolFailed to true will display the error screen with a retry button
            // To retry the enrolment call

            dispatch({
              type: SET_ERROR,
              hasErrored: true,
              errorMessage: ERRMSGS.REGISTRATIONERROR,
              errorStatusCode: code
            });

            dispatch({ type: SET_ENROLFAILED, enrolFailed: true });
            Analytics.setPageName('Enrolment Error');
            history.push('/error');
          }
        } else {
          // Setting enrolFailed to true will display the error screen with a retry button
          // To retry the enrolment call

          dispatch({
            type: SET_ERROR,
            hasErrored: true,
            errorMessage: ERRMSGS.REGISTRATIONERROR
          });

          dispatch({ type: SET_ENROLFAILED, enrolFailed: true });
          Analytics.setPageName('Enrolment Error');
          history.push('/error');
        }
        dispatch({
          type: SET_ENROLLING,
          enrolling: false
        });
      });
  };

  render() {
    return <EnrolmentView handleEnrolment={() => this.handleEnrolment()} />;
  }
}

const mapStateToProps = state => ({
  app: state.app,
  error: state.error
});

export default withRouter(connect(mapStateToProps)(Enrolment));

Enrolment.propTypes = {
  dispatch: PropTypes.func,
  history: ReactRouterPropTypes.history.isRequired
};

Enrolment.defaultProps = {
  dispatch: {}
};
