import Enrolment from './Enrolment.js';

export default Enrolment;
