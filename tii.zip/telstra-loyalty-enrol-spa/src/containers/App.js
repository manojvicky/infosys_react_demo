import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
// Dev Components
import ScrollToTop from 'components/ScrollToTop';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import _ from 'lodash';
import { signIn, completeAuthentication } from 'oidc/initiateOidc';
import scrollToElement from 'scroll-to-element';

// App-wide Presentational Components
import Header from 'components/Header';
import Footer from 'components/Footer/Footer';
import LoadingSpinner from 'components/LoadingSpinner/LoadingSpinner';
import Breadcrumbs from 'components/Breadcrumbs';

import AppLog from 'utils/AppLog';

// Constants
import {
  SET_AUTHENTICATED,
  SET_AUTH_PREFLIGHT,
  SET_INITIALISED,
  SET_ORIGINURL
} from 'constants/actions';

// Top level container
class App extends Component {
  constructor(props) {
    super(props);
    this.log = new AppLog('App');
  }

  componentDidMount() {
    this.log.debug('App Mounted. ', this.props);

    const { dispatch } = this.props;
    const { authenticated } = this.props.app;

    const LOCAL_STORAGE_LOCATION_REF = 'telstraPlusPrevLocation';

    // Determine if coming from caiman
    if (_.has(window.location, 'search') && !authenticated) {
      this.log.debug(window.location.search.substring(1));

      const isAuthPreflight =
        window.location.search.substring(1).indexOf('code=') >= 0;

      if (!isAuthPreflight) {
        this.log.debug('setting location obj in local state');
        localStorage.setItem(
          LOCAL_STORAGE_LOCATION_REF,
          JSON.stringify(window.location)
        );
      } else {
        dispatch({ type: SET_AUTH_PREFLIGHT, authPreFlight: true });

        // complete auth flow
        completeAuthentication()
          .then(() => {
            window.history.replaceState({}, document.title, '/');
            dispatch({ type: SET_AUTHENTICATED, authenticated: true });
          })
          .catch(err => {
            window.history.replaceState({}, document.title, '/');
            console.log('auth err: ', err);
          });

        // retrieve the original URL from localstorage
        const prevOrigin = localStorage.getItem(LOCAL_STORAGE_LOCATION_REF);

        if (prevOrigin !== null) {
          this.log.debug('original location obj: ', JSON.parse(prevOrigin));

          dispatch({ type: SET_ORIGINURL, originUrl: JSON.parse(prevOrigin) });

          // clean the localstorage
          localStorage.removeItem(LOCAL_STORAGE_LOCATION_REF);
        }
      }
    }
    dispatch({ type: SET_INITIALISED, initialised: true });
  }

  // Store the previousLocation in a global var so other components can access it
  componentWillReceiveProps() {
    window.previousLocation = this.props.location;
  }

  componentDidUpdate() {
    this.jumpToHash();
  }

  jumpToHash = () => {
    const { hash } = window.location;
    if (hash) {
      scrollToElement(hash, { offset: -120 });
    }
  };

  // To catch the conditional header eslint error thats caused by indents
  render() {
    const {
      app: { initialised, authenticated, authPreFlight },
      enrolment: { enrolling }
    } = this.props;

    if (initialised && !authenticated && !authPreFlight) {
      return signIn();
    }

    if (initialised && enrolling) {
      return (
        <Fragment>
          <LoadingSpinner />
        </Fragment>
      );
    }

    if (initialised && authenticated) {
      return (
        <Fragment>
          <Header />
          <Fragment>
            <Breadcrumbs />
            <ScrollToTop>{this.props.children}</ScrollToTop>
          </Fragment>
          <Footer />
        </Fragment>
      );
    }
    return null;
  }
}

const mapStateToProps = state => ({
  app: state.app,
  error: state.error,
  enrolment: state.enrolment
});

export default withRouter(connect(mapStateToProps)(App));

App.propTypes = {
  app: PropTypes.shape({
    initialised: PropTypes.bool.isRequired,
    authenticated: PropTypes.bool.isRequired,
    authPreFlight: PropTypes.bool.isRequired,
    originUrl: PropTypes.object
  }),
  children: PropTypes.node,
  location: PropTypes.shape({
    pathname: PropTypes.string.isRequired
  }).isRequired,
  enrolment: PropTypes.shape({
    enrolling: PropTypes.bool
  }),
  dispatch: PropTypes.func
};

App.defaultProps = {
  app: {
    initialised: false,
    authenticated: false,
    originUrl: {}
  },
  children: null,
  enrolment: {
    enrolling: false
  },
  dispatch: () => {}
};
