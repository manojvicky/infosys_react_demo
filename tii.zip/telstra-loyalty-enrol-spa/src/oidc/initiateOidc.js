import { UserManager } from '../../node_modules/oidc-client';
import { oidcConfig } from './oidc-configs';

const manager = new UserManager(oidcConfig);
let user = null;

export function signIn() {
  manager.signinRedirect();
}

export function signOut() {
  window.location.href = oidcConfig.post_logout_redirect_uri;
}

// ==============================================
// Auth token flow helper functions
//
export function isLoggedIn() {
  return user != null && !user.expired;
}

export function startAuthentication() {
  manager.clearStaleState(null).then(() => {
    const args = {};
    manager.signinRedirect(args);
  });
}

export function completeAuthentication() {
  return manager.signinRedirectCallback().then(passedUser => {
    user = passedUser;
    return user;
  });
}

export function getAuthorizationToken() {
  return user.access_token;
}
