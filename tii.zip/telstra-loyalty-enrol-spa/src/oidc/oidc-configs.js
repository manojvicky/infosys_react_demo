import configDev from 'env/config.dev.json';
import configDevMocks from 'env/config.dev-mocks.json';
import configCI from 'env/config.ci.json';
import configNonProd from 'env/config.nonprod.json';
import configProd from 'env/config.prod.json';
import configPreProd from 'env/config.preprod.json';

let config; // YUCK: 'let'

// TODO - SHOULD USE DOT ENV OR SOMETHING SIMILAR TO LOAD CONFIGS
switch (process.env.REACT_APP_CAIMAN_CONF) {
  case 'dev':
    config = configDev;
    break;
  case 'dev-mocks':
    config = configDevMocks;
    break;
  case 'ci':
    config = configCI;
    break;
  case 'nonprod':
    config = configNonProd;
    break;
  case 'production':
    config = configProd;
    break;
  case 'preprod':
    config = configPreProd;
    break;
  default:
    config = configProd;
}

export const apiConfig = config.api;
export const oidcConfig = config.oidc;
