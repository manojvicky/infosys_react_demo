import 'react-app-polyfill/ie9';

import React from 'react';
import { render } from 'react-dom';
import * as serviceWorker from 'containers/serviceWorker';
import _ from 'lodash';
import Root from 'containers/Root';
import './styles/base.scss';

const IN_DEVELOP = process.env.REACT_APP_ENV === 'dev';

// init empty analytics object
window.digitalData = {};

render(<Root />, document.getElementById('root'));

// Disabling CRA service workers
serviceWorker.unregister();

// Need to have this initialised within SPA, i.e. when it loads
// adding a timeout so it's not immediately triggered when loading the SPA
// i.e. before authentication redirect
setTimeout(() => {
  if (_.has(window, 'livePerson')) {
    window.livePerson.init({
      section: ['telstra', 'telstra-plus'],
      sourceSection: ['myacc'],
      onlyTcomCSS: true,
      forceButtonCss: true,
      persistentChat: true,
      persistentSection: ['telstra', 'telstra-plus', 'consumer', 'dtq']
      // callBack() {
      //   // (Optional if not passed no callback will called)function need to called in interval if event is resume or waiting
      //   console.log('CallBack called');
      // },
      // callBackInterval: 2 // interval in second (default: 1 second)
    });
  }
}, 2000);

if (_.has(window, '_satellite')) {
  // eslint-disable-next-line
  window._satellite.pageBottom();
}

// Webpack Hot Module Replacement API
if (IN_DEVELOP) {
  module.hot.accept('./containers/App', () => {
    render();
  });
}
