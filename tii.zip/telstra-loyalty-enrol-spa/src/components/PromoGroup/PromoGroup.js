import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import Slider from 'react-slick';

import './PromoGroup.scss';

const settings = {
  dots: true,
  infinite: false,
  speed: 500,
  slidesToShow: 1,
  slidesToScroll: 1,
  className: 'focused-slide',
  centerMode: true,
  centerPadding: '20px'
};

class PromoGroup extends Component {
  constructor(props) {
    super(props);
    this.props = props;
  }

  getTileAmount = tileAmount => {
    switch (tileAmount) {
      case 3:
        return 'three-tiles';
      case 4:
        return 'four-tiles';
      default:
        return 'vertical-tiles';
    }
  };

  render() {
    return (
      <Fragment>
        <div
          className={`promo-group ${this.getTileAmount(this.props.tileAmount)}`}
        >
          <div className="promo-group-heading">
            {this.props.heading && (
              <h2 className="heading">{this.props.heading}</h2>
            )}
            {this.props.copy && <h3>{this.props.copy}</h3>}
          </div>
        </div>
        <div
          className={`promo-group hidden-xs ${this.getTileAmount(
            this.props.tileAmount
          )}`}
        >
          {/* dont know what kind of promo coming in */}
          {this.props.children}
        </div>
        <div className="max-width-container">
          <div className="tile-container visible-xs">
            <Slider {...settings}>{this.props.children}</Slider>
          </div>
        </div>
      </Fragment>
    );
  }
}

PromoGroup.propTypes = {
  heading: PropTypes.string,
  copy: PropTypes.string,
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node
  ]),
  tileAmount: PropTypes.number
};

PromoGroup.defaultProps = {
  heading: '',
  copy: '',
  children: [],
  tileAmount: 3
};

export default PromoGroup;
