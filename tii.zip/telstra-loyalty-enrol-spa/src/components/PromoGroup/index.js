import PromoGroup from './PromoGroup.js';

export default PromoGroup;
