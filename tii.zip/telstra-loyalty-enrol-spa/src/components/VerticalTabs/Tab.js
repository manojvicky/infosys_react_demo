import React, { Component } from 'react';
import PropTypes from 'prop-types';

import IconMinus from 'icons/IconMinus';

import TabContent from './TabContent';
import './VerticalTabs.scss';

export default class Tab extends Component {
  constructor(props) {
    super(props);

    this.titleRef = React.createRef();
    this.state = {
      checked: false,
      contentClasses: 'vertical-tab-hidden'
    };
  }

  componentDidMount() {
    this.openAndScrollIfHash();
  }

  componentWillUnmount() {
    clearTimeout(this.scrollTimer);
  }

  openAndScrollIfHash = () => {
    const { id } = this.props;
    const { hash } = window.location;

    if (id && hash && hash === `#${id}`) {
      this.scrollTimer = setTimeout(() => {
        this.toggleTab();
      }, 200);
    }
  };

  toggleTab = () => {
    const { checked } = this.state;
    if (checked) {
      this.titleRef.current.setAttribute('aria-expanded', false);
      this.setState({
        checked: false,
        contentClasses: ''
      });

      setTimeout(() => {
        this.setState({
          contentClasses: 'vertical-tab-hidden'
        });
      }, 500);
    } else {
      // TODO
      // get height of content element
      // .vertical-tab-content
      this.titleRef.current.setAttribute('aria-expanded', true);
      this.setState({
        checked: true,
        contentClasses: 'vertical-tab-active'
      });
    }
  };

  getContentSectionId = id => `${id}-vertical-content-id`;

  render() {
    const { title, description, id } = this.props;

    const { contentClasses, checked } = this.state;

    return (
      <section className="vertical-tab-section">
        <div className="vertical-content">
          <div className={`rewards-vertical-tab-accordion ${contentClasses}`}>
            <h3 className="tab-title-container">
              <button
                name={id}
                type="button"
                aria-expanded="false"
                aria-controls={this.getContentSectionId(id)}
                ref={this.titleRef}
                id={id}
                onClick={this.toggleTab}
                className="vertical-tab-title"
              >
                {title}

                <span className="accordion-open-icon tcom-icon-12">
                  <IconMinus />
                </span>
                <span className="accordion-close-icon tcom-icon-12">
                  <IconMinus />
                </span>
              </button>
            </h3>

            <TabContent
              content={description}
              refererId={id}
              id={this.getContentSectionId(id)}
              open={checked}
            />
          </div>
        </div>
      </section>
    );
  }
}

TabContent.propTypes = {
  open: PropTypes.bool.isRequired,
  content: PropTypes.string.isRequired,
  id: PropTypes.string.isRequired,
  refererId: PropTypes.string
};

TabContent.defaultProps = {
  refererId: ''
};
