import React from 'react';
import PropTypes from 'prop-types';
import './VerticalTabs.scss';
import IconArrow from 'icons/IconArrow';
import Tab from './Tab';

const VerticalTabs = ({ title, tabs, footer }) => (
  <article className="rewards-tabs-wrapper">
    {title && <h2 className="vertical-tab-heading">{title}</h2>}

    <div className="vertical-tab-body">
      {tabs.map(tab => (
        <Tab
          id={tab.id}
          title={tab.title}
          description={tab.description}
          key={tab.title}
        />
      ))}
    </div>

    {footer && footer.text && (
      <a
        target={footer.targetNewWindow === 'true' ? '_blank' : null}
        className="primary-cta-18"
        href={footer.url}
      >
        {footer.text} <IconArrow />
      </a>
    )}
  </article>
);

export default VerticalTabs;

VerticalTabs.propTypes = {
  title: PropTypes.string.isRequired,
  footer: PropTypes.shape({
    url: PropTypes.string,
    text: PropTypes.string,
    targetNewWindow: PropTypes.string
  }),
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string.isRequired,
      description: PropTypes.string.isRequired
    })
  ).isRequired
};

VerticalTabs.defaultProps = {
  footer: {
    url: '',
    text: '',
    targetNewWindow: ''
  }
};
