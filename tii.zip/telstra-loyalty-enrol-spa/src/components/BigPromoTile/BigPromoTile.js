import IconArrow from 'icons/IconArrow';
import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import renderHTML from 'react-render-html';

import IconVIPServices from 'icons/IconVIPServices';
import IconTickets from 'icons/IconTickets';
import IconExtras from 'icons/IconExtras';
import IconEarnPoints from 'icons/IconEarnPoints';
import IconMobile from 'icons/IconMobile';

import './BigPromoTile.scss';

class BigPromoTile extends React.Component {
  renderIcon = () => {
    const { icon } = this.props;

    switch (icon) {
      case 'VIPServices':
        return <IconVIPServices />;
      case 'Tickets':
        return <IconTickets />;
      case 'Extras':
        return <IconExtras />;
      case 'EarnPoints':
        return <IconEarnPoints />;
      default:
        return <IconExtras />;
    }
  };

  renderLozenge = () => {
    const { tier } = this.props;
    switch (tier.toUpperCase()) {
      case 'MEMBER':
        return '#a0148c';
      case 'SILVER':
        return '#767676';
      case 'GOLD':
        return '#93713b';
      default:
        return '#FF2896';
    }
  };

  render() {
    const {
      imagePath,
      mobileImagePath,
      imageAltText,
      leftImage,
      promoCopy,
      promoSubCopy,
      icon,
      dateAvailable,
      iconTitle,
      promoTitle,
      url,
      buttonText,
      techSupport,
      hasLozenge,
      lozengeText,
      tier,
      isVerticalTile
    } = this.props;

    return (
      <Fragment>
        <div
          className={`promo-container ${
            !leftImage ? `promo-container-right` : ''
          }
            ${isVerticalTile ? `promo-container-50` : ''}`}
        >
          <div className="image-wrapper promo-image-mobile">
            <img src={imagePath || mobileImagePath} alt={imageAltText} />
            {hasLozenge && (
              <div
                style={{
                  backgroundColor: this.renderLozenge()
                }}
                className={`call-out-block ${leftImage ? 'push-right' : ''}`}
              >
                <p>
                  {lozengeText ||
                    `${tier.charAt(0).toUpperCase() +
                      tier.toLowerCase().slice(1)} tier benefit`}
                </p>
              </div>
            )}
          </div>
          <div className="image-wrapper promo-image">
            <img src={imagePath} alt={imageAltText} />
            {hasLozenge && (
              <div
                style={{
                  backgroundColor: this.renderLozenge()
                }}
                className="call-out-block"
              >
                <p>
                  {lozengeText ||
                    `${tier.charAt(0).toUpperCase() +
                      tier.toLowerCase().slice(1)} tier benefit`}
                </p>
              </div>
            )}
          </div>
          <div className="promo-content">
            <p className="promo-heading-small heading-16">
              {icon && this.renderIcon()} {iconTitle}{' '}
              {dateAvailable && `| ${dateAvailable}`}
            </p>
            <h2 className="promo-heading heading-34 heading-lg-44">
              {renderHTML(promoTitle)}
            </h2>
            <p className="body-copy-18 body-copy-md-20 body-copy-lg-22 promo-copy">
              {renderHTML(promoCopy)}
            </p>
            <p className="promo-terms-conditions body-copy-14 body-copy-light-color">
              {promoSubCopy}
            </p>
            {techSupport && (
              <div className="tech-support-container">
                <span>
                  <IconMobile />
                  <p>Call 13 22 00</p>
                </span>
              </div>
            )}
            <div className="promo-links-container">
              <div className="promo-link">
                <a
                  role="button"
                  aria-pressed="false"
                  className="primary-cta-18"
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {buttonText} {buttonText ? <IconArrow /> : ''}
                </a>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

BigPromoTile.propTypes = {
  dateAvailable: PropTypes.string,
  promoTitle: PropTypes.string,
  promoCopy: PropTypes.string,
  promoSubCopy: PropTypes.string,
  buttonText: PropTypes.string,
  imageAltText: PropTypes.string,
  imagePath: PropTypes.string,
  url: PropTypes.string,
  leftImage: PropTypes.bool,
  techSupport: PropTypes.bool,
  lozengeText: PropTypes.string,
  hasLozenge: PropTypes.bool,
  icon: PropTypes.string,
  iconTitle: PropTypes.string,
  tier: PropTypes.string,
  isVerticalTile: PropTypes.bool
};

BigPromoTile.defaultProps = {
  dateAvailable: null,
  promoTitle: 'Promo Title',
  promoCopy: 'Promo copy',
  promoSubCopy: '',
  buttonText: '',
  imageAltText: 'Alt text for image',
  imagePath: '',
  leftImage: false,
  hasLozenge: false,
  lozengeText: '',
  url: 'urlpath',
  icon: 'Extras',
  iconTitle: 'Extras',
  techSupport: false,
  tier: '',
  isVerticalTile: false
};

export default BigPromoTile;
