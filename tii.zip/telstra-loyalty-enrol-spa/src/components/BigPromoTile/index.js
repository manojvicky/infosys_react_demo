import BigPromoTile from './BigPromoTile.js';

export default BigPromoTile;
