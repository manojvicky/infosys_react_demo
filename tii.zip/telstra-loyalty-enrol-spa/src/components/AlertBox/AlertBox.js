import React from 'react';

import './AlertBox.scss';

const AlertBox = () => (
  <div className="alert-box">
    <p>
      Extras and VIP service benefits are not available for limited authority.
      <a
        target="_blank"
        rel="noopener noreferrer"
        href="https://www.telstra.com.au/plus/frequently-asked-questions#every-one-on-the-account"
      >
        Learn more
      </a>
    </p>
  </div>
);

export default AlertBox;
