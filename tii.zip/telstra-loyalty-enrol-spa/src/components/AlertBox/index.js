import AlertBox from './AlertBox.js';

export default AlertBox;
