import PromoTile from './PromoTile.js';

export default PromoTile;
