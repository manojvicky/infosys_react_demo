import React from 'react';
import PropTypes from 'prop-types';

import './PromoTile.scss';

const PromoTile = ({ imagePath, imageAltText, title, subTitle, text }) => (
  <div className="plus-promo-tile">
    <h2>{title}</h2>

    <div className="clear-div-l" />

    <img src={imagePath} alt={imageAltText} />

    <div className="clear-div-l" />

    <h3>{subTitle}</h3>

    <div className="clear-div-xs" />

    <p>{text}</p>

    <div className="clear-div-l" />
  </div>
);

export default PromoTile;

PromoTile.propTypes = {
  title: PropTypes.string.isRequired,
  subTitle: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
  imageAltText: PropTypes.string.isRequired,
  imagePath: PropTypes.string.isRequired
};
