import VerticalPromoTile from './VerticalPromoTile.js';

export default VerticalPromoTile;
