import IconArrow from 'icons/IconArrow';
import React, { Fragment } from 'react';
import PropTypes from 'prop-types';

import IconVIPServices from 'icons/IconVIPServices';
import IconTickets from 'icons/IconTickets';
import IconExtras from 'icons/IconExtras';
import IconMobile from 'icons/IconMobile';
import IconTechSupport from 'icons/IconTechSupport';

import './VerticalPromoTile.scss';

class VerticalPromoTile extends React.Component {
  renderIcon = () => {
    const { icon } = this.props;

    switch (icon) {
      case 'VIPServices':
        return <IconVIPServices />;
      case 'Tickets':
        return <IconTickets />;
      case 'Extras':
        return <IconExtras />;
      default:
        return <IconExtras />;
    }
  };

  renderLozenge = () => {
    const { tier } = this.props;
    switch (tier.toUpperCase()) {
      case 'MEMBER':
        return '#a0148c';
      case 'SILVER':
        return '#767676';
      case 'GOLD':
        return '#93713b';
      default:
        return '#FF2896';
    }
  };

  render() {
    const {
      imagePath,
      mobileImagePath,
      imageAltText,
      leftImage,
      promoCopy,
      promoSubCopy,
      icon,
      iconTitle,
      promoTitle,
      url,
      buttonText,
      techSupport,
      hasLozenge,
      lozengeText,
      tier
    } = this.props;
    return (
      <Fragment>
        <div className="promo-container promo-container-50">
          <div className="image-wrapper promo-image-mobile">
            {hasLozenge && (
              <div
                style={{ backgroundColor: this.renderLozenge() }}
                className="lozenge"
              >
                <p>{lozengeText || `${tier} tier benefit`}</p>
              </div>
            )}
            <figure aria-labelledby="promo-image-caption">
              <img alt={imageAltText} src={mobileImagePath || imagePath} />
            </figure>
            <figcaption className="sr-only" id="promo-image-caption">
              {imageAltText}
            </figcaption>
          </div>
          <div className="image-wrapper promo-image">
            {hasLozenge && (
              <div
                style={{ backgroundColor: this.renderLozenge() }}
                className="lozenge"
              >
                <p>{lozengeText || `${tier} tier benefit`}</p>
              </div>
            )}
            <figure aria-labelledby="promo-image-caption">
              <img alt={imageAltText} src={imagePath} />
            </figure>
            <figcaption className="sr-only" id="promo-image-caption">
              {imageAltText}
            </figcaption>
          </div>
          <div className="promo-content">
            <span className="promo-heading-small">
              {icon && this.renderIcon()} {iconTitle}
            </span>
            <h3 className="promo-heading">{promoTitle}</h3>
            <p className="body-copy-18 body-copy-md-20 body-copy-lg-22 promo-copy">
              {promoCopy}
            </p>
            {promoSubCopy && <p className="promo-footnote">{promoSubCopy}</p>}
            {techSupport ? (
              <div className="tech-support-container">
                <span>
                  <IconTechSupport />
                  <a className="" href="http://www.telstra.com.au/support">
                    Chat with tech support
                  </a>
                </span>
                <span>
                  <IconMobile />
                  <a className="" href="http://www.telstra.com.au/support">
                    Call 13 75 87
                  </a>
                </span>
              </div>
            ) : (
              <div className="promo-links-container">
                <a
                  role="button"
                  aria-pressed="false"
                  className="primary-cta-18"
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {buttonText} {buttonText ? <IconArrow /> : ''}
                </a>
              </div>
            )}
          </div>
        </div>
      </Fragment>
    );
  }
}

VerticalPromoTile.propTypes = {
  promoTitle: PropTypes.string,
  promoCopy: PropTypes.string,
  buttonText: PropTypes.string,
  promoSubCopy: PropTypes.string,
  imageAltText: PropTypes.string,
  imagePath: PropTypes.string,
  mobileImagePath: PropTypes.string,
  url: PropTypes.string,
  leftImage: PropTypes.bool,
  techSupport: PropTypes.bool,
  hasLozenge: PropTypes.bool,
  lozengeText: PropTypes.string,
  icon: PropTypes.string,
  iconTitle: PropTypes.string,
  tier: PropTypes.string
};

VerticalPromoTile.defaultProps = {
  promoTitle: 'Promo Title',
  promoCopy: 'Promo copy',
  promoSubCopy: '',
  buttonText: 'Button Text',
  imageAltText: 'Alt text for image',
  imagePath: '',
  mobileImagePath: '',
  leftImage: false,
  hasLozenge: false,
  lozengeText: '',
  url: 'urlpath',
  icon: 'Extras',
  iconTitle: 'Extras',
  techSupport: false,
  tier: ''
};

export default VerticalPromoTile;
