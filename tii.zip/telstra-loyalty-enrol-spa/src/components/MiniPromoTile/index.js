import MiniPromoTile from './MiniPromoTile.js';

export default MiniPromoTile;
