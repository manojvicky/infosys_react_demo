import React from 'react';
import PropTypes from 'prop-types';
import IconArrow from 'icons/IconArrow';

import './MiniPromoTile.scss';

const MiniPromoTile = ({
  imagePath,
  imageAltText,
  promoCopy,
  promoSmallTitle,
  promoTitle,
  url,
  buttonText
}) => (
  <div className="mini-promo-tile">
    <img className="tile-image" src={imagePath} alt={imageAltText} />
    <h5>{promoSmallTitle}</h5>
    <h3>{promoTitle}</h3>
    <p>{promoCopy}</p>
    {buttonText && (
      <a
        role="button"
        aria-pressed="false"
        className="primary-cta-18 see-all-btn"
        href={url}
        target="_blank"
        rel="noopener noreferrer"
      >
        {buttonText} {buttonText ? <IconArrow /> : ''}
      </a>
    )}
  </div>
);

MiniPromoTile.propTypes = {
  promoTitle: PropTypes.string,
  promoSmallTitle: PropTypes.string,
  promoCopy: PropTypes.string,
  buttonText: PropTypes.string,
  imageAltText: PropTypes.string,
  imagePath: PropTypes.string,
  url: PropTypes.string
};

MiniPromoTile.defaultProps = {
  promoTitle: 'Mini promo title',
  promoSmallTitle: '',
  promoCopy: '',
  buttonText: '',
  imageAltText: 'Image alt text',
  imagePath: 'Image path',
  url: 'URL Path'
};

export default MiniPromoTile;
