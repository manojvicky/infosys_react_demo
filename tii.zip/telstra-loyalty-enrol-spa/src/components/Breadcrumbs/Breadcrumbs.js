import React, { Fragment } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

import './Breadcrumbs.scss';
import IconChevron from 'icons/IconChevron';

const { REACT_APP_PLUS_HOME_URL, REACT_APP_MY_ACCOUNT_HOME_URL } = process.env;

class Breadcrumbs extends React.Component {
  renderHomeCrumbs = () => {
    return (
      <Fragment>
        <div className="visible-xs">
          <span className="chevron left">
            <IconChevron />
          </span>
          <a href={REACT_APP_MY_ACCOUNT_HOME_URL}>Back to My Account</a>
        </div>
        <div className="hidden-xs">
          <a className="underline" href={REACT_APP_MY_ACCOUNT_HOME_URL}>
            My Account
          </a>
          <span className="chevron">
            <IconChevron />
          </span>
          <span className="current-location">Telstra Plus</span>
        </div>
      </Fragment>
    );
  };

  renderJoinCrumbs = (homeURL, homeDisplayText) => {
    return (
      <Fragment>
        <div className="visible-xs">
          <span className="chevron left">
            <IconChevron />
          </span>
          <a href={REACT_APP_MY_ACCOUNT_HOME_URL}>Back to My Account</a>
        </div>
        <div className="hidden-xs">
          <a className="underline" href={REACT_APP_MY_ACCOUNT_HOME_URL}>
            My Account
          </a>
          <span className="chevron">
            <IconChevron />
          </span>
          <a className="underline" href={homeURL}>
            {homeDisplayText}
          </a>
          <span className="chevron">
            <IconChevron />
          </span>
          <span className="current-location">Join Telstra Plus</span>
        </div>
      </Fragment>
    );
  };

  renderErrorCrumbs = (homeURL, homeDisplayText) => {
    return (
      <Fragment>
        <div className="visible-xs">
          <span className="chevron left">
            <IconChevron />
          </span>
          <a href={homeURL}>{`Back to ${homeDisplayText}`}</a>
        </div>
        <div className="hidden-xs">
          <a className="underline" href="https://www.telstra.com.au">
            Home
          </a>
          <span className="chevron">
            <IconChevron />
          </span>
          <a className="underline" href={homeURL}>
            {homeDisplayText}
          </a>
        </div>
      </Fragment>
    );
  };

  render() {
    const { location } = this.props;
    // const { eligible, enrolled } = this.props.app;

    const homeURL = REACT_APP_PLUS_HOME_URL;
    const homeDisplayText = 'Telstra Plus';

    const currentLocation = location.pathname.replace(/^\/+/g, '');
    if (currentLocation === 'join') {
      return (
        <Fragment>
          <div className="container">
            <div className="plus-breadcrumbs">
              {this.renderJoinCrumbs(homeURL, homeDisplayText)}
            </div>
          </div>
        </Fragment>
      );
    }

    if (currentLocation === 'not-eligible') {
      return (
        <Fragment>
          <div className="container">
            <div className="plus-breadcrumbs">
              {this.renderJoinCrumbs(homeURL, homeDisplayText)}
            </div>
          </div>
        </Fragment>
      );
    }

    if (currentLocation === 'error') {
      return (
        <Fragment>
          <div className="container">
            <div className="plus-breadcrumbs">
              {this.renderErrorCrumbs(homeURL, homeDisplayText)}
            </div>
          </div>
        </Fragment>
      );
    }

    if (currentLocation === 'home') {
      return (
        <Fragment>
          <div className="container">
            <div className="plus-breadcrumbs">
              {this.renderHomeCrumbs(homeURL, homeDisplayText)}
            </div>
          </div>
        </Fragment>
      );
    }

    return null;
  }
}
const mapStateToProps = state => ({
  app: state.app
});

export default withRouter(connect(mapStateToProps)(Breadcrumbs));

Breadcrumbs.propTypes = {
  location: PropTypes.shape({
    hash: PropTypes.string.isRequired,
    search: PropTypes.string.isRequired
  }).isRequired
};
