import React, { Component, Fragment } from 'react';
import {genericPhrases} from 'constants/loadingSpinnerMessages';
import GenericUtil from 'utils/GenericUtil';
import PropTypes from 'prop-types';
import spinnerGIF from 'assets/images/Spinner.gif';

export default class Spinner extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displays: this.props.displays,
            displayIdx: 0
        };
        
        this.timmer = setInterval(()=>{
            let { displays, displayIdx } = this.state;
            this.setState({
                displayIdx: GenericUtil.getUpdateSingleCycleIndex(displayIdx, displays.length)
            });
        }, this.props.swapInterval);
    }

    render() {
        const { displays, displayIdx} = this.state;
        return (
            <Fragment>
                <div className="plus-loader">
                    <img src={spinnerGIF} alt="loading animation" />
                </div>
                {displays && (
                    <div className="loading-phrase" aria-live="polite">
                        <p>{displays[displayIdx]}</p>
                    </div>
                )}
            </Fragment>
        );
    }
}

Spinner.propTypes = {
    displays: PropTypes.array,
    swapInterval: PropTypes.number
};

Spinner.defaultProps = {
    displays: genericPhrases,
    swapInterval: 6000  //6seconds
};
  
