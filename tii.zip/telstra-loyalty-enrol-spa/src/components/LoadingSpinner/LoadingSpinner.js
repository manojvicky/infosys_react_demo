import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';

import './LoadingSpinner.scss';

import spinnerGIF from 'assets/images/Spinner.gif';

import {
  genericPhrases,
  enrollingPhrases,
  retryPhrases
} from 'constants/loadingSpinnerMessages.js';

class LoadingSpinner extends Component {
  state = {
    seconds: 6,
    beginPhrases: false,
    display: '',
    count: 0
  };

  componentDidMount() {
    this.timeout = setInterval(this.tick, 1000);
  }

  componentWillUnmount() {
    this.setState({
      seconds: 6,
      beginPhrases: false,
      display: '',
      count: 0
    });
    clearTimeout(this.timeout);
  }

  chooseNextPhrase = () => {
    const {
      eligibility: { hasCheckedEligibility },
      enrolment: { enrolling, enrolFailed }
    } = this.props;

    const { count } = this.state;

    let phraseList;

    if (enrolling) {
      phraseList = enrollingPhrases;
    }

    if (!hasCheckedEligibility) {
      phraseList = genericPhrases;
    }

    if (enrolFailed) {
      phraseList = retryPhrases;
    }

    if (count < phraseList.length) {
      const phraseToDisplay = phraseList[count];
      this.setState({
        display: phraseToDisplay,
        count: count + 1
      });
    } else {
      this.setState({
        count: 0
      });
    }
  };

  tick = () => {
    const { seconds } = this.state;

    if (seconds === 3) {
      this.setState({
        beginPhrases: true
      });
    }

    if (seconds === 1) {
      this.chooseNextPhrase();
      this.setState({
        seconds: 6
      });
    } else {
      this.setState({
        seconds: seconds - 1
      });
    }
  };

  render() {
    const { beginPhrases, display } = this.state;

    return (
      <Fragment>
        <div className="plus-loader">
          <img src={spinnerGIF} alt="loading animation" />
        </div>
        {beginPhrases && display && (
          <div className="loading-phrase" aria-live="polite">
            <p>{display}</p>
          </div>
        )}
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  enrolment: state.enrolment
});

export default withRouter(connect(mapStateToProps)(LoadingSpinner));

LoadingSpinner.propTypes = {
  enrolment: PropTypes.object,
  eligibility: PropTypes.object
};

LoadingSpinner.defaultProps = {
  enrolment: {},
  eligibility: {}
};
