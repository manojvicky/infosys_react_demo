import React from 'react';
import {shallow, mount} from 'enzyme';
import Spinner from './Spinner';
import { exportAllDeclaration } from '@babel/types';

describe('Spinner', ()=>{
    

    describe('show spinner', ()=>{
        let wrapper;
        beforeEach(()=>{
            wrapper = mount(<Spinner displays={['ABC','DEF', 'GHI']} swapInterval={100} />);
        });

        it('check if the loading gif is showing', ()=>{
            expect(wrapper.find("img").prop("src")).toContain('Spinner.gif');
        })
        it('check if the initial text is showing', ()=>{
            expect(wrapper.text()).toContain('ABC');
        });
        it('check if the second text is showing', (done)=>{
            setTimeout(()=>{
                expect(wrapper.text()).toContain('DEF');
                expect(wrapper.state('displayIdx')).toEqual(1);
                done();
            }, 150);
        });
        it('check if the third text is showing', (done)=>{
            setTimeout(()=>{
                expect(wrapper.text()).toContain('GHI');
                expect(wrapper.state('displayIdx')).toEqual(2);
                done();
            }, 250);
        });
        it('check if the no changes after final text', (done)=>{
            setTimeout(()=>{
                expect(wrapper.text()).toContain('GHI');
                expect(wrapper.state('displayIdx')).toEqual(2);
                done();
            }, 500);
        });

    })




});




