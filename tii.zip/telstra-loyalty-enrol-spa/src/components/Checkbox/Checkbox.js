import React from 'react';
import PropTypes from 'prop-types';
import './Checkbox.scss';

export default class Checkbox extends React.Component {
  componentDidMount() {
    const { indeterminate } = this.props;
    // Apply the indeterminate attribute of the checkbox input
    this.selector.indeterminate = indeterminate;
  }

  componentDidUpdate(prevProps) {
    const { indeterminate } = this.props;

    if (prevProps.indeterminate !== indeterminate) {
      this.selector.indeterminate = indeterminate;
    }
  }

  render() {
    const {
      id,
      type,
      indeterminate,
      hasError,
      handleChange,
      label,
      checked,
      ...inputProps
    } = this.props;

    let checkboxClassname = 'cus-checkbox';

    if (type === 'tick') checkboxClassname = 'cus-checkboxtick ';

    checkboxClassname += `
        ${type === 'tick' && 'cus-checkboxtick'}
        ${type === 'switch' && 'cus-checkboxswitch'}
        ${hasError && 'cus-checkboxhas-error'}
      `;

    const inputClassname = `
        cus-checkboxinput
        ${type === 'tick' && 'cus-checkboxtick'}
        ${type === 'switch' && 'cus-checkboxswitchinput'}
        ${hasError && 'cus-checkboxhas-errorinput'}
      `;

    return (
      <div className={checkboxClassname}>
        <input
          type="checkbox"
          className={inputClassname}
          ref={el => {
            this.selector = el;
          }}
          checked={checked}
          id={id}
          {...inputProps}
          onChange={e => {
            if (handleChange)
              handleChange({
                // name: e.target.name,
                checked: e.target.checked
              });
          }}
        />
        {label && (
          <label htmlFor={id} id={id}>
            {label}
          </label>
        )}
      </div>
    );
  }
}

Checkbox.propTypes = {
  hasError: PropTypes.bool,
  id: PropTypes.string.isRequired,
  indeterminate: PropTypes.bool,
  handleChange: PropTypes.func,
  type: PropTypes.oneOf(['tick', 'switch']),
  label: PropTypes.string
};

Checkbox.defaultProps = {
  hasError: false,
  indeterminate: undefined,
  handleChange: () => {},
  type: 'tick',
  label: null
};
