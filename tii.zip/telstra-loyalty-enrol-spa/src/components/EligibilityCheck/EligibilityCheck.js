import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import _ from 'lodash';

import AppLog from 'utils/AppLog';
import * as Analytics from 'utils/analytics';

import * as pointsActions from 'actions/points';

import * as ERRCODES from 'constants/errorCodes.js';
import * as ERRMSGS from 'constants/errorMessages.js';

import * as actions from 'constants/actions';

import getDetails from 'api/getDetails';
import getPoints from 'api/getPoints';
import getPointsHistory from 'api/getPointsHistory';

import { getAuthorizationToken } from 'oidc/initiateOidc';

import { history } from '../../store';

const IN_DEVELOP = process.env.REACT_APP_ENV === 'dev';

class EligibilityCheck extends Component {
  constructor() {
    super();
    this.log = new AppLog('EligibilityCheck');
  }

  componentDidMount() {
    this.log.debug('EligibilityCheck mounted');

    const {
      eligibility: { hasCheckedEligibility },
      app: { originUrl }
    } = this.props;

    if (hasCheckedEligibility) {
      this.log.debug('Skipping Eligibility check');
    } else {
      this.parseCaimanResponseData();

      // This is for tracking edm codes for analytics
      if (!IN_DEVELOP) history.push(`/${originUrl.search}`);
    }
  }

  parseCaimanResponseData = () => {
    if (IN_DEVELOP) console.log('parsing response');

    const authToken = getAuthorizationToken();

    sessionStorage.setItem('accessToken', authToken);

    Analytics.initAnalytics();
    Analytics.setPageName('Eligibility Check');

    this.getCustomerDetails(authToken);
  };

  getCustomerPoints = (token, cac, cacList) => {
    // Action creator approach:
    // this.props.fetchPoints(token, cac);
    this.log.debug('getCustomerPoints for each cac: ', cacList);
    // basic approach
    const { dispatch } = this.props;

    // POINTS RETRIEVAL
    dispatch({ type: actions.GET_POINTS_PENDING });

    getPoints(token, cacList)
      .then(response => {
        this.log.debug('GetPoints Response: ', response);
        dispatch({
          type: actions.GET_POINTS_SUCCESS,
          response
        });

        const orderedAcc = _.orderBy(
          response.data.loyalty.accounts,
          ['accountId'],
          ['dsc']
        );

        dispatch({
          type: actions.MERGE_ACCOUNTS_LIST,
          sortedPointsAccounts: orderedAcc
        });

        dispatch({
          type: actions.SET_INITIAL_POINTS,
          pointsValue: orderedAcc[0].points.loyaltyPoints
        });
      })
      .catch(error => {
        this.log.error('Caught getPoints error: ', error);
        dispatch({ type: actions.GET_POINTS_FAILURE });
      });

    // POINTS HISTORY RETRIEVAL
    dispatch({ type: actions.GET_POINTS_HISTORY_PENDING });
    getPointsHistory(token, cac.accountId)
      .then(response => {
        this.log.debug('GetPointsHistory Response: ', response);
        dispatch({
          type: actions.GET_POINTS_HISTORY_SUCCESS,
          response
        });
      })
      .catch(error => {
        this.log.error('Caught GetPointsHistory error: ', error);
        dispatch({ type: actions.GET_POINTS_HISTORY_FAILURE });
      });
  };

  getCustomerDetails = token => {
    const { dispatch } = this.props;
    dispatch({ type: actions.SET_ENROLLING, enrolling: true });
    Analytics.setPageName('Checking Eligibility');
    this.log.debug('Getting customer details => token is: ', token);

    getDetails(token)
      .then(response => {
        this.log.debug('Get Details Response', response);

        // SUCCESS, YOU'RE ELIGIBLE!
        if (_.has(response, 'data')) {
          this.log.debug('Normal Response');

          const { isQualified, isEnrolled } = response.data.data;

          dispatch({
            type: actions.SET_ELIGIBLE,
            eligible: isQualified,
            getDetails: response.data
          });

          this.log.debug(
            'get details cac response:',
            response.data.data.accounts
          );

          const sortedAccounts = response.data.data.accounts.filter(
            orderedCac => {
              return orderedCac.enrollmentStatus === 'ENROLLED';
            }
          );

          dispatch({ type: actions.SET_ENROLLED, enrolled: isEnrolled });
          dispatch({
            type: actions.SET_INITIAL_ACCOUNT,
            cac: sortedAccounts[0],
            membershipIndex: 1
          });

          // Loop through accounts and retrieve accountId
          let cacList = '';
          sortedAccounts.forEach(cac => {
            cacList = `${cacList}${cac.accountId},`;
          });

          cacList = cacList.substring(0, cacList.length - 1);
          this.log.debug('CACLIST: ', cacList);

          dispatch({
            type: actions.SET_ACCOUNTS_LIST,
            sortedAccounts,
            cacList
          });
          // If Enrolled fire off points retrieval
          if (isEnrolled) {
            this.getCustomerPoints(token, sortedAccounts[0], cacList);
          }
        }
      })
      .then(() => {
        this.log.debug('Final then');
        dispatch({
          type: actions.SET_HASCHECKEDELIGIBILITY,
          hasCheckedEligibility: true
        });
        dispatch({
          type: actions.SET_ENROLLING,
          enrolling: false
        });
      })
      .catch(error => {
        this.log.debug('catch error', error);
        Analytics.setPageName('Enrolment Error');
        if (typeof error.response === 'undefined') {
          this.log.debug('Technical / 401 Error');
          Analytics.setPageName('Eligibility Check Error');
          dispatch({
            type: actions.SET_ERROR,
            hasErrored: true,
            errorStatusCode: 401,
            errorMessage: ERRMSGS.DEFAULTMESSAGE
          });
        } else if (typeof error.response !== 'undefined') {
          this.log.debug('4XX type error');
          Analytics.setPageName('Eligibility Check Error');
          const { code } = error.response.data;

          if (code === ERRCODES.ERR_NO_ACTIVE_CACS) {
            this.log.debug('Status Code 1040');
            Analytics.setPageName('Not Eligible - No active services');
            dispatch({
              type: actions.SET_ELIGIBLE,
              eligible: false,
              getDetails: error.response.data
            });
            dispatch({ type: actions.SET_ENROLLED, enrolled: false });
            dispatch({
              type: actions.SET_ERROR,
              errorStatusCode: code
            });
          } else if (code === ERRCODES.ERR_ONLY_SMALL_BUSINESS_CACS) {
            this.log.debug('Status Code 1020');
            Analytics.setPageName('Eligibility Check Error');
            dispatch({
              type: actions.SET_ELIGIBLE,
              eligible: false,
              getDetails: error.response.data
            });
            dispatch({ type: actions.SET_ENROLLED, enrolled: false });
            dispatch({
              type: actions.SET_ERROR,
              errorStatusCode: code
            });
          } else if (code === ERRCODES.ERR_SOME_SMALL_BUSINESS_CACS) {
            this.log.debug('Status Code 1030');
            Analytics.setPageName('Not Eligible - Some Small Business');
            const { isQualified } = error.response.data.data;

            if (isQualified) {
              this.log.debug('1030 Qualified');

              dispatch({
                type: actions.SET_ELIGIBLE,
                eligible: true,
                getDetails: error.response.data
              });
              dispatch({ type: actions.SET_ENROLLED, enrolled: true });
              dispatch({ type: actions.SET_ENROLLING, enrolling: false });
            } else {
              this.log.debug('1030 Failed qualification');
              Analytics.setPageName('Eligibility Check Error');
              dispatch({
                type: actions.SET_ELIGIBLE,
                eligible: false,
                getDetails: error.response.data
              });
              dispatch({ type: actions.SET_ENROLLED, enrolled: false });
              dispatch({
                type: actions.SET_ERROR,
                hasErrored: true,
                errorStatusCode: code
              });
              dispatch({ type: actions.SET_ENROLLING, enrolling: false });
            }
          } else {
            this.log.debug('Technical Error');
            Analytics.setPageName('Eligibility Check Error');
            dispatch({
              type: actions.SET_ELIGIBLE,
              eligible: false,
              getDetails: error.response.data
            });
            dispatch({ type: actions.SET_ENROLLED, enrolled: false });
            dispatch({
              type: actions.SET_ERROR,
              hasErrored: true,
              errorStatusCode: code,
              errorMessage: ERRMSGS.DEFAULTMESSAGE
            });
          }
        }
        dispatch({
          type: actions.SET_HASCHECKEDELIGIBILITY,
          hasCheckedEligibility: true
        });
        dispatch({
          type: actions.SET_ENROLLING,
          enrolling: false
        });
      });
  };

  render() {
    const {
      eligibility: { hasCheckedEligibility, eligible },
      enrolment: { enrolled },
      error: { hasErrored },
      app: { originUrl }
    } = this.props;

    if (hasCheckedEligibility) {
      if (hasErrored) {
        return <Redirect exact to="/error" />;
      }

      if (!eligible) {
        return <Redirect exact to="/not-eligible" />;
      }

      if (!enrolled) {
        return <Redirect exact to="/join" />;
      }

      if (originUrl.pathname === '/points') {
        return <Redirect exact to="/points" />;
      }
      // if (originUrl.pathname === '/opt-out') {
      //   return <Redirect exact to="/opt-out" />;
      // }

      return <Redirect exact to="/benefits" />;
    }

    return null;
  }
}

const mapStateToProps = state => ({
  app: state.app,
  error: state.error,
  eligibility: state.eligibility,
  enrolment: state.enrolment
});

const mapDispatchToProps = dispatch => {
  return {
    ...pointsActions,
    dispatch
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EligibilityCheck);

EligibilityCheck.propTypes = {
  dispatch: PropTypes.func.isRequired,
  app: PropTypes.object,
  error: PropTypes.object,
  enrolment: PropTypes.object,
  eligibility: PropTypes.object
};

EligibilityCheck.defaultProps = {
  app: {},
  error: {},
  enrolment: {},
  eligibility: {}
};
