import EligibilityCheck from './EligibilityCheck';

export default EligibilityCheck;
