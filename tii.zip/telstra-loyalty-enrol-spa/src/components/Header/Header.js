import React, { Component, Fragment } from 'react';
import { signOut } from 'oidc/initiateOidc';
import PropTypes from 'prop-types';

import { withRouter, Link } from 'react-router-dom';
import { connect } from 'react-redux';
import Sidebar from 'react-sidebar';

import * as Analytics from 'utils/analytics';

import IconClose from 'icons/IconClose';
import IconArrow from 'icons/IconArrow';

import smallSpinner from 'assets/images/Spinner-48-Loyalty.gif';

import tcomSVG from 'assets/images/t-logo-pacific.svg';
import logoSVG from 'assets/images/TPlus Logo.svg';
import tile from 'assets/images/success-tile@2x.png';

import {
  SWITCH_ACCOUNT,
  GET_POINTS_HISTORY_PENDING,
  GET_POINTS_HISTORY_FAILURE,
  GET_POINTS_HISTORY_SUCCESS
} from 'constants/actions';
import getPointsHistory from 'api/getPointsHistory';
import NavLinks from './NavLinks';

import './Header.scss';
import { SidebarStyles } from './SidebarStyles';

class Header extends Component {
  state = {
    isScrolling: false,
    docked: true,
    sidebarOpen: false,
    showNotificationBar: false,
    allowMultiCAC: false,
    dismissedWelcome: false,
    offsetDivHeight: 0
  };

  componentDidMount() {
    window.addEventListener('scroll', this.listenScrollEvent);

    const {
      activeAccount: { sortedAccounts }
    } = this.props;

    if (typeof sortedAccounts !== 'undefined') {
      if (sortedAccounts.length > 1) {
        this.setState({
          allowMultiCAC: true
        });
      }
    }
  }

  componentDidUpdate(prevProps) {
    const {
      activeAccount: { loyaltyTier, pointsValue }
    } = this.props;

    if (this.props !== prevProps) {
      // set user analytics when header changes
      const user = {
        points: pointsValue,
        tier: loyaltyTier
      };
      Analytics.setUser(user);

      const prevPageIsSuccessOrJoin =
        window.previousLocation.pathname === '/success' ||
        window.previousLocation.pathname === '/join';

      if (prevPageIsSuccessOrJoin && !this.state.dismissedWelcome) {
        this.onSetSidebarOpen(true);
      }
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.listenScrollEvent);
  }

  onSetSidebarOpen = open => {
    this.setState({ sidebarOpen: open });
    window.scrollTo(0, 0);
  };

  dismissWelcome = () => {
    this.setState({
      dismissedWelcome: true
    });
  };

  hideNotificationBar = () => {
    const { showNotificationBar } = this.state;
    this.setState({
      showNotificationBar: !showNotificationBar
    });
  };

  listenScrollEvent = () => {
    if (!this.state.isScrolling) {
      this.setState({ isScrolling: true });
      setTimeout(() => {
        this.setState({ isScrolling: false });
      }, 300);
    }

    if (window.scrollY > 40) {
      // 40px is the height of the tcom-bar
      this.setState({ docked: false });
    } else {
      this.setState({ docked: true });
    }
  };

  getTierColour = () => {
    const {
      activeAccount: { loyaltyTier }
    } = this.props;

    switch (loyaltyTier) {
      case 'MEMBER':
        return '#a0148c';
      case 'SILVER':
        return '#767676';
      case 'GOLD':
        return '#93713b';
      default:
        return '#a0148c';
    }
  };

  switchAccount = (cac, membershipIndex, pointsValue) => {
    const { dispatch } = this.props;
    dispatch({ type: GET_POINTS_HISTORY_PENDING });

    dispatch({
      type: SWITCH_ACCOUNT,
      cac,
      membershipIndex,
      pointsValue
    });
    const token = sessionStorage.getItem('accessToken');

    getPointsHistory(token, cac.accountId)
      .then(response => {
        dispatch({
          type: GET_POINTS_HISTORY_SUCCESS,
          response
        });
      })
      .catch(error => {
        this.log.debug('error', error);
        dispatch({ type: GET_POINTS_HISTORY_FAILURE });
      });
    this.onSetSidebarOpen(false);
  };

  renderSideBarContent = () => {
    const {
      points: { pending },
      activeAccount
    } = this.props;

    const prevPageIsSuccessOrJoin =
      window.previousLocation.pathname === '/success' ||
      window.previousLocation.pathname === '/join';

    if (prevPageIsSuccessOrJoin && !this.state.dismissedWelcome) {
      return (
        <div className="sidebar-content">
          <div className="h-bar visible-xs" />

          <button
            className="close-sidebar-btn"
            type="button"
            onClick={() => this.dismissWelcome()}
          >
            <IconClose />
          </button>
          <h3>Welcome to Telstra Plus &trade;</h3>
          <p className="intro-to-mcac">
            You have multiple Telstra Plus memberships. You can switch between
            them anytime by clicking Select on the membership you want to switch
            to.
          </p>
          <button
            type="button"
            aria-pressed="false"
            className="primary-cta-18 dismiss-btn"
            onClick={() => this.dismissWelcome()}
          >
            OK <IconArrow />
          </button>
          <div
            className="decoration"
            style={{ backgroundImage: `url(${tile})` }}
          />
        </div>
      );
    }

    return (
      <div className="sidebar-content">
        <button
          className="close-sidebar-btn"
          type="button"
          onClick={() => this.onSetSidebarOpen(false)}
        >
          <IconClose />
        </button>
        <div className="h-bar visible-xs" />
        <h3>Switch to another membership</h3>
        <ul className="membership-list">
          {activeAccount.sortedAccounts.map((cac, idx) => {
            return (
              <li
                className={
                  cac.accountId === activeAccount.accountId ? 'active' : null
                }
                key={cac.accountId}
              >
                <p className="title">
                  <strong>Membership {idx + 1}</strong>
                </p>
                {!pending && cac.accountId !== activeAccount.accountId && (
                  <button
                    type="button"
                    aria-pressed="false"
                    className="primary-cta-18 go-to-btn"
                    onClick={() => {
                      this.switchAccount(
                        cac,
                        idx + 1,
                        cac.points.loyaltyPoints
                      );
                    }}
                  >
                    Select <IconArrow />
                  </button>
                )}
                <div className="tier-information">
                  <span className={`membership-tier ${cac.loyaltyTier}`}>
                    <strong>Tier</strong>
                    <p>{cac.loyaltyTier.toLowerCase()}</p>
                  </span>
                  <span className="points-value">
                    <strong>Points</strong>
                    {pending && (
                      <img
                        className="inline-spinner-sidebar"
                        src={smallSpinner}
                        alt="Loading"
                      />
                    )}
                    {!pending &&
                      cac.points &&
                      cac.points.loyaltyPoints &&
                      parseInt(cac.points.loyaltyPoints, 10).toLocaleString(
                        navigator.language,
                        {
                          minimumFractionDigits: 0
                        }
                      )}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
        <div className="sidebar-info">
          <div className="info-container">
            <p>
              <strong>Why do I have multiple Telstra Plus memberships?</strong>
            </p>
            <p>
              You have multiple Telstra Plus memberships because you have access
              to multiple Telstra accounts that have joined Telstra Plus. You
              may be able to combine your accounts into one membership.
              <br />
              <br />
              Call us on
              <a href="http://www.telstra.com.au/support">13 22 00</a> to talk
              to us about consolidating your accounts.
            </p>
          </div>
        </div>
      </div>
    );
  };

  handleSignout = () => {
    signOut();
  };

  refCallback = element => {
    if (element) {
      const elHeight = element.getBoundingClientRect();
      this.setState({
        offsetDivHeight: elHeight.height
      });
    }
  };

  render() {
    const {
      buttonText,
      location,
      points: { pending },
      activeAccount,
      enrolment: { enrolled }
    } = this.props;

    const {
      docked,
      isScrolling,
      showNotificationBar,
      allowMultiCAC
    } = this.state;

    const pointsCommad = parseInt(activeAccount.pointsValue, 10).toLocaleString(
      navigator.language,
      {
        minimumFractionDigits: 0
      }
    );

    let parsedPoints = '--';

    if (!isNaN(parseInt(activeAccount.pointsValue, 10)))
      parsedPoints = pointsCommad;

    if (enrolled && location.pathname !== '/success') {
      const tier = activeAccount.loyaltyTier;

      return (
        <Fragment>
          <Sidebar
            pullRight
            sidebar={this.renderSideBarContent()}
            open={this.state.sidebarOpen}
            onSetOpen={this.onSetSidebarOpen}
            styles={SidebarStyles}
            sidebarClassName="sidebar"
          >
            <p />
          </Sidebar>
          <header
            ref={this.refCallback}
            className={`enrolment-header-large tcom-global-navigation ${
              isScrolling ? 'scrolling' : 'not-scrolling'
            } ${docked ? 'docked' : 'not-docked'} ${
              !showNotificationBar ? 'hide-notification' : 'show-notification'
            }`}
            id="tcom-navigation"
          >
            {showNotificationBar && (
              <div
                id="notification-bar"
                className={`notification-bar  ${
                  showNotificationBar ? 'visible' : 'hidden'
                }`}
              >
                <div className="notification-text-wrapper">
                  <p className="notification-text">
                    To check the points balance for other memberships you have
                    access to, please chat with us.
                  </p>
                  <a
                    className="primary-cta-16 notification-cta"
                    href="https://www.telstra.com.au/plus/frequently-asked-questions#cannot-see-all-my-memberships"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Learn more about multiple memberships
                  </a>
                </div>
                <button
                  onClick={this.hideNotificationBar}
                  type="button"
                  className={`notification-close-btn  ${
                    showNotificationBar ? 'visible' : 'hidden'
                  }`}
                >
                  <IconClose />
                </button>
              </div>
            )}
            <div className={`tcom-bar ${docked ? 'docked' : 'not-docked'}`}>
              <a href="http://www.telstra.com.au">
                <img src={tcomSVG} alt="Telstra Logo" />
                Telstra.com
              </a>
              <button
                className={`signout ${docked ? 'docked' : 'not-docked'}`}
                type="button"
                onClick={this.handleSignout}
              >
                {buttonText}
              </button>
            </div>
            <nav className="tcom-nav-container container hidden-xs">
              <Link className="logo" to="/benefits">
                <img src={logoSVG} alt="Telstra Logo" />
              </Link>
              <NavLinks />
              <div
                style={{ backgroundColor: this.getTierColour() }}
                className="tier-container"
              >
                <div className="tier-info">
                  <span>
                    Tier <strong>{tier.toLowerCase()}</strong>
                  </span>
                  <span>
                    Points
                    {pending ? (
                      <strong>
                        <img
                          className="inline-spinner"
                          src={smallSpinner}
                          alt="Loading"
                        />
                      </strong>
                    ) : (
                      <strong>{parsedPoints}</strong>
                    )}
                  </span>
                  {allowMultiCAC && (
                    <span className="membership-tier">
                      <button
                        type="button"
                        onClick={() => this.onSetSidebarOpen(true)}
                      >
                        Membership {activeAccount.membershipIndex}
                      </button>
                    </span>
                  )}
                </div>
              </div>
            </nav>

            <nav className="tcom-nav-container visible-xs">
              <a className="logo" href="http://www.telstra.com.au">
                <img src={tcomSVG} alt="Telstra Logo" />
                Telstra.com
              </a>
              <div
                style={{ backgroundColor: this.getTierColour() }}
                className="tier-container"
              >
                <div className="tier-info">
                  <span>
                    Tier <strong>{tier.toLowerCase()}</strong>
                  </span>
                  <span>
                    Points
                    {pending ? (
                      <strong>
                        <img
                          className="inline-spinner"
                          src={smallSpinner}
                          alt="Loading"
                        />
                      </strong>
                    ) : (
                      <strong>{parsedPoints}</strong>
                    )}{' '}
                  </span>
                  {allowMultiCAC && (
                    <span className="membership-tier">
                      <button
                        type="button"
                        onClick={() => this.onSetSidebarOpen(true)}
                      >
                        Membership {activeAccount.membershipIndex}
                      </button>
                    </span>
                  )}
                </div>
              </div>
              <NavLinks />

              <button
                className="signout"
                type="button"
                onClick={this.handleSignout}
              >
                {buttonText}
              </button>
            </nav>
          </header>
          <div
            className={`offset-div-large  ${
              !showNotificationBar ? 'hide-notification' : 'show-notifcation'
            }`}
            style={{ height: this.state.offsetDivHeight }}
          />
        </Fragment>
      );
    }

    return (
      <Fragment>
        <header
          className="not-enrolled-header tcom-global-navigation"
          id="tcom-navigation"
        >
          <nav className="tcom-nav-container">
            <a href="http://www.telstra.com.au">
              <img src={tcomSVG} alt="Telstra Logo" />
              Telstra.com
            </a>

            <button
              className="signout"
              type="button"
              onClick={this.handleSignout}
            >
              {buttonText}
            </button>
          </nav>
        </header>
        <div className="not-enrolled-offset-div" />
      </Fragment>
    );
  }
}

const mapStateToProps = state => ({
  app: state.app,
  activeAccount: state.activeAccount,
  points: state.points,
  enrolment: state.enrolment,
  eligibility: state.eligibility
});

Header.propTypes = {
  buttonText: PropTypes.string,
  points: PropTypes.shape({
    apiResponse: PropTypes.shape({
      loyalty: PropTypes.shape({ accounts: PropTypes.array })
    })
  }),
  activeAccount: PropTypes.shape({}),
  dispatch: PropTypes.func,
  eligibility: PropTypes.shape({
    getDetails: PropTypes.shape({
      data: PropTypes.shape({
        accounts: PropTypes.array
      })
    })
  }),
  enrolment: PropTypes.shape({
    enrolled: PropTypes.bool,
    membership: PropTypes.shape({
      tier: PropTypes.string
    })
  }),
  location: PropTypes.shape({
    pathname: PropTypes.string
  })
};

Header.defaultProps = {
  buttonText: 'Sign out',
  activeAccount: {},
  dispatch: () => {},
  points: {
    apiResponse: {
      loyalty: {
        accounts: [{}]
      }
    }
  },
  eligibility: {
    getDetails: {
      data: {
        accounts: [
          {
            loyaltyTier: 'MEMBER'
          }
        ]
      }
    }
  },
  enrolment: {
    enrolled: false,
    membership: {
      tier: 'Member'
    }
  },
  location: {
    pathname: PropTypes.string
  }
};

export default withRouter(connect(mapStateToProps)(Header));
