/* eslint-disable react/no-array-index-key */

import React from 'react';
import PropTypes from 'prop-types';
import { NavLink as Link } from 'react-router-dom';
import './NavLinks.scss';

const NavLink = ({ link }) => {
  const isActive = (match, location) => {
    if (!match) {
      return false;
    }
    if (match.isExact) {
      return true;
    }
    // To catch our only child page so far
    if (location.pathname === '/points/history') {
      return true;
    }

    return location.pathname.startsWith(match.path) && match.path.length > 1;
  };

  if (link.to.startsWith('http')) {
    return (
      <a
        href={link.to}
        rel="noopener noreferrer"
        target="_blank"
        className="navLink"
      >
        {link.label}
      </a>
    );
  }
  return (
    <Link
      isActive={isActive}
      activeClassName="isActive"
      className="navLink"
      to={link.to}
    >
      {link.label}
    </Link>
  );
};

const NavLinks = () => {
  const navLinks = [
    {
      label: 'Benefits',
      to: '/benefits'
    },
    {
      label: 'Points',
      to: '/points'
    }
  ];

  return (
    <div className="navLinks">
      {navLinks.map((link, key) => (
        <NavLink key={key} link={link} />
      ))}
    </div>
  );
};

NavLink.propTypes = {
  link: PropTypes.shape({
    to: PropTypes.string,
    label: PropTypes.string
  })
};

NavLink.defaultProps = {
  link: {
    to: '',
    label: ''
  }
};

export default NavLinks;
