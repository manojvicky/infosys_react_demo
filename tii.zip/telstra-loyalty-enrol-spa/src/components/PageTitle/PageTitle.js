import React, { Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

// import IconArrow from 'icons/IconArrow';

import './PageTitle.scss';

const PageTitle = ({ heroImage, mobileImage, calloutHeader, miniHeader }) => (
  <Fragment>
    <div className="page-title-wrapper container">
      <div
        style={{
          backgroundImage: `url(${heroImage})`
        }}
        className="hero-banner hidden-xs"
      >
        <div className="page-title information-callout hidden-xs">
          <p className="mini-header">{miniHeader}</p>
          <h2>{calloutHeader}</h2>
        </div>
      </div>
      <div
        style={{
          backgroundImage: `url(${mobileImage})`
        }}
        className="hero-banner visible-xs"
      >
        <div className="page-title information-callout hidden-xs">
          <h2>{calloutHeader}</h2>
        </div>
      </div>
    </div>
    <div className="container mobile-header visible-xs">
      <p className="mini-header">{miniHeader}</p>

      <h2>{calloutHeader}</h2>
    </div>
  </Fragment>
);

const mapStateToProps = state => ({
  app: state.app,
  points: state.points,
  enrolment: state.enrolment
});

export default connect(mapStateToProps)(PageTitle);

PageTitle.propTypes = {
  heroImage: PropTypes.string,
  mobileImage: PropTypes.string,
  calloutHeader: PropTypes.string,
  miniHeader: PropTypes.string
};

PageTitle.defaultProps = {
  miniHeader: null,
  heroImage: null,
  mobileImage: null,
  calloutHeader: ''
};
