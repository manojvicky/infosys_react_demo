import PageTitle from './PageTitle';

export default PageTitle;
