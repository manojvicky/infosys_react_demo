# Telstra Plus Loyalty S.P.A

_This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app)_

Telstra Loyalty SPA is a single-page application which uses React for it's UI, and Redux as a method of storing the app state and information returned from our various API's.

### Important information

We have multiple configurations set up for our different development environments and they are as follows:

DEV - Local machine development
`http://localhost:3000/`

NP - (Non-Prod) - Basically for testing new features and functionality - Usually built from our 'develop' branch
`https://plus.np.in.telstra.com.au`

S.I.T (PreProd) - Our major testing environment with access to proper Telstra Digital accoounts and services. The last env before production
`https://plus.preprod.in.telstra.com.au/`

PROD (Production) - Master branch, our latest release with fully reviewed and functional code.
`https://plus.telstra.com.au/`

Different environments will use their respective .env file that lives in the root folder, they contain various different URLS and API endpoints specific to that environment, you should not have any need to edit these files unless you've spoken to the backend team.

#### Authentication

Authentication is handled by a third-party: "CAIMAN" They have certain rules and restrictions regarding how to access their service correctly.

On the first page load, provided you are not-authenticated, you will be directed to CAIMAN to provide some login credentials. Once submitted CAIMAN will re-direct you back to the SPA. There are many caveats with this flow, which we have done our best to develop around.
For instance:

- not being able to store query parameters in a URL,
- not being able to deeplink from pages outside of the SPA.

@TODO More info about this.

#### Page Routing

##### /benefits

The benefits page acts as the 'home' page for the SPA. The SPA defaults to this page if "/points" does not exist in the URL on initial page load.

This page is used to show different Plus promotions to customers, and these Promos are usually conditionally shown based on a users membership tier, either MEMBER, SILVER or GOLD.

It is made with the BenefitsContainer components, which includes a PageTitle and then renders BenefitsView within that.
BenefitsView consists of : Various PromoTile components, MembershipTierTable (called BenefitsTiles) and VerticalTabs

##### /points

Shows points
@TODO

##### /points/history

@TODO
Shows points and table of point history transactions

##### /join

@TODO
Where the user agrees to sign up to t+

##### /success

@TODO
Shown after a succesful enrolment to t+

##### /error

@TODO
If there is an error with any request to receive information from an API

##### /not-eligible

@TODO
If for some reason a user is not allowed to enrol for t+ this page will inform they why

## Ready to develop!

If you're on a Windows machine, you'll need to install "Windows Build Tools"

```sh
https://github.com/felixrieseberg/windows-build-tools
```

After cloning, install them dependencies:

```sh
npm install
```

_There are a number of Telstra Specific repositories that we have as dependencies for this project, please ensure you have, at the very least, read permissions to following repos before trying to install_

- @tcom-core
- @tcom-fonts
- @tcom-icons

https://git02.ae.sda.corp.telstra.com/projects/TELAMS

## Available Scripts

Start the app with mocks

```sh
npm run start:with-mocks
```

OR

```
npm run start
```

NOTE: If using with :with-mocks, you will also want to open a new terminal window, cd into the project folder and run

```
node ./mock/mock-server.js
```

The page will reload if you make edits.

You will also see any lint errors in the console.

Access the app:

```
http://localhost:3000
```

Running unit tests:

```
 `npm test`
```

Launches the test runner in the interactive watch mode.<br>
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

As this project was bootstrapped from create-react-app, we are using its default build configuration, which greatly reduces the complexity of creating builds. There should not be any reason to eject from CRA's default configs.

```
`npm run eject`
```

# DON'T RUN THIS

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (Webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

You don’t have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

---

# Keeping it real

There are some tools in place to maintain consistency in the codebase:

### ESLint

ESLinting is part of the project, we have extended our ruleset from airbnb
[AirBNB ESLint Config](https://eslint.org/docs/user-guide/configuring#extending-configuration-files)

### Prettier

Download the [Prettier Code Formatter](https://prettier.io/) extension for your IDE of choice.

We _strongly_ reccomend using VSCode as your IDE.

We have a .prettierrc file configured to keep our code looking as consistent (and pretty) as possible.

## Branching workflow

_master, develop, feature, update, defect, hotfix, bugfix_

```
### `master`
ready for deployment / end-of-sprint milestones

```

Read more here: [Feature Branch Workflow](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow) and [A successful Git branching model](http://nvie.com/posts/a-successful-git-branching-model/#supporting-branches)

## Commenting and logging (@TODO Needs input / improvement)

Comment anything that seems not self documenting.

Prefix things a developer needs to come back to with `@TODO`.

---

# Components

The following components are frequently used throughout the Loyalty SPA.

## Header

##### Properties

| Name                                                                      |   Type   | Description                                                         |
| ------------------------------------------------------------------------- | :------: | ------------------------------------------------------------------- |
| buttonText                                                                |  string  | Text for the signout button                                         |
| activeAccount                                                             |  object  | Object containing details of the currenttly selected member account |
| dispatch                                                                  | function | function to dispatch actions                                        |
| points: { apiResponse: { loyalty: { accounts: [{}] } } }                  |  object  | List of accounts with points values                                 |
| eligibility: { getDetails: { data: { accounts: [{ loyaltyTier: ''}] } } } |  string  | Users tier level                                                    |
| enrolment: { enrolled: false, membership: { tier: ''} }                   |  string  | Users tier level                                                    |
| location: { pathname: '' }                                                |  string  | Current location of the SPA                                         |

##### State

| Name                |  Type   | Description                                                                                       |
| ------------------- | :-----: | ------------------------------------------------------------------------------------------------- |
| isScrolling         | boolean | flag to determine whether or not the page is scrolling (used to show a drop-shadow on the header) |
| docked              | boolean | Whether or not the Header is attached to the top of the page or freely moving                     |
| sidebarOpen         | boolean | Flag to determine whether to hide/show the MultiCACSideBar                                        |
| showNotificationBar | boolean | Flag to show the notification bar above the header                                                |
| allowMultiCAC       | boolean | Flag to determine whether or not to allow the MultiCACSideBar to render                           |
| dismissedWelcome    | boolean | Flag to determine whether or not to show the welcome splash in the sidebar                        |

##### Purpose:

- Displays a users tier level and points value
- Allows navigation between the /benefits and /points
- Shows a sidebar with a list of users memberships, only if the user has multiple memberships associated with the account
- Can show a notification message above the Header
- Allows user to sign-out from the SPA

##### - Footer

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - EligibilityCheck

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - Breadcrumbs

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - Checkbox

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - LoadingSpinner

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - VerticalTabs

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

##### - PromoGroup

###### Props: @TODO

###### State: @TODO

###### Purpose: @TODO

- ###### BigPromoTile
- ###### MiniPromoTile
- ###### VerticalPromoTile

## Reading & watching material

- Babel's ES6 features page
- React tutorial
- Pete Hunt's talk
- Redux docs
- Abramov's React Europe talk
- Redux egghead series

# And off you go! 🎉
