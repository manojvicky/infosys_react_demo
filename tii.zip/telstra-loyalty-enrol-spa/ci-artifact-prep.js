
const fs = require('fs-extra');
try{
    // clean build directory
    fs.emptyDirSync("./dist");
    // copy public artifact
    fs.copySync("./build", "./dist/public");
    // copy server artifact
    fs.copySync("./mock", "./dist/mock");
    fs.copySync("./package-mock.json", "./dist/package.json"); 
}catch(e){
    console.log("Error:"+e);
}

