const jsonServer = require('json-server');

const server = jsonServer.create();
const router = jsonServer.router(`${__dirname}/db.json`);
const middlewares = jsonServer.defaults();

const cfenv = require("cfenv");
const appEnv = cfenv.getAppEnv();
const express = require('express');

const ON_LOCAL = !(appEnv && appEnv.app && appEnv.app.space_name);
const rootHost = ON_LOCAL ? "http://localhost:3000": "";

// Set default middlewares (logger, static, cors and no-cache)
server.use(middlewares);

// TODO - JOSH - This is going to be outdated and v difficult to mock with
//               auth token flow implementation.
//
// Add custom routes before JSON Server router
server.get('/identity/as/authorization.oauth2', (req, res) => {
  res.redirect(rootHost + '/#access_token=123'); // to handle oidc validation
});
console.log("!!!!! ROOT HOST: ", rootHost);

// To handle POST, PUT and PATCH you need to use a body-parser
// You can use the one used by JSON Server
server.use(jsonServer.bodyParser);
server.use((req, res, next) => {
  if (req.method === 'POST') {
    req.body.createdAt = Date.now();
    //TODO - tmp hack for unenrol post request
    if(req.url === '/presentation/v1/loyalty/unenrol'){
      req.method = 'GET';
    }
  }
  next(); // Continue to JSON Server router
});
// Add middlewares to handle for queries returning only one result
server.use((req, res, next) => {
  const _send = res.send
  res.send = function (body) {
    const json = JSON.parse(body);
    if (Array.isArray(json)) {
      if (json.length === 1) {
        return _send.call(this, JSON.stringify(json[0]));
      } else if (json.length === 0) {
        return _send.call(this, '{}', 404);
      }
    }
    return _send.call(this, body)
  }
  next();
});


// Add this before server.use(router)
server.use( '/presentation',
  jsonServer.rewriter({
    '/v1/loyalty/cip/details': '/cip_details/1',
    '/v1/loyalty/cip/details/*': '/cip_details/$1',
    '/v1/loyalty/cip/unenrol': '/unenrol/1',
    '/v1/loyalty/cip/points/history*': '/points_history/$1',
    '/v1/loyalty/cip/points*': '/points/$1'
  })
);
// Use default router
server.use('/presentation', router);

if(!ON_LOCAL){
  //get it to show static pages in public folder
  server.use( '', express.static(__dirname+'/../public', {
    maxAge: "1y"
  }));

  server.listen(appEnv.port, () => {
    console.log('JSON Server is running on port ' + appEnv.port);
  });

} else {
  
  server.listen(8000, () => {
    console.log('JSON Server is running on port 8000');
  });
}


