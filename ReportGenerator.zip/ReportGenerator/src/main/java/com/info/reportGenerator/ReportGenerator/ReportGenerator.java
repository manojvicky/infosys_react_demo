package com.info.reportGenerator.ReportGenerator;

public interface ReportGenerator {
	public String generateReport(int numberOfPage);
}
