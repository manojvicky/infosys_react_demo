package com.info.reportGenerator.ReportGenerator.html;

import com.info.reportGenerator.ReportGenerator.ReportGenerator;

public class HTMLReportGenerator implements ReportGenerator {
	public String generateReport(int recordsPerPage) {
		return "Generated HTML Report  with " + recordsPerPage + " records";
	}
}
