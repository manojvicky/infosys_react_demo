package com.info.reportGenerator.ReportGenerator;

public class App 
{
    public static void main( String[] args )
    {
    	ReportService report  = new ReportService();
    	report.generateReport();
    }
}
