package com.info.reportGenerator.ReportGenerator;

import com.info.reportGenerator.ReportGenerator.html.HTMLReportGenerator;

public class ReportService {
	int recordsPerPage = 100;
	HTMLReportGenerator html = new HTMLReportGenerator();
	public void generateReport() {
		System.out.println(html.generateReport(this.recordsPerPage));
	}
}
