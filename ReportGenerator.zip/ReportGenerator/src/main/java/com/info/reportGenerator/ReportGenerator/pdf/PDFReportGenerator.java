package com.info.reportGenerator.ReportGenerator.pdf;

import com.info.reportGenerator.ReportGenerator.ReportGenerator;

public class PDFReportGenerator implements ReportGenerator {

	public String generateReport(int recordsPerPage) {
		
		return "Generated PDF Report  with " + recordsPerPage + "records";
	}

}
