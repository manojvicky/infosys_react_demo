import React from "react";
import ReactDOM from "react-dom";
import App from "./src/App/App";
import 'bootstrap/dist/css/bootstrap.css';
import "./src/styles.css";



ReactDOM.render(
    <App />, document.getElementById('app')
);