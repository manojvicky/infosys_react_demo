import React from "react";
import FunctionComp from "./FunctionComp";
import ClassComp from "./ClassComp";

class App extends React.Component{
    constructor(props){
        super(props);
        this.state={
            value:"Rani"
        }
    }
    render(){
        return (
            <div>
                <div>
                    <select value={this.state.value} onChange={(e)=>{const value = e.target.value; console.log("value", value);this.setState({value})}}>
                        <option>Manoj</option>
                        <option>vicky</option>
                        <option>Rani</option>
                        <option>Monika</option>
                        <option>Bakri</option>
                    </select>
                </div>
                <div className="adjust">
                    <FunctionComp user={this.state.value} />
                    <ClassComp user={this.state.value} />
                </div>
            </div>
        )
    }
}
export default App;