import React from "react";

const FunctionComp = (props) => {
    const showMessage = () => {
        alert('Followed ' + props.user);
      };
    
      const handleClick = () => {
        console.log("yoo");
        setTimeout(showMessage, 3000);
      };
      
      console.log("props functional component",props);


      return (
        <div className="FunctionComp" onClick={handleClick}>(Functional) Follow</div>
      );
}

export default FunctionComp;