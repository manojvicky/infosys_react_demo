import React from "react";
let a;
 export default class ClassComp extends React.Component{
    constructor(props){
        super(props);
        a = this;
        this.handleClick = this.handleClick.bind(this);
        this.showMessage = this.showMessage.bind(this);
        console.log("constructor");

    }
    componentDidMount(){
        console.log("this DidMmount", a===this);
    }
    showMessage (user){
        alert('Followed ' + user);
    }
    
    handleClick(){
        let user = this.props.user;
        setTimeout(()=>this.showMessage(user), 3000);
        // this.forceUpdate()
        console.log("this handleClick", a===this, this, a);
    }
    
    render() {
        return <div className="ClassComp" onClick={this.handleClick}>(Class) Follow</div>;
    }
 }
 