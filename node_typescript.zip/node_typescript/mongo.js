
//Import the mongoose module
var mongoose = require('mongoose');

//Set up default mongoose connection
var mongoDB = 'mongodb://127.0.0.1:27017/employee';
mongoose.connect(mongoDB, { useNewUrlParser: true });
// var Athlete = mongoose.model('emp');

var db = mongoose.connection;
let name = mongoose.model('emp',{});
let data = name.find().find({name:"Manoj"});
console.log('data', data);
db.on('error', console.error.bind(console, 'MongoDB connection error:'));