var count = 0;
module.exports = function(options){
return function (req, res, next){
    count++;
    console.log(`yoo i am middleware ${options} ${count}`);
    next();
}
}