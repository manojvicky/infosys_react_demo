import RedisManager from "./src/RedisManager/index";

RedisManager.setupRedisManger("localhost", 6727);
RedisManager.get("someKey", );