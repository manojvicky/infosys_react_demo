var express = require('express')
var app = express()
var logger = require("./myLogger");
var count = 0;
// app.use(logger('Write this?'));
var onCli = ()=>console.log("clicked");
app.use(function (req, res, next) {
  count++;
  console.log('Middleware 1');
  console.log('Time: ', Date.now(), 'count: ', count)
  next()
},
(req, res, next)=>{
  console.log('Middleware 2');
  next();
},

(req, res, next)=>{
  console.log('Middleware 3');
  next();
})
app.get('/user/:id', function (req, res, next) {
  // if the user ID is 0, skip to the next route
  if (req.params.id === '0') next('route')
  // otherwise pass the control to the next middleware function in this stack
  else next()
}, function (req, res, next) {
  // send a regular response
  res.send('regular')
})

// handler for the /user/:id path, which sends a special response
app.get('/user/:id', function (req, res, next) {
  res.send('special')
})
app.get('/value/we', (req, res)=>{
  res.send({name:"manoj"});
});
app.get('/:id', function (req, res) {
    res.send(`<html><script>var onCli = ()=>{
      let res = fetch('http://localhost:3000/value/we');
      res.then((response)=>response.json()).then(data=>console.log(data))
    };</script><body><h1>Yoo</h1><br><button onclick='onCli()'>click me</button></body></html>`)
  })

app.listen(3000);