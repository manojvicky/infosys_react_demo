const express = require("express");
const router  = express.Router();

router.use((req, res, next)=>{
console.log("date", Date.now());
next();
})
router.get("/", (req, res)=>{
    res.send("i am home page");
});
router.get("/about", (req, res)=>{
    res.send("i am about page");
});
router.get("/info", (req, res)=>{
    res.send("i am info page");
});

module.exports = router;
