import * as redis from "redis";

export default class RedisManager{
    private constructor(host:string, port:number){
        this.redisClient = redis.createClient(port, host);
    }
    private static manager: RedisManager = null;
    private redisClient: redis.RedisClient = null;
    static get(key: string) :string{
        RedisManager.manager.redisClient.get(key, (error:Error, response:string)=>{
            if(error){
                console.log('error', error)
            }else{
                return response;
            }
        });
        return "";
    }
    static set(key:string, value:string):void{
        RedisManager.manager.redisClient.set(key, value);
    }

    static setupRedisManger(host:string, port: number, ) {
        if(RedisManager.manager===null){
            RedisManager.manager =  new RedisManager(host, port)
        }
    }

}