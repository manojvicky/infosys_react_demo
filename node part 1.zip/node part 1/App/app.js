var net = require("net");
var client = net.connect({ port: 1234 }, function() {
  console.log("connected to server!");
  client.write("<B>Name:</B>" + chatname);
  client.write("<br><B>Message:</B>" + chatmessage);
});
client.on("data", function(data) {
  message +=
    "<tr style=' border-bottom:ridge;'><td>" + data.toString() + "</td></tr>";
  var chatresponse =
    "<br><table style='border-collapse:collapse;background-color: #ffb3b3;border: ridge;width:300px;top:100;left:0;position: fixed;'><tr style=' border-bottom:ridge;'><td><h4>Discussion:</h4></td></tr>" +
    message +
    "</table>";
  response.write(chatresponse);
  response.end();
});

client.on("end", function() {
  console.log("disconnected from server");
});


