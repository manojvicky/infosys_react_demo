var net = require('net');

var client = net.connect({ port: 5000 }, () => {
	console.log('connected to server');
	console.log("Hello I am client");
});

client.on('data', (data) => {
	console.log(data.toString());
	client.end();
});


client.on('end', () => {
	console.log('disconnected from server ');
}); 

