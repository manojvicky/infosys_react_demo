exports.add = (a,b) => a+b;
exports.substract = (a,b) => a-b;