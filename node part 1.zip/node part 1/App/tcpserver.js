var net = require("net");

var server = net.createServer(c => {
  console.log("client connected");

  c.on("data", data => {
    console.log(data.toString());
  });

  c.on("close", () => {
    console.log("client disconnected");
  });

  c.write("Hello data from server to client");
});
server.listen(5000, () => {
  console.log("TCP server started");
});

