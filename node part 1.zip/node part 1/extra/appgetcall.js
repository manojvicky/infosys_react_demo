const http = require("http");
const url = require("url");
const querystring = require("querystring");
let calculator = require("./calculator");
let server = http.createServer((req, res)=>{
    if (url.parse(req.url).pathname != "/favicon.ico") {
    let queryURL = url.parse(req.url);
    let query = queryURL.query
    let name = querystring.parse(query)["username"];
    let password = querystring.parse(query)["password"];
    console.log("req.url : ", queryURL, " query : ", query, " name : ",name, " password : ", password);
    res.write("<h1>Done</h1>");
    }
    res.end();
});
server.listen(3000, ()=>{
    console.log("server has been started at port 3000 in new way");
});