const http = require("http");
const url = require("url");
const fs = require("fs");
const querystring = require("querystring");
let calculator = require("./calculator");
let server = http.createServer((req, res)=>{
    if (url.parse(req.url).pathname != "/favicon.ico") {
        let data = "";
        req.on("data", chunk=>{
            console.log("chunk", chunk);
            data+=chunk;
        });
        req.on("end", ()=>{
            const dataSave = querystring.parse(data);
            console.log(querystring.parse(data));
            fs.appendFile('./data.txt', `\nHey There at ${new Date()}`, (err, call)=>{
                if(!err)console.log("Data Written");
                else throw err;
            });
            fs.readFile("./data.txt", "utf8", (err, content)=>{
                if(!err) console.log(content);
                else throw err;
            });
            res.write(`<h1>body we have send ny client ${data.data}</h1>`);
            res.end();
        });
    }
});
server.listen(3000, ()=>{
    console.log("server has been started at port 3000 in new way");
});