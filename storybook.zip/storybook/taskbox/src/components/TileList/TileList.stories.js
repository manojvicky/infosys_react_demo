import React from 'react';
import { storiesOf } from '@storybook/react';
// import {action} from '@storybook/addon-actions';
import TileList from "./TileList";

storiesOf('TileList', module)
    .add('loading', ()=><TileList loading tiles={[]}/>)
    .add('error', ()=> <TileList error tiles={[]}/>)
    .add('tasks', ()=><TileList tiles={[{text:'I am black',color:'black'}, {text:'I am green',color:'green'}, {text:'I am red',color:'red'}]}/>)
    .add('no tasks', ()=> <TileList tiles={[]}/>);