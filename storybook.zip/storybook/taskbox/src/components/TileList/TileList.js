import React from 'react';
import Tile from '../Tile/Tile';
export default function TileList({tiles, loading, error}){
    if(loading) return <div>loading.....</div>
    if(error) return <div>Ooops error occured</div>
    if(tiles.length===0) return <div>No tiles</div>
    return(
    <div>
        {tiles.map(tile=><Tile text={tile.text} color={tile.color} onclick={()=>{console.log("you clicked me")}}/>)}
    </div>
)
}
