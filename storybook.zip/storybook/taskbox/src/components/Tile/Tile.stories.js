import React from 'react';
import { storiesOf } from '@storybook/react';
import {action} from '@storybook/addon-actions';
import Tile from "./Tile";
export const actions = {
    clicked: action('yoo, someone clicked me')
  };
  
storiesOf('Tiles', module)
    .add('Default (black)', ()=><Tile text='I am black' color='black'{...actions}/>)
    .add('Green', ()=> <Tile text='I am green' color='green'{...actions}/>)
    .add('Red', ()=><Tile text='I am red' color='red' {...actions}/>);