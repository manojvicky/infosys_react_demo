import React from 'react';
import PropTypes from 'prop-types';

export default function Tile({color, text, clicked}){
return(<div onClick={clicked} style={{height:'100px', width: '300px', color, border:`1px solid ${color}`}}>
    {text}
</div>)
}

Tile.propTypes = {
    color: PropTypes.string.isRequired,
    text: PropTypes.string.isRequired,
    clicked: PropTypes.func,
};