import React from 'react';

import { storiesOf } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { linkTo } from '@storybook/addon-links';

import { Button, Welcome } from '@storybook/react/demo';
let text = 'Manoj_Vicky';
storiesOf('Welcome', module).add('to Storybook', () => <Welcome showApp={linkTo('Button')} />);

storiesOf('Button', module)
  .add('with text', () => <Button onClick={action('clicked')}>Hello Button</Button>)
  .add('with some emoji', () => (
    <Button onClick={action('clicked')}>
      <span role="img" aria-label="so cool">
        😀 😎 👍 Papa
      </span>
    </Button>
  ));
  storiesOf('Vicky', module)
  .add('with small letters', () => <div onClick={action('clicked')}>{text.toLowerCase()}</div>)
  .add('with capital letters', () => <div onClick={action('clicked')}>{text.toUpperCase()}</div>);

