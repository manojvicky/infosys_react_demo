import React from "react";
class NewComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            count: 0
        }
    }
    render(){
        console.log("props, context, updater",this.props, this.context, this.updater);
        return (
          <div className="newcomponent">
            <button onClick={()=>{
                this.setState({count: this.state.count+1}, (xx)=>console.log("xx", this.state.count));
                }
            }
            > {this.state.count} </button>
          </div>
        );
    }
};

export default NewComponent;
