import React from "react";
import InputElement from "./inputElement";
import "../../styles.css";
export default class AddTodo extends React.Component{
constructor(){
  super();
  this.state={
    stateProps: "Yoo"
  }
}
render(){
    return (
      <div className="addtodo">
      
      </div>
    );
}
};
