import React from "react";
import "../../styles.css";

const Header = () => {
  return (
    <h1 className="header">
        Todos  App
    </h1>
  );
};

export default Header;
