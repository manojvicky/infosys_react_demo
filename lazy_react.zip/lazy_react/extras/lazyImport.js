import React from "react";

class promise extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: []
    };
  }
  componentDidMount() {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then(response => response.json())
      .then(json => this.setState({ data: json }));
  }
  render() {
    let arr = this.state.data.map(item => {
      return <div key={item.id}>{item.title}</div>;
    });
    return <div>{arr}</div>;
  }
}
export default promise;
