import React, { Suspense, lazy } from "react";
import Spinner from 'react-bootstrap/Spinner'
const Pro = lazy(() => import("./lazyImport"));
function App() {
  console.log("pro", Pro);
  return (
    <div className="App">
      <Suspense
          fallback={
            <Spinner  animation="border" as="div" size="md"/>
          }
        >
          <Pro />
        </Suspense>
    </div>
  );
}

export default App;
