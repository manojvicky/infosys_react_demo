import React from "react";

const App = (props)=>{
    console.log("children", React.Children.count(props.children));
    return (<div className="yoo">{props.children}</div>);
}
export default App;