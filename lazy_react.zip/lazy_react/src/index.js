import React from 'react';
import ReactDOM from 'react-dom';
import App from './App/App';
import App2 from './App/App2';

import "./style.css";
console.log("react", React);
console.log("react-dom", ReactDOM);
console.log("app", App);

// const Appp = <App><div>I am App too. </div></App>

ReactDOM.render(<App ><div>I am App too</div><span>Baba re baba</span></App>, document.getElementById('root'));
ReactDOM.render(<App2 />, document.getElementById('subroot'));